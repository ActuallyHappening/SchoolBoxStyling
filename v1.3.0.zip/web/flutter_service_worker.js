'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';
const RESOURCES = {
  "version.json": "5e6e5fe6577b399440b59c8208ef47ce",
"popup.js": "d6aa35286050912cd9708e65e82a3824",
"index.html": "1f01fbac561754f3bccb8c7bd396818b",
"/": "1f01fbac561754f3bccb8c7bd396818b",
"popup.js.map": "ee4a26b78038876971d1f33dbdb4fad0",
"main.dart.js": "c6843612e216c72b06d23ce8dec1c36e",
"node_modules/@types/har-format/LICENSE": "d4a904ca135bb7bc912156fee12726f0",
"node_modules/@types/har-format/ts4.3/index.d.ts": "37c45856bce1fc12c269142f8734099a",
"node_modules/@types/har-format/README.md": "032d7174a7ac702f6d0ee1c9d625bfef",
"node_modules/@types/har-format/package.json": "7b0421ea6fc25d08dbf277747db13a66",
"node_modules/@types/har-format/index.d.ts": "1ac7adb44c058f6932ae654d4f0a4257",
"node_modules/@types/filewriter/LICENSE": "d4a904ca135bb7bc912156fee12726f0",
"node_modules/@types/filewriter/README.md": "7df326eeb23af30d534d56b78e20df51",
"node_modules/@types/filewriter/package.json": "a638906a36c8acb50ddd48d2e7259bb4",
"node_modules/@types/filewriter/index.d.ts": "9e0a2ef5e24aee33fd3727162457c77a",
"node_modules/@types/filesystem/LICENSE": "d4a904ca135bb7bc912156fee12726f0",
"node_modules/@types/filesystem/README.md": "d113bcde984af944acb632c3c562b0a0",
"node_modules/@types/filesystem/package.json": "e75714878fb85660c150919bf94917cd",
"node_modules/@types/filesystem/index.d.ts": "eb947f57e446b72666f0af11af7bcb1b",
"node_modules/@types/chrome/har-format/index.d.ts": "94af97349f57d5f4af93b5818cd6fbdd",
"node_modules/@types/chrome/LICENSE": "d4a904ca135bb7bc912156fee12726f0",
"node_modules/@types/chrome/README.md": "2bb1f52b793f53f49cc3e31e20164c33",
"node_modules/@types/chrome/package.json": "40d7d509b235fd46964c13b287a06d4f",
"node_modules/@types/chrome/index.d.ts": "0743aa53735da723a03317792bee6b4c",
"node_modules/@types/chrome/chrome-cast/index.d.ts": "a81c0f4dbf7efd733e8153aff26a1fb2",
"flutter.js": "f85e6fb278b0fd20c349186fb46ae36d",
"content.ts": "ec5ef76b219eec94ac63210c6c166e6b",
"popup.ts": "8dbaf7cc5a9eb5e4e3ed61f218a04720",
"favicon.png": "5dcef449791fa27946b3d35ad8803796",
"content.js.map": "c4d31f31409275268b90cd5a7b34eba8",
"package-lock.json": "1645ffebd751513f6a46215649c59b5b",
"package.json": "2efda75e8a602692b88b5fcd24346155",
"icons/Icon-192.png": "ac9a721a12bbc803b44f645561ecb1e1",
"icons/Icon-maskable-192.png": "c457ef57daa1d16f64b27b786ec2ea3c",
"icons/Binary%20swift%20icon.png": "0f41929783d3ca04301a89d529ac9cee",
"icons/Icon-maskable-512.png": "301a7604d45b3e739efc881eb04896ea",
"icons/Icon-512.png": "96e752610906ba2a93c65f8abe1645f1",
"manifest.json": "628250ce8964e4b8bcae7328920e9073",
"tsconfig.json": "ef516d527c3cd8d35867c2f3cb0e0546",
"content.js": "43833e3ec1d12760b3b1a753e2425508",
"assets/AssetManifest.json": "2efbb41d7877d10aac9d091f58ccd7b9",
"assets/NOTICES": "12b032370bbbd9e16ff25cc8f54e8059",
"assets/FontManifest.json": "dc3d03800ccca4601324923c0b1d6d57",
"assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "6d342eb68f170c97609e9da345464e5e",
"assets/shaders/ink_sparkle.frag": "47a605e9ce5724fb017f80e33cc65bd6",
"assets/fonts/MaterialIcons-Regular.otf": "95db9098c58fd6db106f1116bae85a0b",
"canvaskit/canvaskit.js": "2bc454a691c631b07a9307ac4ca47797",
"canvaskit/profiling/canvaskit.js": "38164e5a72bdad0faa4ce740c9b8e564",
"canvaskit/profiling/canvaskit.wasm": "95a45378b69e77af5ed2bc72b2209b94",
"canvaskit/canvaskit.wasm": "bf50631470eb967688cca13ee181af62"
};

// The application shell files that are downloaded before a service worker can
// start.
const CORE = [
  "main.dart.js",
"index.html",
"assets/AssetManifest.json",
"assets/FontManifest.json"];
// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  self.skipWaiting();
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      return cache.addAll(
        CORE.map((value) => new Request(value, {'cache': 'reload'})));
    })
  );
});

// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');
      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        return;
      }
      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});

// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== 'GET') {
    return;
  }
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (key.indexOf('?v=') != -1) {
    key = key.split('?v=')[0];
  }
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#') || key == '') {
    key = '/';
  }
  // If the URL is not the RESOURCE list then return to signal that the
  // browser should take over.
  if (!RESOURCES[key]) {
    return;
  }
  // If the URL is the index.html, perform an online-first request.
  if (key == '/') {
    return onlineFirst(event);
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache only if the resource was successfully fetched.
        return response || fetch(event.request).then((response) => {
          if (response && Boolean(response.ok)) {
            cache.put(event.request, response.clone());
          }
          return response;
        });
      })
    })
  );
});

self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
    return;
  }
  if (event.data === 'downloadOffline') {
    downloadOffline();
    return;
  }
});

// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey of Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.push(resourceKey);
    }
  }
  return contentCache.addAll(resources);
}

// Attempt to download the resource online before falling back to
// the offline cache.
function onlineFirst(event) {
  return event.respondWith(
    fetch(event.request).then((response) => {
      return caches.open(CACHE_NAME).then((cache) => {
        cache.put(event.request, response.clone());
        return response;
      });
    }).catch((error) => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response != null) {
            return response;
          }
          throw error;
        });
      });
    })
  );
}
