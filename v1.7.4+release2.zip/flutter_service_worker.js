'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';
const RESOURCES = {
  "version.json": "cc634d8509964a4d044a069a32b53cf9",
"popup.js": "5522a2497fa681c96c8336c774a3ec7f",
"index.html": "347b90fc6579e075cf5efe2a0907107a",
"/": "347b90fc6579e075cf5efe2a0907107a",
"popup.js.map": "241572349ef7e6d707020f4bce44065a",
"main.dart.js": "6d650f100b450b329174f63385e13ec3",
"node_modules/@types/har-format/LICENSE": "d4a904ca135bb7bc912156fee12726f0",
"node_modules/@types/har-format/ts4.3/index.d.ts": "37c45856bce1fc12c269142f8734099a",
"node_modules/@types/har-format/README.md": "032d7174a7ac702f6d0ee1c9d625bfef",
"node_modules/@types/har-format/package.json": "7b0421ea6fc25d08dbf277747db13a66",
"node_modules/@types/har-format/index.d.ts": "1ac7adb44c058f6932ae654d4f0a4257",
"node_modules/@types/filewriter/LICENSE": "d4a904ca135bb7bc912156fee12726f0",
"node_modules/@types/filewriter/README.md": "7df326eeb23af30d534d56b78e20df51",
"node_modules/@types/filewriter/package.json": "a638906a36c8acb50ddd48d2e7259bb4",
"node_modules/@types/filewriter/index.d.ts": "9e0a2ef5e24aee33fd3727162457c77a",
"node_modules/@types/filesystem/LICENSE": "d4a904ca135bb7bc912156fee12726f0",
"node_modules/@types/filesystem/README.md": "d113bcde984af944acb632c3c562b0a0",
"node_modules/@types/filesystem/package.json": "e75714878fb85660c150919bf94917cd",
"node_modules/@types/filesystem/index.d.ts": "eb947f57e446b72666f0af11af7bcb1b",
"node_modules/@types/youtube/LICENSE": "d4a904ca135bb7bc912156fee12726f0",
"node_modules/@types/youtube/README.md": "cfe4390cbcd89c039d87fa56e0b82db2",
"node_modules/@types/youtube/package.json": "d05b2b7ba9503dc890d04a614371842b",
"node_modules/@types/youtube/index.d.ts": "933d89903caa76999c2efa26ec2e27ab",
"node_modules/@types/chrome/har-format/index.d.ts": "94af97349f57d5f4af93b5818cd6fbdd",
"node_modules/@types/chrome/LICENSE": "d4a904ca135bb7bc912156fee12726f0",
"node_modules/@types/chrome/README.md": "2bb1f52b793f53f49cc3e31e20164c33",
"node_modules/@types/chrome/package.json": "40d7d509b235fd46964c13b287a06d4f",
"node_modules/@types/chrome/index.d.ts": "0743aa53735da723a03317792bee6b4c",
"node_modules/@types/chrome/chrome-cast/index.d.ts": "a81c0f4dbf7efd733e8153aff26a1fb2",
"node_modules/.bin/resolve": "cc916ba0117083b308254cf1a2f47844",
"node_modules/.bin/nanoid": "49733797030660b081f981653a25402b",
"node_modules/.bin/vite": "6b1be8b36cf2579f2fbcf2889cd52003",
"node_modules/.bin/rollup": "28201fb93a0be1cbe7b3324ad33387a8",
"node_modules/.bin/esbuild": "01aea26ed06ab994859d14d6edd10521",
"node_modules/resolve/LICENSE": "baa47288b5bd3e657a01886ce3dd0cb6",
"node_modules/resolve/test/shadowed_core.js": "218995538aa76bcf5001a3c997c95aca",
"node_modules/resolve/test/dotdot.js": "eb25b51a3ccfacd7b4fbbb94a342edf8",
"node_modules/resolve/test/pathfilter/deep_ref/main.js": "d41d8cd98f00b204e9800998ecf8427e",
"node_modules/resolve/test/home_paths.js": "660800979dd80e96a392ba3d435de48e",
"node_modules/resolve/test/core.js": "1b98e334b28d23f9130a63201398a5da",
"node_modules/resolve/test/filter_sync.js": "7e1a00d127e1512d54bce45054ddab03",
"node_modules/resolve/test/subdirs.js": "e8a1a80da10c1fd7193ac00aa839644c",
"node_modules/resolve/test/node_path.js": "3351665d86f053e84659a8a865cfc626",
"node_modules/resolve/test/node_path/x/ccc/index.js": "e80e2b6d94895cc3c6641ecf9e1ab0d6",
"node_modules/resolve/test/node_path/x/aaa/index.js": "52127f7aa347b8613740d223a1fd8bb8",
"node_modules/resolve/test/node_path/y/bbb/index.js": "65a094ea67b5e4886331645f37463a32",
"node_modules/resolve/test/node_path/y/ccc/index.js": "1840eac4d3fe020fa3d4642a5ae21cec",
"node_modules/resolve/test/module_dir.js": "dba5837c6fa7833449c084f949c9eb3d",
"node_modules/resolve/test/symlinks.js": "a216ed42c6bedc2324a6c93889f9df58",
"node_modules/resolve/test/faulty_basedir.js": "dba3e4709b1aae6d85bfa7a7210bc13c",
"node_modules/resolve/test/resolver_sync.js": "1432d1b0503cedcfdcf191b0e8e0d768",
"node_modules/resolve/test/dotdot/abc/index.js": "a6d23efd29494430e12623e97e094c7d",
"node_modules/resolve/test/dotdot/index.js": "303653a00d6b4e9506c0ec3b7ef50234",
"node_modules/resolve/test/mock.js": "56413f13828cd95488ae65d55f606bdb",
"node_modules/resolve/test/precedence.js": "60dbf81e71603b0ce609b8e33eed177f",
"node_modules/resolve/test/home_paths_sync.js": "e942f35d6b5d0b28df52f7e542d5e0aa",
"node_modules/resolve/test/module_dir/ymodules/aaa/index.js": "b96f38dcf7e5c8674c12f465faf0f054",
"node_modules/resolve/test/module_dir/xmodules/aaa/index.js": "9e45e7ed7dd804266a1b96eb70db330f",
"node_modules/resolve/test/module_dir/zmodules/bbb/main.js": "09fa66df61573f1a368f30489cc33741",
"node_modules/resolve/test/module_dir/zmodules/bbb/package.json": "4a3e4b65131149d13cf2a9006879a030",
"node_modules/resolve/test/nonstring.js": "90a1edf2d8cda69acd16d333f232468b",
"node_modules/resolve/test/mock_sync.js": "5f29325447d2898aa55e739af27c1c00",
"node_modules/resolve/test/filter.js": "4f4848e867716678497a8797df2a81c8",
"node_modules/resolve/test/precedence/bbb/main.js": "889ce877c52c09163d1be7868a3404ec",
"node_modules/resolve/test/precedence/bbb.js": "5e98b57495bcdf630a21ec378db7b0e9",
"node_modules/resolve/test/precedence/aaa.js": "49163d248668737d115fc3d13361d34c",
"node_modules/resolve/test/precedence/aaa/index.js": "5790d1c0db9d396d0c5d383eea413290",
"node_modules/resolve/test/precedence/aaa/main.js": "293842d0cd56c726e5510a4d72df51b5",
"node_modules/resolve/test/shadowed_core/node_modules/util/index.js": "d41d8cd98f00b204e9800998ecf8427e",
"node_modules/resolve/test/resolver/mug.coffee": "d41d8cd98f00b204e9800998ecf8427e",
"node_modules/resolve/test/resolver/same_names/foo/index.js": "0c1d9e1731bb3d71b0b7a15695bfab14",
"node_modules/resolve/test/resolver/same_names/foo.js": "d00072229e607e3109a7c7b617d829f8",
"node_modules/resolve/test/resolver/cup.coffee": "68b329da9893e34099c7d8ad5cb9c940",
"node_modules/resolve/test/resolver/symlinked/_/node_modules/foo.js": "d41d8cd98f00b204e9800998ecf8427e",
"node_modules/resolve/test/resolver/symlinked/package/package.json": "0c5b2b6430634798519321e18ed3954d",
"node_modules/resolve/test/resolver/symlinked/package/bar.js": "4e957bc0e855379d8c9d7dc61d94dd5b",
"node_modules/resolve/test/resolver/without_basedir/main.js": "a273979c29547819f4ce096e8454eba6",
"node_modules/resolve/test/resolver/dot_main/index.js": "0c1d9e1731bb3d71b0b7a15695bfab14",
"node_modules/resolve/test/resolver/dot_main/package.json": "6651c03c05348dc79127845895e2e021",
"node_modules/resolve/test/resolver/invalid_main/package.json": "d753bb6b216e118c75d96e043a47ae12",
"node_modules/resolve/test/resolver/multirepo/package.json": "3cef7227b9a2ca3a6e1991459f40beba",
"node_modules/resolve/test/resolver/multirepo/packages/package-b/index.js": "d41d8cd98f00b204e9800998ecf8427e",
"node_modules/resolve/test/resolver/multirepo/packages/package-b/package.json": "ce6c7a1786d468fe499a0bbbc654c858",
"node_modules/resolve/test/resolver/multirepo/packages/package-a/index.js": "4daeb9776a4995aa9a64eeba1275ca8a",
"node_modules/resolve/test/resolver/multirepo/packages/package-a/package.json": "466e84ae67db33dda31ba06fb0212e2d",
"node_modules/resolve/test/resolver/multirepo/lerna.json": "a2d913ed76975c203ea97d0c623fb462",
"node_modules/resolve/test/resolver/dot_slash_main/index.js": "0c1d9e1731bb3d71b0b7a15695bfab14",
"node_modules/resolve/test/resolver/dot_slash_main/package.json": "844f13b650c02c10e1fba9ca7d1536f2",
"node_modules/resolve/test/resolver/malformed_package_json/index.js": "d41d8cd98f00b204e9800998ecf8427e",
"node_modules/resolve/test/resolver/malformed_package_json/package.json": "d9bed3b7e151f11b8fdadf75f1db96d9",
"node_modules/resolve/test/resolver/mug.js": "d41d8cd98f00b204e9800998ecf8427e",
"node_modules/resolve/test/resolver/foo.js": "0c1d9e1731bb3d71b0b7a15695bfab14",
"node_modules/resolve/test/resolver/quux/foo/index.js": "0c1d9e1731bb3d71b0b7a15695bfab14",
"node_modules/resolve/test/resolver/baz/doom.js": "d41d8cd98f00b204e9800998ecf8427e",
"node_modules/resolve/test/resolver/baz/quux.js": "0c1d9e1731bb3d71b0b7a15695bfab14",
"node_modules/resolve/test/resolver/baz/package.json": "0f73fb8842088e1e70c904431c1ad130",
"node_modules/resolve/test/resolver/browser_field/a.js": "d41d8cd98f00b204e9800998ecf8427e",
"node_modules/resolve/test/resolver/browser_field/package.json": "e110dd6fd6f26b1f3d45948cc1e27da0",
"node_modules/resolve/test/resolver/browser_field/b.js": "d41d8cd98f00b204e9800998ecf8427e",
"node_modules/resolve/test/resolver/nested_symlinks/mylib/sync.js": "4c05bb8c706430ef6b423d6dd01a5797",
"node_modules/resolve/test/resolver/nested_symlinks/mylib/async.js": "2f1e59b3e11027b5ac9db2855a1ffc40",
"node_modules/resolve/test/resolver/nested_symlinks/mylib/package.json": "d67bf0331e8ca5350eef9b8bc85cde08",
"node_modules/resolve/test/resolver/incorrect_main/index.js": "0b72654f2e307bde1ab4fbeab7af2b78",
"node_modules/resolve/test/resolver/incorrect_main/package.json": "3d72b845730884cbf8970497318e754c",
"node_modules/resolve/test/resolver/false_main/index.js": "d41d8cd98f00b204e9800998ecf8427e",
"node_modules/resolve/test/resolver/false_main/package.json": "c957144f31f2bda33e82b3d31c6a4bda",
"node_modules/resolve/test/resolver/other_path/root.js": "d41d8cd98f00b204e9800998ecf8427e",
"node_modules/resolve/test/resolver/other_path/lib/other-lib.js": "d41d8cd98f00b204e9800998ecf8427e",
"node_modules/resolve/test/resolver.js": "03b21e4ead4231a425bdc7f0441b7f92",
"node_modules/resolve/test/node-modules-paths.js": "cae1b936b91a0beadb64f43e8c53e5a8",
"node_modules/resolve/test/pathfilter.js": "bbe22bc568c2aee7953cc78147cb9a6f",
"node_modules/resolve/bin/resolve": "cc916ba0117083b308254cf1a2f47844",
"node_modules/resolve/example/sync.js": "54c6056bebcdb34d4bca7e25d556f4fe",
"node_modules/resolve/example/async.js": "dc08ce48012fc11583adbe609b1f2520",
"node_modules/resolve/sync.js": "98b7c6f62e9b7a1dbc24d4bcd7f46bed",
"node_modules/resolve/index.js": "0d09fd975136c80fa0b07090fb6c3df8",
"node_modules/resolve/readme.markdown": "5e9be42afdffd370ca27cb3c371d3b16",
"node_modules/resolve/async.js": "0072b73e74e7931c9e922fb6e845b2a6",
"node_modules/resolve/package.json": "30ef94e25c3720ee6a37cfa23049af8f",
"node_modules/resolve/.github/FUNDING.yml": "b1d37d1cb74342343e3eced5b7a36cce",
"node_modules/resolve/lib/core.js": "bfba23e29c5a7fc487a564f4c7ccdf14",
"node_modules/resolve/lib/caller.js": "2bb2d2683e11c79a1b6b8a22caef583b",
"node_modules/resolve/lib/sync.js": "8c33718b32e0b3041bc85e46e47e39b0",
"node_modules/resolve/lib/normalize-options.js": "0deb023ba3c6de50244f140e21f4a08f",
"node_modules/resolve/lib/homedir.js": "0fd2b8ddd7fc048801164852bd751c68",
"node_modules/resolve/lib/core.json": "fc81f4ebde31ae7cfb5e81bca6b66095",
"node_modules/resolve/lib/async.js": "b0772b8edff193ba58392e1ba217f690",
"node_modules/resolve/lib/is-core.js": "db824542b1fcf8fdd8fddc73a7c98856",
"node_modules/resolve/lib/node-modules-paths.js": "8cda3e75c5735f47e2222eb6c2782fd0",
"node_modules/resolve/SECURITY.md": "23030733bf7c5f821e7cbff6098811bd",
"node_modules/nanoid/LICENSE": "237c21016e56a1ee4475a39fc00d1504",
"node_modules/nanoid/bin/nanoid.cjs": "49733797030660b081f981653a25402b",
"node_modules/nanoid/index.browser.js": "a0cb4e8711476b2c70bfe1286479086d",
"node_modules/nanoid/async/index.browser.js": "2dd2f72c635ad1c3b2ce043ed763ac60",
"node_modules/nanoid/async/index.js": "fe4c3998ac84ae9106e9786b5ecac88e",
"node_modules/nanoid/async/package.json": "abe925a5c146999bb2450c9d296df000",
"node_modules/nanoid/async/index.browser.cjs": "fbaf0352c4d539adb654fcbdad378333",
"node_modules/nanoid/async/index.cjs": "fda21b3b56ea48e4689bd20aca5f17a2",
"node_modules/nanoid/async/index.native.js": "e900bef8ac50df16268b2fe719c9a5d5",
"node_modules/nanoid/async/index.d.ts": "a3984190d7e211a9520ab61141339772",
"node_modules/nanoid/index.js": "4dd3d76c89d326d236fa15b1642964f9",
"node_modules/nanoid/README.md": "b06670f28666acb6314d82ccb12bbe5a",
"node_modules/nanoid/non-secure/index.js": "29b49a8d77d26ad277e42577e82c6526",
"node_modules/nanoid/non-secure/package.json": "cc71a594b961b450376a595078782fc1",
"node_modules/nanoid/non-secure/index.cjs": "9022da453365e752406ea2ff72c72d7e",
"node_modules/nanoid/non-secure/index.d.ts": "9273a31537439ae8d310bfdde5ab9a23",
"node_modules/nanoid/package.json": "d3f798390457c849dd46eb116721a619",
"node_modules/nanoid/index.browser.cjs": "2ccbced9db4f6fe4c8f7312610cd90ba",
"node_modules/nanoid/index.cjs": "7e5fbd5f3f497e7a7133ca89f38907c4",
"node_modules/nanoid/url-alphabet/index.js": "36637b3cf3a881262e6ec64465ba0dee",
"node_modules/nanoid/url-alphabet/package.json": "cc71a594b961b450376a595078782fc1",
"node_modules/nanoid/url-alphabet/index.cjs": "d0c4505dc8c786d32fdecc68e2e556bd",
"node_modules/nanoid/nanoid.js": "438797624030c8b45ee874d60f3b7815",
"node_modules/nanoid/index.d.ts": "ad265c6480d9ddbc1209864887a06ebd",
"node_modules/function-bind/LICENSE": "e7417c1a8ad83f88bcac21ad440d48b2",
"node_modules/function-bind/test/index.js": "9786942aeefcdc12b2f841895ede1647",
"node_modules/function-bind/index.js": "80c4b0103888a6175e5579dedbab1ea3",
"node_modules/function-bind/README.md": "9e8d47033f55b3ee4d53248dc8fbd84b",
"node_modules/function-bind/package.json": "f453e26c8d3482b4c3736f53303b4ec5",
"node_modules/function-bind/implementation.js": "c9440a397f0261d2e74484628d1cab9b",
"node_modules/postcss/LICENSE": "e0ef868fdaaba6859dcbab082c20439b",
"node_modules/postcss/README.md": "d4271deeee7d030465b9226a2bd908de",
"node_modules/postcss/package.json": "f532ab32429c785d4430505a69028f68",
"node_modules/postcss/lib/postcss.js": "e7c23f51119cf9a63c0fb16df51b59f2",
"node_modules/postcss/lib/rule.d.ts": "66008bba317642eeefad7eca9105f39d",
"node_modules/postcss/lib/lazy-result.d.ts": "e772e5058724edda41a7e2a6570e553b",
"node_modules/postcss/lib/stringifier.js": "063aa3d297058c022cfdc450474862f0",
"node_modules/postcss/lib/stringify.js": "ac81d75fa96fd8de7774dddc431df716",
"node_modules/postcss/lib/css-syntax-error.js": "72adb068bf19fa1962e31654c4aedf62",
"node_modules/postcss/lib/previous-map.d.ts": "697c4659fd10b288f9fa70d0856d2bb0",
"node_modules/postcss/lib/result.d.ts": "e91a92ccbfd1812c3d184aaa5dad8c92",
"node_modules/postcss/lib/at-rule.js": "aae46a0f113db45ae888478416a9167f",
"node_modules/postcss/lib/declaration.js": "99c9a17d92db2e20170ead0fd6337b00",
"node_modules/postcss/lib/parse.d.ts": "9d57666eec6757ab45524a50432fb930",
"node_modules/postcss/lib/warning.js": "88aded9ade4264879f0f4fd7cc829604",
"node_modules/postcss/lib/processor.js": "256e9ef92812464ad62e7d952e0bbec9",
"node_modules/postcss/lib/previous-map.js": "fa5d2b921b235bdb4dedfabc4f2ff02e",
"node_modules/postcss/lib/fromJSON.js": "8ad6ff14cf9fbe0e9dbf7c24bfd4dc6c",
"node_modules/postcss/lib/input.d.ts": "bd06947d97ae9df0c549ef1ec99788bb",
"node_modules/postcss/lib/at-rule.d.ts": "26f0393f68e735c2f7831ae42f0353d3",
"node_modules/postcss/lib/stringifier.d.ts": "891ddf2720d0f0aa8e8022828189b8bf",
"node_modules/postcss/lib/map-generator.js": "f5394f69b7032c0e45f09ceeb10cdde1",
"node_modules/postcss/lib/comment.d.ts": "e636a502f2190ade7881fa534ce9dae2",
"node_modules/postcss/lib/declaration.d.ts": "f01e6ad669cbc649e318c8dc59d7dc58",
"node_modules/postcss/lib/processor.d.ts": "cd527238043aa57d450344a1ead34a3f",
"node_modules/postcss/lib/list.js": "350c8a35ea97782c48efd50c6450ce02",
"node_modules/postcss/lib/warn-once.js": "b90bf6629bd7f2403237b66a0b714af8",
"node_modules/postcss/lib/lazy-result.js": "a19086ef935a2fcbcec81753e384d2b2",
"node_modules/postcss/lib/postcss.mjs": "48c55913cf3a832294f1b8ee9ae3a313",
"node_modules/postcss/lib/comment.js": "deda63c1442ea52fbf26d1a17762d91c",
"node_modules/postcss/lib/postcss.d.ts": "2b6e4e125a194636e54b894ad2fa2bde",
"node_modules/postcss/lib/container.d.ts": "3a5d4b1f7b57551a83e82fe7e5a7a399",
"node_modules/postcss/lib/stringify.d.ts": "dd83eccd8a55722d23fddc36a5cba74c",
"node_modules/postcss/lib/document.d.ts": "89238b6425a50fcd5096a4ac0cb36d67",
"node_modules/postcss/lib/node.js": "e136749bf85948c36e6d60c9dd6d264a",
"node_modules/postcss/lib/parse.js": "a41d8a59f34cbcaedc11520bd7b3e217",
"node_modules/postcss/lib/root.js": "99788e02cfe5133cee096f3027187f21",
"node_modules/postcss/lib/fromJSON.d.ts": "d69edd95bdab0f6464bea66883ecb3ff",
"node_modules/postcss/lib/list.d.ts": "4f180970feeece82183a0a6400015887",
"node_modules/postcss/lib/no-work-result.d.ts": "5a74c84a4a717c49d7887d7f750ab320",
"node_modules/postcss/lib/tokenize.js": "1d19a732f92d8b8aac82f839bae05421",
"node_modules/postcss/lib/rule.js": "089e93123dfbe4ba01fc4e4aa3de980a",
"node_modules/postcss/lib/css-syntax-error.d.ts": "d476aec271e0408861989f510780b328",
"node_modules/postcss/lib/symbols.js": "4828dddfc2d8201c488c646e307f11dc",
"node_modules/postcss/lib/no-work-result.js": "0e1838118c4f1613313479d256a8f1f1",
"node_modules/postcss/lib/result.js": "283f53ba4029777a836f843968cc7c77",
"node_modules/postcss/lib/terminal-highlight.js": "3dea5dd22732f8510b84b6e37de74cc8",
"node_modules/postcss/lib/warning.d.ts": "a81839f3a46630923da4ea0b8c4c41bb",
"node_modules/postcss/lib/container.js": "9d434b8dc855cbf9ba7a7a2409868839",
"node_modules/postcss/lib/parser.js": "3e79dbe95c8169dfbd919a9c1738f6f2",
"node_modules/postcss/lib/node.d.ts": "8c02e7fed8eae6bf583474396f368cfe",
"node_modules/postcss/lib/root.d.ts": "2f32d71cc55bcd7908f6f65fbd95c724",
"node_modules/postcss/lib/input.js": "20779670c192af737c701f10ae2a01c5",
"node_modules/postcss/lib/document.js": "87f786624eaf8bad517611aca1013427",
"node_modules/supports-preserve-symlinks-flag/LICENSE": "d237eac07663bde2409de740ba75ec97",
"node_modules/supports-preserve-symlinks-flag/test/index.js": "2c1b6d23e1fab5de4160480a06dd6b40",
"node_modules/supports-preserve-symlinks-flag/CHANGELOG.md": "21b2e2c4bebc79d16f3fee94bc8ba486",
"node_modules/supports-preserve-symlinks-flag/index.js": "634f1307f1734f08750c68034a47d9e0",
"node_modules/supports-preserve-symlinks-flag/README.md": "ea047231f1083b2ec7ccbc8024503991",
"node_modules/supports-preserve-symlinks-flag/package.json": "bfaaddac07876305313de6edc3d38b5d",
"node_modules/supports-preserve-symlinks-flag/.github/FUNDING.yml": "dc18380bc514c5728fb7ab2d9c42856b",
"node_modules/supports-preserve-symlinks-flag/browser.js": "1d6d56ed4832eb474dbb994e6fa805d0",
"node_modules/path-parse/LICENSE": "4b940f9668dfcb796d2cb98ad94692df",
"node_modules/path-parse/index.js": "35a8542db6ae043c3caad7fac18fa62c",
"node_modules/path-parse/README.md": "716e39f18c8dadd37b49a9f63ccd61d6",
"node_modules/path-parse/package.json": "e225588668693d527d2a82f0db68088c",
"node_modules/picocolors/LICENSE": "8aabd5d21f92335888d962fb6ca980f8",
"node_modules/picocolors/picocolors.js": "580aa71ccc19d8e59130a0e8127a93c6",
"node_modules/picocolors/README.md": "f2c17387e2a6a4d84562cf20c7bcec5d",
"node_modules/picocolors/types.ts": "f6d8e07d7aab25ffa981e5f865db95ac",
"node_modules/picocolors/package.json": "4d7ee16898c8b0c6721a1c0f56e80b17",
"node_modules/picocolors/picocolors.browser.js": "6f11fa261571200c3632acaef972c419",
"node_modules/picocolors/picocolors.d.ts": "d7e77656d31b27e13b3fddf73bb503ac",
"node_modules/vite/LICENSE.md": "c5a014073aabe09e783fa7c516de617f",
"node_modules/vite/types/commonjs.d.ts": "cbace68b4dce36f8a69d03d278703b67",
"node_modules/vite/types/connect.d.ts": "61851e6b112ee2b5819d964a12195242",
"node_modules/vite/types/hmrPayload.d.ts": "1b972e23998c8056ccac0f02e130783a",
"node_modules/vite/types/hot.d.ts": "7a96014710658813f6d5d80c8fe8ec9b",
"node_modules/vite/types/customEvent.d.ts": "861dcf43222ebcedcc8b46843f02900f",
"node_modules/vite/types/ws.d.ts": "4775244e14e7034aa4664f0405c1ce2d",
"node_modules/vite/types/importGlob.d.ts": "b7939b9a2241b1f9dd1d7523c8c447ff",
"node_modules/vite/types/package.json": "163ba2b134f6e78ee81e426e379260ac",
"node_modules/vite/types/terser.d.ts": "c8054c02a4f8f022b93a5dc89c0a0305",
"node_modules/vite/types/alias.d.ts": "8e202d1f695504e91de6ad81ae91ff15",
"node_modules/vite/types/chokidar.d.ts": "a03e63554eaebd2d0f2808d6028cbf45",
"node_modules/vite/types/anymatch.d.ts": "51db50c674eb582398dbdf2cce21e91c",
"node_modules/vite/types/importMeta.d.ts": "693df515ef7325aae837e956a2c53fc8",
"node_modules/vite/types/dynamicImportVars.d.ts": "83a5c076cf2324697814468dfbca1d18",
"node_modules/vite/types/http-proxy.d.ts": "299f8aa4cd0a2c6c3780a0e3312935a4",
"node_modules/vite/bin/openChrome.applescript": "154fe7671f14201efa540c5026ad4c64",
"node_modules/vite/bin/vite.js": "6b1be8b36cf2579f2fbcf2889cd52003",
"node_modules/vite/dist/node/constants.js": "3dd8cf598314800f6d00ae753207281a",
"node_modules/vite/dist/node/index.js": "068aaa778aedb3ac1024938ec7068890",
"node_modules/vite/dist/node/chunks/dep-d29b4e33.js": "a10e12db4a3e6b087112aaadcef6fd2a",
"node_modules/vite/dist/node/chunks/dep-19c40c50.js": "197636ec3e9a33f6910f5812a2c75690",
"node_modules/vite/dist/node/chunks/dep-9055f77d.js": "1de00789877d18ed21a2ea8f74d8f30d",
"node_modules/vite/dist/node/chunks/dep-9deb2354.js": "4dc6c23ee08f08e54d82878e84213146",
"node_modules/vite/dist/node/chunks/dep-07a79996.js": "7777c5708f838a0a3b6a998a6a658565",
"node_modules/vite/dist/node/cli.js": "ef91afed0a1baffdb181d529f1500790",
"node_modules/vite/dist/node/index.d.ts": "cf0d416d9b895c93209aeba38ebee227",
"node_modules/vite/dist/client/client.mjs": "2a29d964d8356dbf846e34d5c7cb3c21",
"node_modules/vite/dist/client/env.mjs.map": "5d15375eef9f53991360e5fb924f962b",
"node_modules/vite/dist/client/client.mjs.map": "380afcadfcd6e74bd5ed272feab80bcb",
"node_modules/vite/dist/client/env.mjs": "7b417978c8b450f134b32ec1962e2ef6",
"node_modules/vite/dist/node-cjs/publicUtils.cjs": "9eb9096997b11878fb56a5c16e0776d5",
"node_modules/vite/README.md": "58f705be7c35eeb6630a4d27e37b7199",
"node_modules/vite/package.json": "856167eb40429b0ee769f8abd7ebb107",
"node_modules/vite/index.cjs": "57c2023a8f2e3b8feed42f20060f95fc",
"node_modules/vite/client.d.ts": "15a09181d4449a8a03cc5301d87c25ea",
"node_modules/vite/src/client/client.ts": "4329cb767898f03ff467385c827e2cca",
"node_modules/vite/src/client/tsconfig.json": "d4c4f05a48eef5f2f084be505096ecff",
"node_modules/vite/src/client/env.ts": "f4e721c0147f416cdc5197d1caadddc5",
"node_modules/vite/src/client/overlay.ts": "ea84a8faf8ef1f4b8558a892fa57ae53",
"node_modules/is-core-module/LICENSE": "02b0fb5ff4014a08fd4193bc3e2349e2",
"node_modules/is-core-module/test/index.js": "9434e7ee575518cb07633b0ae1d32989",
"node_modules/is-core-module/CHANGELOG.md": "82660ab44890f5377c40b54d3472633e",
"node_modules/is-core-module/index.js": "a65eec6935f0eadcdd9c6ed89b00a878",
"node_modules/is-core-module/README.md": "cd04f1e7e9e51f3b2f8d30c40a0c9aa2",
"node_modules/is-core-module/core.json": "5096e78cf6ff0ba87d6727407aa9d834",
"node_modules/is-core-module/package.json": "b6e5330919de49caa17ae92f597a9da3",
"node_modules/rollup/LICENSE.md": "61eb79d40b84270db630d0fd3cf43867",
"node_modules/rollup/CHANGELOG.md": "ed83f44609587e53eb9d3584dc6e3a63",
"node_modules/rollup/dist/rollup.browser.js.map": "24fdb5b3cec9e1cd08c82bd578be0d75",
"node_modules/rollup/dist/rollup.browser.js": "88e7f21199384a25b3741b32cd000140",
"node_modules/rollup/dist/bin/rollup": "28201fb93a0be1cbe7b3324ad33387a8",
"node_modules/rollup/dist/rollup.js": "ad3ef0f5728cb78b6c441bfdc02843b8",
"node_modules/rollup/dist/rollup.d.ts": "c7ecce9fff3374f6c8cd09a1103b11e7",
"node_modules/rollup/dist/shared/watch-cli.js": "7428a263d533955881de80bc160bc9d7",
"node_modules/rollup/dist/shared/mergeOptions.js": "9ad447aaf50e34577ed31a4f4f9789f4",
"node_modules/rollup/dist/shared/rollup.js": "b692baed4b48673dd9698e88a3e8a8d4",
"node_modules/rollup/dist/shared/index.js": "7acf7d3e42a08f8c9e0bbaca3ad58274",
"node_modules/rollup/dist/shared/watch.js": "674e00855640be436c78950b5491fc10",
"node_modules/rollup/dist/shared/loadConfigFile.js": "796bb91acd5e416046219e32871bb0db",
"node_modules/rollup/dist/es/rollup.browser.js": "dd382593483c7ef915ec9a8d1b6e08de",
"node_modules/rollup/dist/es/rollup.js": "e41e87d4c3621872c8704a3c23014f70",
"node_modules/rollup/dist/es/shared/rollup.js": "36e1dc68beeab93a077663766477b59e",
"node_modules/rollup/dist/es/shared/watch.js": "a128b4da3d1edf56551aa998c3cc51db",
"node_modules/rollup/dist/es/package.json": "6138da8f9bd4f861c6157689d96b6d64",
"node_modules/rollup/dist/loadConfigFile.js": "cd805b5c0eef9fa59821b3d1e9769ebb",
"node_modules/rollup/README.md": "ed730cf918e74a415f7818523cf86379",
"node_modules/rollup/package.json": "a478a1a7615944705bb562996b39b786",
"node_modules/esbuild-darwin-arm64/bin/esbuild": "01aea26ed06ab994859d14d6edd10521",
"node_modules/esbuild-darwin-arm64/README.md": "018d8862d5055c48e6cbdbf99c9e10a7",
"node_modules/esbuild-darwin-arm64/package.json": "9c936b6e137df600fafdac203bec1ccf",
"node_modules/has/test/index.js": "91cf2ac2cdf73a0d46f9be0607e6af94",
"node_modules/has/README.md": "c3ded9188a92bbea57b2dfe8f00e32ee",
"node_modules/has/package.json": "2fee243336ba5aeebed1e0145472cd49",
"node_modules/has/LICENSE-MIT": "d000afc3c9ff3501a5610197db76a246",
"node_modules/has/src/index.js": "a8d64bba485fcf821ade7ce6e94f9c0a",
"node_modules/esbuild/LICENSE.md": "46b907b175628fe6d2a5258b252970fa",
"node_modules/esbuild/bin/esbuild": "01aea26ed06ab994859d14d6edd10521",
"node_modules/esbuild/README.md": "4c83bfb5e79b2207a8ae09c3c0e72ac6",
"node_modules/esbuild/package.json": "4b5bc9722af387518be55b9aeedcb37d",
"node_modules/esbuild/install.js": "aa0c4c1f9a897e621b381d62b1cf0513",
"node_modules/esbuild/lib/main.d.ts": "41a9bba5d2bf1916b8bac4c8113d1855",
"node_modules/esbuild/lib/main.js": "67745998ef0acb3391ffeb9ca6eff80c",
"node_modules/fsevents/fsevents.node": "0cd02e818c0a460e23dec5b38b702ee2",
"node_modules/fsevents/LICENSE": "76d77bb5bb62ad250453f947253ea01c",
"node_modules/fsevents/fsevents.js": "e42b1d3a9d840915fcbbaf1d625e73bd",
"node_modules/fsevents/fsevents.d.ts": "f16f5de27ad74e00330aaa0b2ae82ab2",
"node_modules/fsevents/README.md": "0030bee28e9a576230b69c2be82e70ed",
"node_modules/fsevents/package.json": "b22f0f9ffcfff126bebbf770585dadc1",
"node_modules/source-map-js/LICENSE": "b1ca6dbc0075d56cbd9931a75566cd44",
"node_modules/source-map-js/CHANGELOG.md": "477c7c329d27e6ad2d13718c5adc5a1e",
"node_modules/source-map-js/README.md": "64a252202e119873707ebc50bf0c9e3e",
"node_modules/source-map-js/package.json": "595fdb4eb04ce1244d2a9535bf83ee6b",
"node_modules/source-map-js/source-map.js": "1bb9c1d35d2fbb3779c67306ca3d8070",
"node_modules/source-map-js/lib/source-map-consumer.js": "ac42944efbc1399fe19c96d0ad1546ab",
"node_modules/source-map-js/lib/quick-sort.js": "ace64c2b979c64ee72d7f445c6142601",
"node_modules/source-map-js/lib/util.js": "460072236ad347448538aeeba8d90144",
"node_modules/source-map-js/lib/base64-vlq.js": "10ab2672fb7feaa6e4a2ca651d2412f9",
"node_modules/source-map-js/lib/mapping-list.js": "b43d49bb65a0e89b26e13a97de816cad",
"node_modules/source-map-js/lib/binary-search.js": "250315731532fce9f782a6dcc6a0f569",
"node_modules/source-map-js/lib/base64.js": "d6ba9a233e14b859b51f538c0b295953",
"node_modules/source-map-js/lib/array-set.js": "e409c2198743fb3f9c3e5939358bc32e",
"node_modules/source-map-js/lib/source-node.js": "c53b081a390b23d134d60c390843b5de",
"node_modules/source-map-js/lib/source-map-generator.js": "85a051f0e4bdb90a4beafe62f6f1cedf",
"node_modules/source-map-js/source-map.d.ts": "8309069f2590dcf4e7b0a4db3d04d267",
"content.ts": "9083689fa767fdb8c5119ff025a48c45",
"__pycache__/macro.cpython-310.pyc": "e8871d02cbf4d24a2988deb84f7b9e62",
"popup.ts": "7874bade2bc959ca46eca8b8e78e99ea",
"favicon.png": "5dcef449791fa27946b3d35ad8803796",
"content.js.map": "3c825e98d40d07181a5d1207a720543c",
"compile": "f54a36cff0c2a7dae871b06879ec88d8",
"package-lock.json": "66359d61a891eb2437370c85b72d64e4",
"package.json": "b0a13d2cb4005732903d984d242a3276",
"icons/Icon-192.png": "ac9a721a12bbc803b44f645561ecb1e1",
"icons/Icon-maskable-192.png": "c457ef57daa1d16f64b27b786ec2ea3c",
"icons/Binary%20swift%20icon.png": "0f41929783d3ca04301a89d529ac9cee",
"icons/Icon-maskable-512.png": "301a7604d45b3e739efc881eb04896ea",
"icons/Icon-512.png": "96e752610906ba2a93c65f8abe1645f1",
"manifest.json": "a9e3827f628a495d3d75a984a4d1b0ac",
"DIRTY/firebase-firestore-v9.11.js": "a09d6090f3c2fe5bf980d725a83c16a2",
"DIRTY/firebase-app-check-v9.11.js": "b335129f351e0ccf2ba94333c55db652",
"DIRTY/bundle.js": "671e5246598ec566ed157c3e27fb2e04",
"DIRTY/DIRTY_manual_CSP_fix.js": "1cb16b4a5088d6c1c061aaef537f76dc",
"DIRTY/firebase-remote-config-v9.11.js": "0dc22150d2eba1197b4018e777f91c1a",
"DIRTY/firebase-app-v9.11.js": "c03afa36f68089d34fc1ada10dd6ec5c",
"tsconfig.json": "ef516d527c3cd8d35867c2f3cb0e0546",
"content.js": "031fff02a57e064c9e81c4c93ec45c77",
"build": "7c292670125e98d47af3c0934a068ecb",
"assets/AssetManifest.json": "2efbb41d7877d10aac9d091f58ccd7b9",
"assets/NOTICES": "e7dddee98a35c457edfdcce0181d0640",
"assets/FontManifest.json": "dc3d03800ccca4601324923c0b1d6d57",
"assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "6d342eb68f170c97609e9da345464e5e",
"assets/shaders/ink_sparkle.frag": "47a605e9ce5724fb017f80e33cc65bd6",
"assets/fonts/MaterialIcons-Regular.otf": "95db9098c58fd6db106f1116bae85a0b",
"macro.py": "5fafb83c2a63167485e3297f7e689d6f"
};

// The application shell files that are downloaded before a service worker can
// start.
const CORE = [
  "main.dart.js",
"index.html",
"assets/AssetManifest.json",
"assets/FontManifest.json"];
// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  self.skipWaiting();
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      return cache.addAll(
        CORE.map((value) => new Request(value, {'cache': 'reload'})));
    })
  );
});

// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');
      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        return;
      }
      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});

// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== 'GET') {
    return;
  }
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (key.indexOf('?v=') != -1) {
    key = key.split('?v=')[0];
  }
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#') || key == '') {
    key = '/';
  }
  // If the URL is not the RESOURCE list then return to signal that the
  // browser should take over.
  if (!RESOURCES[key]) {
    return;
  }
  // If the URL is the index.html, perform an online-first request.
  if (key == '/') {
    return onlineFirst(event);
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache only if the resource was successfully fetched.
        return response || fetch(event.request).then((response) => {
          if (response && Boolean(response.ok)) {
            cache.put(event.request, response.clone());
          }
          return response;
        });
      })
    })
  );
});

self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
    return;
  }
  if (event.data === 'downloadOffline') {
    downloadOffline();
    return;
  }
});

// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey of Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.push(resourceKey);
    }
  }
  return contentCache.addAll(resources);
}

// Attempt to download the resource online before falling back to
// the offline cache.
function onlineFirst(event) {
  return event.respondWith(
    fetch(event.request).then((response) => {
      return caches.open(CACHE_NAME).then((cache) => {
        cache.put(event.request, response.clone());
        return response;
      });
    }).catch((error) => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response != null) {
            return response;
          }
          throw error;
        });
      });
    })
  );
}
