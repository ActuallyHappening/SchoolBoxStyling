# SchoolBoxStyling
Changes the styling of a specific website
