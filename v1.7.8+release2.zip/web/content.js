"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var _a;
// Replaced by macro.py
const PROD = true;
const config = fetch("https://firestore.googleapis.com/v1/projects/better-schoolbox-1f647/databases/(default)/documents/default-config/global")
    .then((resp) => resp.json())
    .then((resp) => {
    const _config = resp.fields;
    const config = {
        "*": _config["*"].stringValue,
        "url-backgrounds": _config["url-backgrounds"].stringValue,
    };
    if (!config["*"]) {
        config["*"] = "enabled";
        console.warn("No config found for *");
    }
    if (!config["url-backgrounds"]) {
        config["url-backgrounds"] = "enabled";
        console.warn("No config found for url-backgrounds");
    }
    console.warn("Config:", config);
    return config;
    // XXX potential runtime checking here
});
const knownKeys = [
    "topBar",
    // "topBarIcons",
    "leftBar",
    "timetableHeaders",
    "background",
    "iconNotifications",
    "nameText",
    // "sectionHeaders",
];
// TODO: Implement text colour changes
/*
--body-foreground-h1-s: 10%;
*/
// TODO: Populate default values for known keys
const _knownDefaults = {
    topBar: {
        querySelector: "nav.tab-bar",
        attribute1: "style",
        attribute2: "background",
        // assignedValue:
        //   document.querySelector("nav.tab-bar")?.style.backgroundColor,
    },
    leftBar: {
        querySelector: "aside#left-menu",
        attribute1: "style",
        attribute2: "background",
        // assignedValue:
        //   document.querySelector("aside#left-menu")?.style.backgroundColor,
    },
    timetableHeaders: {
        querySelector: "table.timetable[data-timetable]>thead>tr>th",
        attribute1: "style",
        attribute2: "background",
        // assignedValue: document.querySelector(
        //   "table.timetable[data-timetable]>thead>tr>th"
        // )?.style.backgroundColor,
    },
    background: {
        querySelector: "body",
        attribute1: "style",
        attribute2: "background",
        // assignedValue:
        //   document.querySelector("body")?.style.backgroundColor ??
        //   "rgb(237, 237, 237)",
    },
    iconNotifications: {
        querySelector: "a.icon-notifications, label#notification-toggle-full",
        attribute1: "style",
        attribute2: "background",
    },
    nameText: {
        querySelector: "h1>strong",
        attribute1: "innerText",
    },
};
/**
 * Default memory units, loaded with actual values from DOM.
 */
const knownDefaults = {};
for (const _key of Object.keys(_knownDefaults)) {
    const key = _key;
    const _none = "NOT FOUND ON DOM!";
    let assignedValue = _none;
    const spec = _knownDefaults[key];
    const Node = document.querySelector(spec.querySelector);
    let computedStyles;
    if (!Node) {
        console.error(`Could not find element with querySelector: ${spec.querySelector}`);
        computedStyles = { background: "initial" };
    }
    else {
        computedStyles = window.getComputedStyle(Node);
    }
    if (spec.attribute2) {
        if (spec.attribute1 !== "style") {
            console.warn("attribute2 is set, but attribute1 is not style\nThis might not work as expected!\nGrabbing from raw _query (DOM node)");
            // @ts-ignore
            assignedValue = Node[spec.attribute1][spec.attribute2];
        }
        else {
            // @ts-ignore
            assignedValue = computedStyles[spec.attribute2];
        }
    }
    else {
        // @ts-ignore
        assignedValue = (Node !== null && Node !== void 0 ? Node : { src: "initial" })[spec.attribute1];
    }
    // console.log("Got assigned value '", assignedValue, "' for key", key);
    knownDefaults[key] = Object.assign(Object.assign({}, _knownDefaults[key]), { assignedValue: assignedValue === _none ? "" : assignedValue });
}
//   {
//     key: "deleteIMGSrc",
//     querySelector: 'img[src][alt="Emmanuel College"]',
//     firstLevelProperty: "srcset",
//     newValWrapper: "$$$",
//     defaultValue: "DELETE",
//   },
const defaultMemory = {};
for (const key of knownKeys) {
    defaultMemory[key] = { domSpec: knownDefaults[key] };
}
for (const key of knownKeys) {
    if (!defaultMemory[key]) {
        console.error(`Key ${key} not found in defaultMemory!`);
    }
    if (!((_a = defaultMemory[key]) === null || _a === void 0 ? void 0 : _a.domSpec)) {
        console.error(`Key ${key} not found in defaultMemorys domSpecs!`);
    }
}
console.log("content.js loaded");
// #region Helpers
/**
 * Usage:
 * ```ts
 * function expensiveFunction() {
 *  // Do something expensive
 * }
 * const cheapFunc = debounce(expensiveFunction, 1000, {debugExecuted: "Expensive function executed", debugBounced: "Expensive function was debounced"});
 * // Or call it directly
 * expensiveFunction() // Immediate
 * cheapFunc() // Debounced
 * ```
 * @param fn Function to be executed
 * @param delay Delay before execution
 */
const debounce = (callback, waitFor, debug) => {
    let timeout;
    return (...args) => {
        let result;
        (debug === null || debug === void 0 ? void 0 : debug.debugBounced) ? console.log(debug === null || debug === void 0 ? void 0 : debug.debugBounced) : null;
        timeout && clearTimeout(timeout);
        timeout = setTimeout(() => {
            var _a;
            console.log((_a = debug === null || debug === void 0 ? void 0 : debug.debugExecuted) !== null && _a !== void 0 ? _a : "& Executed");
            result = callback(...args);
        }, waitFor);
        return result;
    };
};
// #region Cache
const cache = {};
const resetInfo = {};
for (const _key of knownKeys) {
    const key = _key;
    resetInfo[key] = [
        {
            initialSpec: knownDefaults[key],
        },
    ];
}
// XXX: Add other reset info here
// #endregion
// #region Storage manipulation
/**
 * Usage:
 * ```ts
 * const dataUnderKey = await getStorageData("myKey");
 * ```
 *
 * @param key Key to retrieve from storage
 * @returns Promise that resolves to the value stored under the key
 */
const getStorageData = (key) => new Promise((resolve, reject) => chrome.storage.sync.get([key], (result) => {
    var _a;
    let parsedResult;
    if (!result[key]) {
        console.warn("[getStorageData] No data found for key", key, "in storage");
        resolve(undefined);
        return;
    }
    try {
        parsedResult = JSON.parse(result[key]);
    }
    catch (e) {
        console.error("Could not parse result", result, "with key", key);
        reject(e);
        return;
    }
    console.log("[getStorageData] key:", key, "assignedValue", (_a = parsedResult === null || parsedResult === void 0 ? void 0 : parsedResult.domSpec) === null || _a === void 0 ? void 0 : _a.assignedValue, PROD ? "" : "result:", PROD ? "" : parsedResult, PROD ? "" : "raw:", PROD ? "" : result[key], PROD ? "" : "lastError:", PROD ? "" : chrome.runtime.lastError);
    if (!parsedResult) {
        reject(new Error("Parsed result is falsy"));
        return;
    }
    if (!parsedResult.domSpec) {
        reject(new Error("Parsed result has no domSpec"));
        return;
    }
    if (!validateDOMSpecification(parsedResult.domSpec)) {
        reject(new Error("Parsed result has invalid domSpec"));
        return;
    }
    chrome.runtime.lastError
        ? reject(Error(chrome.runtime.lastError.message))
        : resolve(parsedResult);
}));
/**
 * Usage:
 * ```ts
 * await setStorageData("myKey", "newValue");
 * ```
 * Sets the value of `key` to `value` in actual storage.
 * @param data Data to be stored
 * @returns true if good, else rejects
 */
const setStorageData = (key, data) => new Promise((resolve, reject) => {
    const dataToStore = JSON.stringify(data);
    chrome.storage.sync.set({ [key]: dataToStore }, () => {
        console.log("[setStorageData] key:", key, "data:", data, PROD ? "" : "stringified", PROD ? "" : dataToStore, PROD ? "" : "last error:", PROD ? "" : chrome.runtime.lastError, PROD ? "" : "[note]: Checking if storage was set ...");
        if (PROD)
            return;
        // Test
        chrome.storage.sync.get([key], (result) => {
            if (result[key] === dataToStore) {
                console.log("[setStorageData] [test] Successful!!");
                resolve(true);
            }
            else {
                console.error("[setStorageData] [test] Failed!!");
                reject(false);
            }
        });
        chrome.runtime.lastError
            ? reject(Error(chrome.runtime.lastError.message))
            : resolve(true);
    });
});
/**
 * Get a key. Use this function, as it handles caching for you.
 * Returns a MemoryUnit or **undefined** if not found.
 *
 * Will **not** return a default, unless `fillDefaults` is set to true.
 * If this is the case, when undefined is returned, it will be set to the default.
 * The default is found from `defaultMemory[key]`.
 *
 * @param key Key to retrieve from storage
 * @returns The Memory Unit stored (as promise)
 */
function getKey(key, options) {
    return __awaiter(this, void 0, void 0, function* () {
        if (cache[key]) {
            return cache[key];
        }
        else {
            console.warn("Key", key, "not found in cache. Searching storage...");
            const d = yield getStorageData(key);
            if (d) {
                cache[key] = d;
                return d;
            }
            else {
                if (options === null || options === void 0 ? void 0 : options.fillDefaults) {
                    console.warn("Key", key, "not found in storage. Setting default value");
                    const defaultMem = defaultMemory[key];
                    // setStorageData(key, defaultMem);
                    cache[key] = defaultMem;
                    return defaultMem;
                }
                else {
                    console.warn("Key", key, "not found in storage. Returning undefined");
                    return undefined;
                }
            }
        }
    });
}
const _setKeyList = knownKeys.map((key) => {
    return debounce(setStorageData, 1000, {
        debugExecuted: `Set '${key}' EXECUTED`,
        debugBounced: `Set '${key}' debounced`,
    });
});
const _setKey = _setKeyList.reduce((previousValue, currentValue, i) => {
    previousValue[knownKeys[i]] = currentValue;
    return previousValue;
}, {});
console.info("Set key", _setKey);
/**
 * Sets the desired `key`s (`domSpec`) `property` (commonly `assignedValue`) to `value` in storage,
 * note this *uses a cache*.
 *
 * ## Use this function, as it will properly update the DOM.
 * ### Note: this will set the `assignedValue` property on the internal `MemoryUnit.domSpec` object by default. To set the `domSpec` property, repeatedly call this function
 *
 *
 * Usage:
 * ```ts
 * await setKey("topbar", "new colour", "assignedValue");
 * ```
 * @param key Key to set
 * @param value Value to set key to
 */
function setKey(key, value, property = "assignedValue") {
    return __awaiter(this, void 0, void 0, function* () {
        const _config = yield config;
        if ((value === null || value === void 0 ? void 0 : value.includes("url")) && _config["url-backgrounds"] != "enabled") {
            console.error("Extension URL images disabled: ", _config["url-backgrounds"], "");
            return;
        }
        if (!cache[key]) {
            console.warn("Key", key, "not found in cache during call to `setKey`.\nThe cache should be the source of truth, as storage is slow.\nTo fix this, load the cache with all desired values from storage. This is usually done automatically when `content.ts` is first loaded.\nAutomatically calling `getKey` to load the cache (this is an implementation detail fix) ...");
            cache[key] = yield getKey(key, { fillDefaults: true });
        }
        // TODO: unmounting logic could go here
        // E.g. resetting the DOM to the initial state, then re-adding the new DOM
        // This would allow changes such as to `querySelector` to work as expected
        cache[key].domSpec[property] = value;
        _setKey[key](key, cache[key]); // Debounces
        // Update DOM
        executeDOMSpecification(cache[key].domSpec);
    });
}
/**
 * Handles a user request, including the reset logic and using `setKey` to update the DOM.
 * @param request Request to handle
 */
function handleUserRequest(request) {
    const key = request.key;
    const action = request.do;
    if (action === "RESET") {
        console.log("Handling RESET request for request: ", request);
        if (!resetInfo[key]) {
            console.warn(`Reset info not found for key '${key}' during reset.\nThis is probably a bug. When initializing, remember to capture the initial DOM state.\nDoing nothing.`);
            return;
        }
        // Loop through each initialSpec
        resetInfo[key].forEach((info) => {
            const initial = info.initialSpec;
            // Loop through initial, and set each property
            for (const _property in initial) {
                const property = _property;
                console.log(`Setting ${key}.${property} to ${initial[property]}`);
                setKey(key, initial[property], property);
            }
        });
    }
    else {
        console.log("Handling request:", request);
        setKey(key, action.newAssignedValue);
    }
}
function _updateElem(elem, spec) {
    if (spec.attribute2) {
        // @ts-ignore
        elem[spec.attribute1][spec.attribute2] = "initial";
        // @ts-ignore
        elem[spec.attribute1][spec.attribute2] = spec.assignedValue;
        // console.log(
        //   "[_updateElem] Set attribute2",
        //   spec.attribute2,
        //   "of",
        //   elem,
        //   "to",
        //   spec.assignedValue
        // );
    }
    else {
        console.log("[_updateElem] setting attribute1", spec.attribute1, "of", elem, "to", spec.assignedValue);
        // @ts-ignore
        elem[spec.attribute1] = spec.assignedValue;
    }
}
function executeDOMSpecification(spec) {
    config.then((config) => {
        if (config["*"] != "enabled") {
            console.error("Not going to update the DOM, because the extension is disabled FULLY");
            throw new Error("Extension (fully) disabled: " + config["*"]);
        }
        if (!spec) {
            console.warn("No DOM specification provided. Doing nothing.");
            return;
        }
        if (!(spec === null || spec === void 0 ? void 0 : spec.querySelector)) {
            console.error("No querySelector found in spec:", spec);
            return;
        }
        queryMany(spec.querySelector, (elem) => {
            _updateElem(elem, spec);
        });
    });
}
function queryMany(querySelector, callback) {
    const elements = document.querySelectorAll(querySelector);
    if (elements.length == 0) {
        console.warn(`Did query for '${querySelector}', but matched nothing.\nTry copy pasting this into your browser:\ndocument.querySelectedAll("${querySelector}")\nIf nothing is returned, you may have made a mistake with your query selector.\nRemember to split multiple selectors with commas, like 'nav-bar, #id, .class'`);
    }
    elements.forEach(callback);
}
// #endregion
// #region Runtime Validation
function validateDOMSpecification(spec) {
    if (!spec) {
        console.error("No DOM specification provided. Doing nothing.");
        return false;
    }
    if (!(spec === null || spec === void 0 ? void 0 : spec.querySelector)) {
        console.error("No querySelector found in spec:", spec);
        return false;
    }
    if (!(spec === null || spec === void 0 ? void 0 : spec.attribute1)) {
        console.error("No attribute1 found in spec:", spec);
        return false;
    }
    if (!(spec === null || spec === void 0 ? void 0 : spec.assignedValue)) {
        console.error("No assignedValue found in spec:", spec);
        return false;
    }
    return true;
}
// #endregion
// #region Execution
chrome.storage.sync.get(null, (everything) => {
    var _a, _b, _c;
    if (!everything) {
        console.warn("[initial] No storage found");
        return;
    }
    for (const storageKey in everything) {
        const key = storageKey;
        let _parsed;
        try {
            _parsed = JSON.parse(everything[key]);
        }
        catch (e) {
            console.error(`Failed to parse JSON for key '${key}'\nValue: ${everything[key]}; e:`, e);
            continue;
        }
        const value = _parsed;
        if (!key) {
            console.warn("[initial] No storage key found", key, value);
            continue;
        }
        if (!value) {
            console.warn("[initial] No storage value found", key, value);
            continue;
        }
        if (knownKeys.indexOf(key) == -1) {
            console.warn(`[initial] Key '${key}' found in storage, but not in knownKeys.\nThis is probably a bug.\nValue:`, value);
        }
        if (!validateDOMSpecification(value.domSpec)) {
            const MANUAL_newValue = console.warn(`[initial] Invalid DOM specification found for key '${key}' in initial storage fetch.\nThis is probably a bug.\nValue:`, value, "\nSetting a default value, [fatal] this will override any valid settings data under key", key, "[manual implementation] Setting to");
            chrome.storage.sync.set({
                [key]: JSON.stringify(defaultMemory[key]),
            });
            continue;
        }
        cache[key] = value;
        // Validating value's properties against defaults
        if (((_a = value === null || value === void 0 ? void 0 : value.domSpec) === null || _a === void 0 ? void 0 : _a.querySelector) !==
            ((_c = (_b = defaultMemory[key]) === null || _b === void 0 ? void 0 : _b.domSpec) === null || _c === void 0 ? void 0 : _c.querySelector)) {
            console.warn(`Key '${key}' has a different querySelector than the default.\nThis is probably a bug.\nValue:`, value);
        }
        // Use official means, including updating the DOM
        const newValue = value === null || value === void 0 ? void 0 : value.domSpec.assignedValue;
        setKey(key, newValue);
    }
});
// // Retrieve data from chrome storage and put into cache
// knownKeys.forEach(async (key) => {
//   // Populate cache
//   const data = await getStorageData(key);
//   if (cache[key]) {
//     console.warn(
//       "Overwriting cache for key",
//       key,
//       "because it is initial run.\nThis could happen when duplicate items in `kno wnKeys` list exist."
//     );
//   }
//   console.log(
//     "[initial] Setting cache for key",
//     key,
//     "to assignedValue",
//     data?.domSpec?.assignedValue,
//     "domSpec",
//     data?.domSpec,
//     PROD ? "" : "data:",
//     PROD ? "" : data
//   );
//   cache[key] = data;
//   executeDOMSpecification(data!.domSpec);
// });
// Listen for messages from popup.ts
chrome.runtime.onMessage.addListener((request) => {
    if (!request.__is_user_request) {
        console.warn("Received message from popup.ts, but it was not a user request.\nIgnoring.", request);
        return;
    }
    handleUserRequest(request);
});
// #endregion
// #region 1/10000 rick astley rick roll
// const insertionPoint = document.querySelector("#container");
// const rickRoll = document.createElement("iframe");
// rickRoll.src = "https://www.youtube.com/embed/dQw4w9WgXcQ?autoplay=1&mute=1";
// rickRoll.style.height = "60vh";
// insertionPoint?.insertBefore(rickRoll, insertionPoint.firstChild);
// #endregion
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udGVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImNvbnRlbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0FBQUEsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDO0FBUWxCLE1BQU0sTUFBTSxHQUFvQixLQUFLLENBQ25DLHlIQUF5SCxDQUMxSDtLQUNFLElBQUksQ0FBQyxDQUFDLElBQUksRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO0tBQzNCLElBQUksQ0FBQyxDQUFDLElBQUksRUFBRSxFQUFFO0lBQ2IsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLE1BQWtELENBQUM7SUFDeEUsTUFBTSxNQUFNLEdBQVc7UUFDckIsR0FBRyxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxXQUFXO1FBQzdCLGlCQUFpQixFQUFFLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLFdBQVc7S0FDMUQsQ0FBQztJQUNGLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEVBQUU7UUFDaEIsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLFNBQVMsQ0FBQztRQUN4QixPQUFPLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLENBQUM7S0FDdkM7SUFDRCxJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEVBQUU7UUFDOUIsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsU0FBUyxDQUFDO1FBQ3RDLE9BQU8sQ0FBQyxJQUFJLENBQUMscUNBQXFDLENBQUMsQ0FBQztLQUNyRDtJQUNELE9BQU8sQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxDQUFDO0lBQ2hDLE9BQU8sTUFBTSxDQUFDO0lBQ2Qsc0NBQXNDO0FBQ3hDLENBQUMsQ0FBQyxDQUFDO0FBcUJMLE1BQU0sU0FBUyxHQUFHO0lBQ2hCLFFBQVE7SUFDUixpQkFBaUI7SUFDakIsU0FBUztJQUNULGtCQUFrQjtJQUNsQixZQUFZO0lBRVosbUJBQW1CO0lBQ25CLFVBQVU7SUFFVixvQkFBb0I7Q0FDWixDQUFDO0FBR1gsc0NBQXNDO0FBQ3RDOztFQUVFO0FBRUYsK0NBQStDO0FBRS9DLE1BQU0sY0FBYyxHQUdoQjtJQUNGLE1BQU0sRUFBRTtRQUNOLGFBQWEsRUFBRSxhQUFhO1FBQzVCLFVBQVUsRUFBRSxPQUFPO1FBQ25CLFVBQVUsRUFBRSxZQUFZO1FBQ3hCLGlCQUFpQjtRQUNqQixrRUFBa0U7S0FDbkU7SUFDRCxPQUFPLEVBQUU7UUFDUCxhQUFhLEVBQUUsaUJBQWlCO1FBQ2hDLFVBQVUsRUFBRSxPQUFPO1FBQ25CLFVBQVUsRUFBRSxZQUFZO1FBQ3hCLGlCQUFpQjtRQUNqQixzRUFBc0U7S0FDdkU7SUFDRCxnQkFBZ0IsRUFBRTtRQUNoQixhQUFhLEVBQUUsNkNBQTZDO1FBQzVELFVBQVUsRUFBRSxPQUFPO1FBQ25CLFVBQVUsRUFBRSxZQUFZO1FBQ3hCLHlDQUF5QztRQUN6QyxrREFBa0Q7UUFDbEQsNEJBQTRCO0tBQzdCO0lBQ0QsVUFBVSxFQUFFO1FBQ1YsYUFBYSxFQUFFLE1BQU07UUFDckIsVUFBVSxFQUFFLE9BQU87UUFDbkIsVUFBVSxFQUFFLFlBQVk7UUFDeEIsaUJBQWlCO1FBQ2pCLDZEQUE2RDtRQUM3RCwwQkFBMEI7S0FDM0I7SUFDRCxpQkFBaUIsRUFBRTtRQUNqQixhQUFhLEVBQUUsc0RBQXNEO1FBQ3JFLFVBQVUsRUFBRSxPQUFPO1FBQ25CLFVBQVUsRUFBRSxZQUFZO0tBQ3pCO0lBQ0QsUUFBUSxFQUFFO1FBQ1IsYUFBYSxFQUFFLFdBQVc7UUFDMUIsVUFBVSxFQUFFLFdBQVc7S0FDeEI7Q0FDRixDQUFDO0FBRUY7O0dBRUc7QUFDSCxNQUFNLGFBQWEsR0FBdUMsRUFBUyxDQUFDO0FBQ3BFLEtBQUssTUFBTSxJQUFJLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsRUFBRTtJQUM5QyxNQUFNLEdBQUcsR0FBRyxJQUFpQixDQUFDO0lBQzlCLE1BQU0sS0FBSyxHQUFHLG1CQUFtQixDQUFDO0lBQ2xDLElBQUksYUFBYSxHQUFzQyxLQUFLLENBQUM7SUFFN0QsTUFBTSxJQUFJLEdBQUcsY0FBYyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ2pDLE1BQU0sSUFBSSxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0lBQ3hELElBQUksY0FBYyxDQUFDO0lBQ25CLElBQUksQ0FBQyxJQUFJLEVBQUU7UUFDVCxPQUFPLENBQUMsS0FBSyxDQUNYLDhDQUE4QyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQ25FLENBQUM7UUFDRixjQUFjLEdBQUcsRUFBRSxVQUFVLEVBQUUsU0FBUyxFQUFFLENBQUM7S0FDNUM7U0FBTTtRQUNMLGNBQWMsR0FBRyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLENBQUM7S0FDaEQ7SUFFRCxJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUU7UUFDbkIsSUFBSSxJQUFJLENBQUMsVUFBVSxLQUFLLE9BQU8sRUFBRTtZQUMvQixPQUFPLENBQUMsSUFBSSxDQUNWLHVIQUF1SCxDQUN4SCxDQUFDO1lBQ0YsYUFBYTtZQUNiLGFBQWEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztTQUN4RDthQUFNO1lBQ0wsYUFBYTtZQUNiLGFBQWEsR0FBRyxjQUFjLENBQUMsSUFBSSxDQUFDLFVBQVcsQ0FBQyxDQUFDO1NBQ2xEO0tBQ0Y7U0FBTTtRQUNMLGFBQWE7UUFDYixhQUFhLEdBQUcsQ0FBQyxJQUFJLGFBQUosSUFBSSxjQUFKLElBQUksR0FBSSxFQUFFLEdBQUcsRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztLQUMvRDtJQUVELHdFQUF3RTtJQUV4RSxhQUFhLENBQUMsR0FBRyxDQUFDLG1DQUNiLGNBQWMsQ0FBQyxHQUFHLENBQUMsS0FDdEIsYUFBYSxFQUFFLGFBQWEsS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsYUFBYSxHQUM1RCxDQUFDO0NBQ0g7QUFDRCxNQUFNO0FBQ04sMkJBQTJCO0FBQzNCLHlEQUF5RDtBQUN6RCxvQ0FBb0M7QUFDcEMsNEJBQTRCO0FBQzVCLDhCQUE4QjtBQUM5QixPQUFPO0FBRVAsTUFBTSxhQUFhLEdBQXFCLEVBQVMsQ0FBQztBQUNsRCxLQUFLLE1BQU0sR0FBRyxJQUFJLFNBQVMsRUFBRTtJQUMzQixhQUFhLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxPQUFPLEVBQUUsYUFBYSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUM7Q0FDdEQ7QUFDRCxLQUFLLE1BQU0sR0FBRyxJQUFJLFNBQVMsRUFBRTtJQUMzQixJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxFQUFFO1FBQ3ZCLE9BQU8sQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLDhCQUE4QixDQUFDLENBQUM7S0FDekQ7SUFDRCxJQUFJLENBQUMsQ0FBQSxNQUFBLGFBQWEsQ0FBQyxHQUFHLENBQUMsMENBQUUsT0FBTyxDQUFBLEVBQUU7UUFDaEMsT0FBTyxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsd0NBQXdDLENBQUMsQ0FBQztLQUNuRTtDQUNGO0FBRUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO0FBRWpDLGtCQUFrQjtBQUVsQjs7Ozs7Ozs7Ozs7OztHQWFHO0FBQ0gsTUFBTSxRQUFRLEdBQUcsQ0FDZixRQUFXLEVBQ1gsT0FBZSxFQUNmLEtBQXlELEVBQ3pELEVBQUU7SUFDRixJQUFJLE9BQXNDLENBQUM7SUFDM0MsT0FBTyxDQUFDLEdBQUcsSUFBbUIsRUFBaUIsRUFBRTtRQUMvQyxJQUFJLE1BQVcsQ0FBQztRQUNoQixDQUFBLEtBQUssYUFBTCxLQUFLLHVCQUFMLEtBQUssQ0FBRSxZQUFZLEVBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxhQUFMLEtBQUssdUJBQUwsS0FBSyxDQUFFLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7UUFDOUQsT0FBTyxJQUFJLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUNqQyxPQUFPLEdBQUcsVUFBVSxDQUFDLEdBQUcsRUFBRTs7WUFDeEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFBLEtBQUssYUFBTCxLQUFLLHVCQUFMLEtBQUssQ0FBRSxhQUFhLG1DQUFJLFlBQVksQ0FBQyxDQUFDO1lBQ2xELE1BQU0sR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQztRQUM3QixDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDWixPQUFPLE1BQU0sQ0FBQztJQUNoQixDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUF3QkYsZ0JBQWdCO0FBRWhCLE1BQU0sS0FBSyxHQUF1QixFQUFFLENBQUM7QUFhckMsTUFBTSxTQUFTLEdBQXdCLEVBQUUsQ0FBQztBQUUxQyxLQUFLLE1BQU0sSUFBSSxJQUFJLFNBQVMsRUFBRTtJQUM1QixNQUFNLEdBQUcsR0FBRyxJQUFpQixDQUFDO0lBQzlCLFNBQVMsQ0FBQyxHQUFHLENBQUMsR0FBRztRQUNmO1lBQ0UsV0FBVyxFQUFFLGFBQWEsQ0FBQyxHQUFHLENBQUM7U0FDaEM7S0FDRixDQUFDO0NBQ0g7QUFDRCxpQ0FBaUM7QUFFakMsYUFBYTtBQUViLCtCQUErQjtBQUUvQjs7Ozs7Ozs7R0FRRztBQUNILE1BQU0sY0FBYyxHQUFHLENBQUMsR0FBYyxFQUFtQyxFQUFFLENBQ3pFLElBQUksT0FBTyxDQUFDLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxFQUFFLENBQzlCLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsTUFBTSxFQUFFLEVBQUU7O0lBQ3hDLElBQUksWUFBd0IsQ0FBQztJQUM3QixJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxFQUFFO1FBQ2hCLE9BQU8sQ0FBQyxJQUFJLENBQ1Ysd0NBQXdDLEVBQ3hDLEdBQUcsRUFDSCxZQUFZLENBQ2IsQ0FBQztRQUNGLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUNuQixPQUFPO0tBQ1I7SUFDRCxJQUFJO1FBQ0YsWUFBWSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBUSxDQUFDLENBQUM7S0FDL0M7SUFBQyxPQUFPLENBQUMsRUFBRTtRQUNWLE9BQU8sQ0FBQyxLQUFLLENBQUMsd0JBQXdCLEVBQUUsTUFBTSxFQUFFLFVBQVUsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNqRSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDVixPQUFPO0tBQ1I7SUFDRCxPQUFPLENBQUMsR0FBRyxDQUNULHVCQUF1QixFQUN2QixHQUFHLEVBQ0gsZUFBZSxFQUNmLE1BQUEsWUFBWSxhQUFaLFlBQVksdUJBQVosWUFBWSxDQUFFLE9BQU8sMENBQUUsYUFBYSxFQUNwQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsU0FBUyxFQUNyQixJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsWUFBWSxFQUN4QixJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUNsQixJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxFQUN2QixJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsWUFBWSxFQUN4QixJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQ3JDLENBQUM7SUFDRixJQUFJLENBQUMsWUFBWSxFQUFFO1FBQ2pCLE1BQU0sQ0FBQyxJQUFJLEtBQUssQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDLENBQUM7UUFDNUMsT0FBTztLQUNSO0lBQ0QsSUFBSSxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUU7UUFDekIsTUFBTSxDQUFDLElBQUksS0FBSyxDQUFDLDhCQUE4QixDQUFDLENBQUMsQ0FBQztRQUNsRCxPQUFPO0tBQ1I7SUFDRCxJQUFJLENBQUMsd0JBQXdCLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxFQUFFO1FBQ25ELE1BQU0sQ0FBQyxJQUFJLEtBQUssQ0FBQyxtQ0FBbUMsQ0FBQyxDQUFDLENBQUM7UUFDdkQsT0FBTztLQUNSO0lBRUQsTUFBTSxDQUFDLE9BQU8sQ0FBQyxTQUFTO1FBQ3RCLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ2pELENBQUMsQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7QUFDNUIsQ0FBQyxDQUFDLENBQ0gsQ0FBQztBQUVKOzs7Ozs7OztHQVFHO0FBQ0gsTUFBTSxjQUFjLEdBQUcsQ0FBQyxHQUFjLEVBQUUsSUFBZ0IsRUFBb0IsRUFBRSxDQUM1RSxJQUFJLE9BQU8sQ0FBQyxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsRUFBRTtJQUM5QixNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ3pDLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsV0FBVyxFQUFFLEVBQUUsR0FBRyxFQUFFO1FBQ25ELE9BQU8sQ0FBQyxHQUFHLENBQ1QsdUJBQXVCLEVBQ3ZCLEdBQUcsRUFDSCxPQUFPLEVBQ1AsSUFBSSxFQUNKLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxhQUFhLEVBQ3pCLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxXQUFXLEVBQ3ZCLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxhQUFhLEVBQ3pCLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFDcEMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLHlDQUF5QyxDQUN0RCxDQUFDO1FBQ0YsSUFBSSxJQUFJO1lBQUUsT0FBTztRQUNqQixPQUFPO1FBQ1AsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxNQUFNLEVBQUUsRUFBRTtZQUN4QyxJQUFJLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSyxXQUFXLEVBQUU7Z0JBQy9CLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0NBQXNDLENBQUMsQ0FBQztnQkFDcEQsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ2Y7aUJBQU07Z0JBQ0wsT0FBTyxDQUFDLEtBQUssQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFDO2dCQUNsRCxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDZjtRQUNILENBQUMsQ0FBQyxDQUFDO1FBQ0gsTUFBTSxDQUFDLE9BQU8sQ0FBQyxTQUFTO1lBQ3RCLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ2pELENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDcEIsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQztBQUVMOzs7Ozs7Ozs7O0dBVUc7QUFDSCxTQUFlLE1BQU0sQ0FDbkIsR0FBYyxFQUNkLE9BQW1DOztRQUVuQyxJQUFJLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUNkLE9BQU8sS0FBSyxDQUFDLEdBQUcsQ0FBRSxDQUFDO1NBQ3BCO2FBQU07WUFDTCxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxHQUFHLEVBQUUsMENBQTBDLENBQUMsQ0FBQztZQUNyRSxNQUFNLENBQUMsR0FBRyxNQUFNLGNBQWMsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNwQyxJQUFJLENBQUMsRUFBRTtnQkFDTCxLQUFLLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNmLE9BQU8sQ0FBQyxDQUFDO2FBQ1Y7aUJBQU07Z0JBQ0wsSUFBSSxPQUFPLGFBQVAsT0FBTyx1QkFBUCxPQUFPLENBQUUsWUFBWSxFQUFFO29CQUN6QixPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxHQUFHLEVBQUUsNkNBQTZDLENBQUMsQ0FBQztvQkFDeEUsTUFBTSxVQUFVLEdBQUcsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUN0QyxtQ0FBbUM7b0JBQ25DLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxVQUFVLENBQUM7b0JBQ3hCLE9BQU8sVUFBVSxDQUFDO2lCQUNuQjtxQkFBTTtvQkFDTCxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxHQUFHLEVBQUUsMkNBQTJDLENBQUMsQ0FBQztvQkFDdEUsT0FBTyxTQUFTLENBQUM7aUJBQ2xCO2FBQ0Y7U0FDRjtJQUNILENBQUM7Q0FBQTtBQUVELE1BQU0sV0FBVyxHQUE0QixTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLEVBQUU7SUFDakUsT0FBTyxRQUFRLENBQUMsY0FBYyxFQUFFLElBQUksRUFBRTtRQUNwQyxhQUFhLEVBQUUsUUFBUSxHQUFHLFlBQVk7UUFDdEMsWUFBWSxFQUFFLFFBQVEsR0FBRyxhQUFhO0tBQ3ZDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDO0FBQ0gsTUFBTSxPQUFPLEdBQTZDLFdBQVcsQ0FBQyxNQUFNLENBQzFFLENBQUMsYUFBYSxFQUFFLFlBQVksRUFBRSxDQUFDLEVBQUUsRUFBRTtJQUNqQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsWUFBWSxDQUFDO0lBQzNDLE9BQU8sYUFBYSxDQUFDO0FBQ3ZCLENBQUMsRUFDRCxFQUFTLENBQ1YsQ0FBQztBQUVGLE9BQU8sQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO0FBRWpDOzs7Ozs7Ozs7Ozs7OztHQWNHO0FBQ0gsU0FBZSxNQUFNLENBR25CLEdBQWMsRUFDZCxLQUFzQyxFQUN0QyxXQUFxQixlQUFzQjs7UUFFM0MsTUFBTSxPQUFPLEdBQUcsTUFBTSxNQUFNLENBQUM7UUFDN0IsSUFBSSxDQUFBLEtBQUssYUFBTCxLQUFLLHVCQUFMLEtBQUssQ0FBRSxRQUFRLENBQUMsS0FBSyxDQUFDLEtBQUksT0FBTyxDQUFDLGlCQUFpQixDQUFDLElBQUksU0FBUyxFQUFFO1lBQ3JFLE9BQU8sQ0FBQyxLQUFLLENBQ1gsaUNBQWlDLEVBQ2pDLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxFQUMxQixFQUFFLENBQ0gsQ0FBQztZQUNGLE9BQU87U0FDUjtRQUVELElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDZixPQUFPLENBQUMsSUFBSSxDQUNWLEtBQUssRUFDTCxHQUFHLEVBQ0gsaVZBQWlWLENBQ2xWLENBQUM7WUFDRixLQUFLLENBQUMsR0FBRyxDQUFDLEdBQUcsTUFBTSxNQUFNLENBQUMsR0FBRyxFQUFFLEVBQUUsWUFBWSxFQUFFLElBQUksRUFBRSxDQUFDLENBQUM7U0FDeEQ7UUFFRCx1Q0FBdUM7UUFDdkMsMEVBQTBFO1FBQzFFLDBFQUEwRTtRQUUxRSxLQUFLLENBQUMsR0FBRyxDQUFFLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxHQUFHLEtBQUssQ0FBQztRQUN0QyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxHQUFHLENBQUUsQ0FBQyxDQUFDLENBQUMsWUFBWTtRQUU1QyxhQUFhO1FBQ2IsdUJBQXVCLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQy9DLENBQUM7Q0FBQTtBQXdCRDs7O0dBR0c7QUFDSCxTQUFTLGlCQUFpQixDQUFDLE9BQW9CO0lBQzdDLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUM7SUFDeEIsTUFBTSxNQUFNLEdBQUcsT0FBTyxDQUFDLEVBQUUsQ0FBQztJQUMxQixJQUFJLE1BQU0sS0FBSyxPQUFPLEVBQUU7UUFDdEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQ0FBc0MsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUM3RCxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQ25CLE9BQU8sQ0FBQyxJQUFJLENBQ1YsaUNBQWlDLEdBQUcsd0hBQXdILENBQzdKLENBQUM7WUFDRixPQUFPO1NBQ1I7UUFDRCxnQ0FBZ0M7UUFDaEMsU0FBUyxDQUFDLEdBQUcsQ0FBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksRUFBRSxFQUFFO1lBQy9CLE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUM7WUFDakMsOENBQThDO1lBQzlDLEtBQUssTUFBTSxTQUFTLElBQUksT0FBTyxFQUFFO2dCQUMvQixNQUFNLFFBQVEsR0FBRyxTQUFpQyxDQUFDO2dCQUVuRCxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsR0FBRyxJQUFJLFFBQVEsT0FBTyxPQUFPLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUVsRSxNQUFNLENBQUMsR0FBRyxFQUFFLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQzthQUMxQztRQUNILENBQUMsQ0FBQyxDQUFDO0tBQ0o7U0FBTTtRQUNMLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDMUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxNQUFNLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztLQUN0QztBQUNILENBQUM7QUFzQkQsU0FBUyxXQUFXLENBQUMsSUFBVSxFQUFFLElBQXNCO0lBQ3JELElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRTtRQUNuQixhQUFhO1FBQ2IsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsU0FBUyxDQUFDO1FBQ25ELGFBQWE7UUFDYixJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO1FBRTVELGVBQWU7UUFDZixvQ0FBb0M7UUFDcEMscUJBQXFCO1FBQ3JCLFVBQVU7UUFDVixVQUFVO1FBQ1YsVUFBVTtRQUNWLHVCQUF1QjtRQUN2QixLQUFLO0tBQ047U0FBTTtRQUNMLE9BQU8sQ0FBQyxHQUFHLENBQ1Qsa0NBQWtDLEVBQ2xDLElBQUksQ0FBQyxVQUFVLEVBQ2YsSUFBSSxFQUNKLElBQUksRUFDSixJQUFJLEVBQ0osSUFBSSxDQUFDLGFBQWEsQ0FDbkIsQ0FBQztRQUNGLGFBQWE7UUFDYixJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUM7S0FDNUM7QUFDSCxDQUFDO0FBRUQsU0FBUyx1QkFBdUIsQ0FBQyxJQUFzQjtJQUNyRCxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxFQUFFLEVBQUU7UUFDckIsSUFBSSxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksU0FBUyxFQUFFO1lBQzVCLE9BQU8sQ0FBQyxLQUFLLENBQ1gsc0VBQXNFLENBQ3ZFLENBQUM7WUFDRixNQUFNLElBQUksS0FBSyxDQUFDLDhCQUE4QixHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1NBQy9EO1FBQ0QsSUFBSSxDQUFDLElBQUksRUFBRTtZQUNULE9BQU8sQ0FBQyxJQUFJLENBQUMsK0NBQStDLENBQUMsQ0FBQztZQUM5RCxPQUFPO1NBQ1I7UUFDRCxJQUFJLENBQUMsQ0FBQSxJQUFJLGFBQUosSUFBSSx1QkFBSixJQUFJLENBQUUsYUFBYSxDQUFBLEVBQUU7WUFDeEIsT0FBTyxDQUFDLEtBQUssQ0FBQyxpQ0FBaUMsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUN2RCxPQUFPO1NBQ1I7UUFDRCxTQUFTLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDLElBQUksRUFBRSxFQUFFO1lBQ3JDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDMUIsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUM7QUFFRCxTQUFTLFNBQVMsQ0FBQyxhQUFxQixFQUFFLFFBQThCO0lBQ3RFLE1BQU0sUUFBUSxHQUFHLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUMxRCxJQUFJLFFBQVEsQ0FBQyxNQUFNLElBQUksQ0FBQyxFQUFFO1FBQ3hCLE9BQU8sQ0FBQyxJQUFJLENBQ1Ysa0JBQWtCLGFBQWEsaUdBQWlHLGFBQWEsa0tBQWtLLENBQ2hULENBQUM7S0FDSDtJQUNELFFBQVEsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDN0IsQ0FBQztBQUVELGFBQWE7QUFFYiw2QkFBNkI7QUFFN0IsU0FBUyx3QkFBd0IsQ0FBQyxJQUFzQjtJQUN0RCxJQUFJLENBQUMsSUFBSSxFQUFFO1FBQ1QsT0FBTyxDQUFDLEtBQUssQ0FBQywrQ0FBK0MsQ0FBQyxDQUFDO1FBQy9ELE9BQU8sS0FBSyxDQUFDO0tBQ2Q7SUFDRCxJQUFJLENBQUMsQ0FBQSxJQUFJLGFBQUosSUFBSSx1QkFBSixJQUFJLENBQUUsYUFBYSxDQUFBLEVBQUU7UUFDeEIsT0FBTyxDQUFDLEtBQUssQ0FBQyxpQ0FBaUMsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUN2RCxPQUFPLEtBQUssQ0FBQztLQUNkO0lBQ0QsSUFBSSxDQUFDLENBQUEsSUFBSSxhQUFKLElBQUksdUJBQUosSUFBSSxDQUFFLFVBQVUsQ0FBQSxFQUFFO1FBQ3JCLE9BQU8sQ0FBQyxLQUFLLENBQUMsOEJBQThCLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDcEQsT0FBTyxLQUFLLENBQUM7S0FDZDtJQUNELElBQUksQ0FBQyxDQUFBLElBQUksYUFBSixJQUFJLHVCQUFKLElBQUksQ0FBRSxhQUFhLENBQUEsRUFBRTtRQUN4QixPQUFPLENBQUMsS0FBSyxDQUFDLGlDQUFpQyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3ZELE9BQU8sS0FBSyxDQUFDO0tBQ2Q7SUFDRCxPQUFPLElBQUksQ0FBQztBQUNkLENBQUM7QUFFRCxhQUFhO0FBRWIsb0JBQW9CO0FBQ3BCLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxVQUFrQyxFQUFFLEVBQUU7O0lBQ25FLElBQUksQ0FBQyxVQUFVLEVBQUU7UUFDZixPQUFPLENBQUMsSUFBSSxDQUFDLDRCQUE0QixDQUFDLENBQUM7UUFDM0MsT0FBTztLQUNSO0lBQ0QsS0FBSyxNQUFNLFVBQVUsSUFBSSxVQUFVLEVBQUU7UUFDbkMsTUFBTSxHQUFHLEdBQUcsVUFBdUIsQ0FBQztRQUNwQyxJQUFJLE9BQU8sQ0FBQztRQUNaLElBQUk7WUFDRixPQUFPLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztTQUN2QztRQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQ1YsT0FBTyxDQUFDLEtBQUssQ0FDWCxpQ0FBaUMsR0FBRyxhQUFhLFVBQVUsQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUN0RSxDQUFDLENBQ0YsQ0FBQztZQUNGLFNBQVM7U0FDVjtRQUNELE1BQU0sS0FBSyxHQUFHLE9BQXFCLENBQUM7UUFFcEMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNSLE9BQU8sQ0FBQyxJQUFJLENBQUMsZ0NBQWdDLEVBQUUsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQzNELFNBQVM7U0FDVjtRQUVELElBQUksQ0FBQyxLQUFLLEVBQUU7WUFDVixPQUFPLENBQUMsSUFBSSxDQUFDLGtDQUFrQyxFQUFFLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUM3RCxTQUFTO1NBQ1Y7UUFFRCxJQUFJLFNBQVMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUU7WUFDaEMsT0FBTyxDQUFDLElBQUksQ0FDVixrQkFBa0IsR0FBRyw0RUFBNEUsRUFDakcsS0FBSyxDQUNOLENBQUM7U0FDSDtRQUVELElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFDNUMsTUFBTSxlQUFlLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FDbEMsc0RBQXNELEdBQUcsOERBQThELEVBQ3ZILEtBQUssRUFDTCx5RkFBeUYsRUFDekYsR0FBRyxFQUNILG9DQUFvQyxDQUNyQyxDQUFDO1lBQ0YsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO2dCQUN0QixDQUFDLEdBQUcsQ0FBQyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2FBQzFDLENBQUMsQ0FBQztZQUVILFNBQVM7U0FDVjtRQUVELEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxLQUFLLENBQUM7UUFFbkIsaURBQWlEO1FBQ2pELElBQ0UsQ0FBQSxNQUFBLEtBQUssYUFBTCxLQUFLLHVCQUFMLEtBQUssQ0FBRSxPQUFPLDBDQUFFLGFBQWE7YUFDN0IsTUFBQSxNQUFBLGFBQWEsQ0FBQyxHQUFHLENBQUMsMENBQUUsT0FBTywwQ0FBRSxhQUFhLENBQUEsRUFDMUM7WUFDQSxPQUFPLENBQUMsSUFBSSxDQUNWLFFBQVEsR0FBRyxvRkFBb0YsRUFDL0YsS0FBSyxDQUNOLENBQUM7U0FDSDtRQUVELGlEQUFpRDtRQUVqRCxNQUFNLFFBQVEsR0FBRyxLQUFLLGFBQUwsS0FBSyx1QkFBTCxLQUFLLENBQUUsT0FBTyxDQUFDLGFBQWEsQ0FBQztRQUM5QyxNQUFNLENBQUMsR0FBRyxFQUFFLFFBQVEsQ0FBQyxDQUFDO0tBQ3ZCO0FBQ0gsQ0FBQyxDQUFDLENBQUM7QUFFSCwwREFBMEQ7QUFDMUQscUNBQXFDO0FBQ3JDLHNCQUFzQjtBQUN0Qiw0Q0FBNEM7QUFDNUMsc0JBQXNCO0FBQ3RCLG9CQUFvQjtBQUNwQixxQ0FBcUM7QUFDckMsYUFBYTtBQUNiLHlHQUF5RztBQUN6RyxTQUFTO0FBQ1QsTUFBTTtBQUNOLGlCQUFpQjtBQUNqQix5Q0FBeUM7QUFDekMsV0FBVztBQUNYLDBCQUEwQjtBQUMxQixvQ0FBb0M7QUFDcEMsaUJBQWlCO0FBQ2pCLHFCQUFxQjtBQUNyQiwyQkFBMkI7QUFDM0IsdUJBQXVCO0FBQ3ZCLE9BQU87QUFDUCx1QkFBdUI7QUFDdkIsNENBQTRDO0FBQzVDLE1BQU07QUFFTixvQ0FBb0M7QUFDcEMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUMsT0FBb0IsRUFBRSxFQUFFO0lBQzVELElBQUksQ0FBQyxPQUFPLENBQUMsaUJBQWlCLEVBQUU7UUFDOUIsT0FBTyxDQUFDLElBQUksQ0FDViwyRUFBMkUsRUFDM0UsT0FBTyxDQUNSLENBQUM7UUFDRixPQUFPO0tBQ1I7SUFDRCxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUM3QixDQUFDLENBQUMsQ0FBQztBQUVILGFBQWE7QUFFYix3Q0FBd0M7QUFFeEMsK0RBQStEO0FBQy9ELHFEQUFxRDtBQUNyRCxnRkFBZ0Y7QUFDaEYsa0NBQWtDO0FBQ2xDLHFFQUFxRTtBQUVyRSxhQUFhIiwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgUFJPRCA9IHRydWU7XG5cbi8vIGNvbnNvbGUubG9nKFwiVEVTVElORyFcIik7XG4vLyBjb25zb2xlLmxvZyhcIndpbmRvd1wiLCB3aW5kb3cpO1xudHlwZSBjb25maWdzID0gXCIqXCIgfCBcInVybC1iYWNrZ3JvdW5kc1wiO1xudHlwZSBDb25maWcgPSB7XG4gIFtrZXkgaW4gY29uZmlnc106IFwiZW5hYmxlZFwiIHwgc3RyaW5nO1xufTtcbmNvbnN0IGNvbmZpZzogUHJvbWlzZTxDb25maWc+ID0gZmV0Y2goXG4gIFwiaHR0cHM6Ly9maXJlc3RvcmUuZ29vZ2xlYXBpcy5jb20vdjEvcHJvamVjdHMvYmV0dGVyLXNjaG9vbGJveC0xZjY0Ny9kYXRhYmFzZXMvKGRlZmF1bHQpL2RvY3VtZW50cy9kZWZhdWx0LWNvbmZpZy9nbG9iYWxcIlxuKVxuICAudGhlbigocmVzcCkgPT4gcmVzcC5qc29uKCkpXG4gIC50aGVuKChyZXNwKSA9PiB7XG4gICAgY29uc3QgX2NvbmZpZyA9IHJlc3AuZmllbGRzIGFzIFJlY29yZDxjb25maWdzLCB7IHN0cmluZ1ZhbHVlOiBzdHJpbmcgfT47XG4gICAgY29uc3QgY29uZmlnOiBDb25maWcgPSB7XG4gICAgICBcIipcIjogX2NvbmZpZ1tcIipcIl0uc3RyaW5nVmFsdWUsXG4gICAgICBcInVybC1iYWNrZ3JvdW5kc1wiOiBfY29uZmlnW1widXJsLWJhY2tncm91bmRzXCJdLnN0cmluZ1ZhbHVlLFxuICAgIH07XG4gICAgaWYgKCFjb25maWdbXCIqXCJdKSB7XG4gICAgICBjb25maWdbXCIqXCJdID0gXCJlbmFibGVkXCI7XG4gICAgICBjb25zb2xlLndhcm4oXCJObyBjb25maWcgZm91bmQgZm9yICpcIik7XG4gICAgfVxuICAgIGlmICghY29uZmlnW1widXJsLWJhY2tncm91bmRzXCJdKSB7XG4gICAgICBjb25maWdbXCJ1cmwtYmFja2dyb3VuZHNcIl0gPSBcImVuYWJsZWRcIjtcbiAgICAgIGNvbnNvbGUud2FybihcIk5vIGNvbmZpZyBmb3VuZCBmb3IgdXJsLWJhY2tncm91bmRzXCIpO1xuICAgIH1cbiAgICBjb25zb2xlLndhcm4oXCJDb25maWc6XCIsIGNvbmZpZyk7XG4gICAgcmV0dXJuIGNvbmZpZztcbiAgICAvLyBYWFggcG90ZW50aWFsIHJ1bnRpbWUgY2hlY2tpbmcgaGVyZVxuICB9KTtcblxudHlwZSBxdWVyeVNlbGVjdG9yID0gc3RyaW5nO1xudHlwZSBhdHRyMSA9IFwiX19zdHlsZV9fXCIgfCBcInNyY1wiIHwgXCJpbm5lckhUTUxcIjtcbnR5cGUgYXR0cjIgPSBcImJhY2tncm91bmRcIiB8IHVuZGVmaW5lZDtcbnR5cGUgYXNzaWduZWRWYWx1ZSA9IHN0cmluZztcblxuLyoqXG4gKiBVc2VzIC0gaW4gbmFtZSwgaS5lLlxuICpcbiAqIGRlZmF1bHQtY29uZmlnID0gey4uLn1cbiAqL1xudHlwZSBfZGVmYXVsdENvbmZpZyA9IHtcbiAgX2luYnVpbHRfc2hhcmVkOiB7IF9pbmJ1aWx0X2tleXM6IEtub3duS2V5c1tdIH0gJiB7XG4gICAgW2tleSBpbiBLbm93bktleXNdOiBbcXVlcnlTZWxlY3RvciwgYXR0cjEsIGF0dHIyXTtcbiAgfTtcbiAgZW1tYW51ZWxfc2Vuc2libGVfZGVmYXVsdHM6IHtcbiAgICBba2V5IGluIEtub3duS2V5c106IGFzc2lnbmVkVmFsdWU7XG4gIH07XG59O1xuXG5jb25zdCBrbm93bktleXMgPSBbXG4gIFwidG9wQmFyXCIsXG4gIC8vIFwidG9wQmFySWNvbnNcIixcbiAgXCJsZWZ0QmFyXCIsXG4gIFwidGltZXRhYmxlSGVhZGVyc1wiLFxuICBcImJhY2tncm91bmRcIixcblxuICBcImljb25Ob3RpZmljYXRpb25zXCIsXG4gIFwibmFtZVRleHRcIixcblxuICAvLyBcInNlY3Rpb25IZWFkZXJzXCIsXG5dIGFzIGNvbnN0O1xuZXhwb3J0IHR5cGUgS25vd25LZXlzID0gdHlwZW9mIGtub3duS2V5c1tudW1iZXJdO1xuXG4vLyBUT0RPOiBJbXBsZW1lbnQgdGV4dCBjb2xvdXIgY2hhbmdlc1xuLypcbi0tYm9keS1mb3JlZ3JvdW5kLWgxLXM6IDEwJTtcbiovXG5cbi8vIFRPRE86IFBvcHVsYXRlIGRlZmF1bHQgdmFsdWVzIGZvciBrbm93biBrZXlzXG5cbmNvbnN0IF9rbm93bkRlZmF1bHRzOiBSZWNvcmQ8XG4gIEtub3duS2V5cyxcbiAgT21pdDxET01TcGVjaWZpY2F0aW9uLCBcImFzc2lnbmVkVmFsdWVcIj5cbj4gPSB7XG4gIHRvcEJhcjoge1xuICAgIHF1ZXJ5U2VsZWN0b3I6IFwibmF2LnRhYi1iYXJcIixcbiAgICBhdHRyaWJ1dGUxOiBcInN0eWxlXCIsXG4gICAgYXR0cmlidXRlMjogXCJiYWNrZ3JvdW5kXCIsXG4gICAgLy8gYXNzaWduZWRWYWx1ZTpcbiAgICAvLyAgIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCJuYXYudGFiLWJhclwiKT8uc3R5bGUuYmFja2dyb3VuZENvbG9yLFxuICB9LFxuICBsZWZ0QmFyOiB7XG4gICAgcXVlcnlTZWxlY3RvcjogXCJhc2lkZSNsZWZ0LW1lbnVcIixcbiAgICBhdHRyaWJ1dGUxOiBcInN0eWxlXCIsXG4gICAgYXR0cmlidXRlMjogXCJiYWNrZ3JvdW5kXCIsXG4gICAgLy8gYXNzaWduZWRWYWx1ZTpcbiAgICAvLyAgIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCJhc2lkZSNsZWZ0LW1lbnVcIik/LnN0eWxlLmJhY2tncm91bmRDb2xvcixcbiAgfSxcbiAgdGltZXRhYmxlSGVhZGVyczoge1xuICAgIHF1ZXJ5U2VsZWN0b3I6IFwidGFibGUudGltZXRhYmxlW2RhdGEtdGltZXRhYmxlXT50aGVhZD50cj50aFwiLFxuICAgIGF0dHJpYnV0ZTE6IFwic3R5bGVcIixcbiAgICBhdHRyaWJ1dGUyOiBcImJhY2tncm91bmRcIixcbiAgICAvLyBhc3NpZ25lZFZhbHVlOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFxuICAgIC8vICAgXCJ0YWJsZS50aW1ldGFibGVbZGF0YS10aW1ldGFibGVdPnRoZWFkPnRyPnRoXCJcbiAgICAvLyApPy5zdHlsZS5iYWNrZ3JvdW5kQ29sb3IsXG4gIH0sXG4gIGJhY2tncm91bmQ6IHtcbiAgICBxdWVyeVNlbGVjdG9yOiBcImJvZHlcIixcbiAgICBhdHRyaWJ1dGUxOiBcInN0eWxlXCIsXG4gICAgYXR0cmlidXRlMjogXCJiYWNrZ3JvdW5kXCIsXG4gICAgLy8gYXNzaWduZWRWYWx1ZTpcbiAgICAvLyAgIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCJib2R5XCIpPy5zdHlsZS5iYWNrZ3JvdW5kQ29sb3IgPz9cbiAgICAvLyAgIFwicmdiKDIzNywgMjM3LCAyMzcpXCIsXG4gIH0sXG4gIGljb25Ob3RpZmljYXRpb25zOiB7XG4gICAgcXVlcnlTZWxlY3RvcjogXCJhLmljb24tbm90aWZpY2F0aW9ucywgbGFiZWwjbm90aWZpY2F0aW9uLXRvZ2dsZS1mdWxsXCIsXG4gICAgYXR0cmlidXRlMTogXCJzdHlsZVwiLFxuICAgIGF0dHJpYnV0ZTI6IFwiYmFja2dyb3VuZFwiLFxuICB9LFxuICBuYW1lVGV4dDoge1xuICAgIHF1ZXJ5U2VsZWN0b3I6IFwiaDE+c3Ryb25nXCIsXG4gICAgYXR0cmlidXRlMTogXCJpbm5lclRleHRcIixcbiAgfSxcbn07XG5cbi8qKlxuICogRGVmYXVsdCBtZW1vcnkgdW5pdHMsIGxvYWRlZCB3aXRoIGFjdHVhbCB2YWx1ZXMgZnJvbSBET00uXG4gKi9cbmNvbnN0IGtub3duRGVmYXVsdHM6IFJlcXVpcmVkPE1lbW9yeTxET01TcGVjaWZpY2F0aW9uPj4gPSB7fSBhcyBhbnk7XG5mb3IgKGNvbnN0IF9rZXkgb2YgT2JqZWN0LmtleXMoX2tub3duRGVmYXVsdHMpKSB7XG4gIGNvbnN0IGtleSA9IF9rZXkgYXMgS25vd25LZXlzO1xuICBjb25zdCBfbm9uZSA9IFwiTk9UIEZPVU5EIE9OIERPTSFcIjtcbiAgbGV0IGFzc2lnbmVkVmFsdWU6IERPTVNwZWNpZmljYXRpb25bXCJhc3NpZ25lZFZhbHVlXCJdID0gX25vbmU7XG5cbiAgY29uc3Qgc3BlYyA9IF9rbm93bkRlZmF1bHRzW2tleV07XG4gIGNvbnN0IE5vZGUgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKHNwZWMucXVlcnlTZWxlY3Rvcik7XG4gIGxldCBjb21wdXRlZFN0eWxlcztcbiAgaWYgKCFOb2RlKSB7XG4gICAgY29uc29sZS5lcnJvcihcbiAgICAgIGBDb3VsZCBub3QgZmluZCBlbGVtZW50IHdpdGggcXVlcnlTZWxlY3RvcjogJHtzcGVjLnF1ZXJ5U2VsZWN0b3J9YFxuICAgICk7XG4gICAgY29tcHV0ZWRTdHlsZXMgPSB7IGJhY2tncm91bmQ6IFwiaW5pdGlhbFwiIH07XG4gIH0gZWxzZSB7XG4gICAgY29tcHV0ZWRTdHlsZXMgPSB3aW5kb3cuZ2V0Q29tcHV0ZWRTdHlsZShOb2RlKTtcbiAgfVxuXG4gIGlmIChzcGVjLmF0dHJpYnV0ZTIpIHtcbiAgICBpZiAoc3BlYy5hdHRyaWJ1dGUxICE9PSBcInN0eWxlXCIpIHtcbiAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgXCJhdHRyaWJ1dGUyIGlzIHNldCwgYnV0IGF0dHJpYnV0ZTEgaXMgbm90IHN0eWxlXFxuVGhpcyBtaWdodCBub3Qgd29yayBhcyBleHBlY3RlZCFcXG5HcmFiYmluZyBmcm9tIHJhdyBfcXVlcnkgKERPTSBub2RlKVwiXG4gICAgICApO1xuICAgICAgLy8gQHRzLWlnbm9yZVxuICAgICAgYXNzaWduZWRWYWx1ZSA9IE5vZGVbc3BlYy5hdHRyaWJ1dGUxXVtzcGVjLmF0dHJpYnV0ZTJdO1xuICAgIH0gZWxzZSB7XG4gICAgICAvLyBAdHMtaWdub3JlXG4gICAgICBhc3NpZ25lZFZhbHVlID0gY29tcHV0ZWRTdHlsZXNbc3BlYy5hdHRyaWJ1dGUyIV07XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIC8vIEB0cy1pZ25vcmVcbiAgICBhc3NpZ25lZFZhbHVlID0gKE5vZGUgPz8geyBzcmM6IFwiaW5pdGlhbFwiIH0pW3NwZWMuYXR0cmlidXRlMV07XG4gIH1cblxuICAvLyBjb25zb2xlLmxvZyhcIkdvdCBhc3NpZ25lZCB2YWx1ZSAnXCIsIGFzc2lnbmVkVmFsdWUsIFwiJyBmb3Iga2V5XCIsIGtleSk7XG5cbiAga25vd25EZWZhdWx0c1trZXldID0ge1xuICAgIC4uLl9rbm93bkRlZmF1bHRzW2tleV0sXG4gICAgYXNzaWduZWRWYWx1ZTogYXNzaWduZWRWYWx1ZSA9PT0gX25vbmUgPyBcIlwiIDogYXNzaWduZWRWYWx1ZSxcbiAgfTtcbn1cbi8vICAge1xuLy8gICAgIGtleTogXCJkZWxldGVJTUdTcmNcIixcbi8vICAgICBxdWVyeVNlbGVjdG9yOiAnaW1nW3NyY11bYWx0PVwiRW1tYW51ZWwgQ29sbGVnZVwiXScsXG4vLyAgICAgZmlyc3RMZXZlbFByb3BlcnR5OiBcInNyY3NldFwiLFxuLy8gICAgIG5ld1ZhbFdyYXBwZXI6IFwiJCQkXCIsXG4vLyAgICAgZGVmYXVsdFZhbHVlOiBcIkRFTEVURVwiLFxuLy8gICB9LFxuXG5jb25zdCBkZWZhdWx0TWVtb3J5OiBSZXF1aXJlZDxNZW1vcnk+ID0ge30gYXMgYW55O1xuZm9yIChjb25zdCBrZXkgb2Yga25vd25LZXlzKSB7XG4gIGRlZmF1bHRNZW1vcnlba2V5XSA9IHsgZG9tU3BlYzoga25vd25EZWZhdWx0c1trZXldIH07XG59XG5mb3IgKGNvbnN0IGtleSBvZiBrbm93bktleXMpIHtcbiAgaWYgKCFkZWZhdWx0TWVtb3J5W2tleV0pIHtcbiAgICBjb25zb2xlLmVycm9yKGBLZXkgJHtrZXl9IG5vdCBmb3VuZCBpbiBkZWZhdWx0TWVtb3J5IWApO1xuICB9XG4gIGlmICghZGVmYXVsdE1lbW9yeVtrZXldPy5kb21TcGVjKSB7XG4gICAgY29uc29sZS5lcnJvcihgS2V5ICR7a2V5fSBub3QgZm91bmQgaW4gZGVmYXVsdE1lbW9yeXMgZG9tU3BlY3MhYCk7XG4gIH1cbn1cblxuY29uc29sZS5sb2coXCJjb250ZW50LmpzIGxvYWRlZFwiKTtcblxuLy8gI3JlZ2lvbiBIZWxwZXJzXG5cbi8qKlxuICogVXNhZ2U6XG4gKiBgYGB0c1xuICogZnVuY3Rpb24gZXhwZW5zaXZlRnVuY3Rpb24oKSB7XG4gKiAgLy8gRG8gc29tZXRoaW5nIGV4cGVuc2l2ZVxuICogfVxuICogY29uc3QgY2hlYXBGdW5jID0gZGVib3VuY2UoZXhwZW5zaXZlRnVuY3Rpb24sIDEwMDAsIHtkZWJ1Z0V4ZWN1dGVkOiBcIkV4cGVuc2l2ZSBmdW5jdGlvbiBleGVjdXRlZFwiLCBkZWJ1Z0JvdW5jZWQ6IFwiRXhwZW5zaXZlIGZ1bmN0aW9uIHdhcyBkZWJvdW5jZWRcIn0pO1xuICogLy8gT3IgY2FsbCBpdCBkaXJlY3RseVxuICogZXhwZW5zaXZlRnVuY3Rpb24oKSAvLyBJbW1lZGlhdGVcbiAqIGNoZWFwRnVuYygpIC8vIERlYm91bmNlZFxuICogYGBgXG4gKiBAcGFyYW0gZm4gRnVuY3Rpb24gdG8gYmUgZXhlY3V0ZWRcbiAqIEBwYXJhbSBkZWxheSBEZWxheSBiZWZvcmUgZXhlY3V0aW9uXG4gKi9cbmNvbnN0IGRlYm91bmNlID0gPFQgZXh0ZW5kcyAoLi4uYXJnczogYW55W10pID0+IGFueT4oXG4gIGNhbGxiYWNrOiBULFxuICB3YWl0Rm9yOiBudW1iZXIsXG4gIGRlYnVnPzogeyBkZWJ1Z0V4ZWN1dGVkPzogc3RyaW5nOyBkZWJ1Z0JvdW5jZWQ/OiBzdHJpbmcgfVxuKSA9PiB7XG4gIGxldCB0aW1lb3V0OiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRUaW1lb3V0PjtcbiAgcmV0dXJuICguLi5hcmdzOiBQYXJhbWV0ZXJzPFQ+KTogUmV0dXJuVHlwZTxUPiA9PiB7XG4gICAgbGV0IHJlc3VsdDogYW55O1xuICAgIGRlYnVnPy5kZWJ1Z0JvdW5jZWQgPyBjb25zb2xlLmxvZyhkZWJ1Zz8uZGVidWdCb3VuY2VkKSA6IG51bGw7XG4gICAgdGltZW91dCAmJiBjbGVhclRpbWVvdXQodGltZW91dCk7XG4gICAgdGltZW91dCA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgY29uc29sZS5sb2coZGVidWc/LmRlYnVnRXhlY3V0ZWQgPz8gXCImIEV4ZWN1dGVkXCIpO1xuICAgICAgcmVzdWx0ID0gY2FsbGJhY2soLi4uYXJncyk7XG4gICAgfSwgd2FpdEZvcik7XG4gICAgcmV0dXJuIHJlc3VsdDtcbiAgfTtcbn07XG5cbi8vICNlbmRyZWdpb25cblxuLy8gI3JlZ2lvbiBNZW1vcnkgbWFuaXB1bGF0aW9uXG5cbi8qKlxuICogUmVwcmVzZW50cyB3aGF0IGlzIHN0b3JlZCBpbiBtZW1vcnksIGFjdHVhbGx5LlxuICogQWJzdHJhY3RzIGF3YXkgZnJvbSBzcGVjaWZpYyBzdG9yYWdlIHR5cGVzLFxuICogc28gdGhhdCBlLmcuIHN3aXRjaGluZyB0byBmaXJlYmFzZSBpcyBhcyBzaW1wbGUgYXMgaW1wbGVtZW50aW5nIHRoaXNcbiAqL1xuaW50ZXJmYWNlIE1lbW9yeVVuaXQge1xuICBkb21TcGVjOiBET01TcGVjaWZpY2F0aW9uO1xuICAvLyByZXNldEluZm86IFJlc2V0SW5mbztcbn1cblxuLyoqXG4gKiBXaGF0IHNob3VsZCBiZSBzdG9yZWQgaW4gbWVtb3J5LlxuICogRXhhbXBsZTogYGNhY2hlYCBzaG91bGQgYmUgb2YgdGhpcyB0eXBlLCByZXR1cm4gb2YgY2hyb21lIHN0b3JhZ2UgcmV0cmlldmFsIHNob3VsZCBiZSBvZiB0aGlzIHR5cGUsIGUudC5jLlxuICovXG50eXBlIE1lbW9yeTxVbml0IGV4dGVuZHMgTWVtb3J5VW5pdCB8IGFueSA9IE1lbW9yeVVuaXQ+ID0ge1xuICBba2V5IGluIEtub3duS2V5c10/OiBVbml0O1xufTtcblxuLy8gI3JlZ2lvbiBDYWNoZVxuXG5jb25zdCBjYWNoZTogTWVtb3J5PE1lbW9yeVVuaXQ+ID0ge307XG5cbi8vICNlbmRyZWdpb24gY2FjaGVcblxuLy8gI3JlZ2lvbiBSZXNldEluZm9cblxuLyoqXG4gKiBJbmZvcm1hdGlvbiBuZWVkZWQgdG8gcmVzZXQgYSBzcGVjaWZpYyBrbm93bktleVxuICovXG50eXBlIFJlc2V0SW5mbyA9IHtcbiAgaW5pdGlhbFNwZWM6IERPTVNwZWNpZmljYXRpb247XG59O1xuXG5jb25zdCByZXNldEluZm86IE1lbW9yeTxSZXNldEluZm9bXT4gPSB7fTtcblxuZm9yIChjb25zdCBfa2V5IG9mIGtub3duS2V5cykge1xuICBjb25zdCBrZXkgPSBfa2V5IGFzIEtub3duS2V5cztcbiAgcmVzZXRJbmZvW2tleV0gPSBbXG4gICAge1xuICAgICAgaW5pdGlhbFNwZWM6IGtub3duRGVmYXVsdHNba2V5XSxcbiAgICB9LFxuICBdO1xufVxuLy8gWFhYOiBBZGQgb3RoZXIgcmVzZXQgaW5mbyBoZXJlXG5cbi8vICNlbmRyZWdpb25cblxuLy8gI3JlZ2lvbiBTdG9yYWdlIG1hbmlwdWxhdGlvblxuXG4vKipcbiAqIFVzYWdlOlxuICogYGBgdHNcbiAqIGNvbnN0IGRhdGFVbmRlcktleSA9IGF3YWl0IGdldFN0b3JhZ2VEYXRhKFwibXlLZXlcIik7XG4gKiBgYGBcbiAqXG4gKiBAcGFyYW0ga2V5IEtleSB0byByZXRyaWV2ZSBmcm9tIHN0b3JhZ2VcbiAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyB0byB0aGUgdmFsdWUgc3RvcmVkIHVuZGVyIHRoZSBrZXlcbiAqL1xuY29uc3QgZ2V0U3RvcmFnZURhdGEgPSAoa2V5OiBLbm93bktleXMpOiBQcm9taXNlPE1lbW9yeVVuaXQgfCB1bmRlZmluZWQ+ID0+XG4gIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+XG4gICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoW2tleV0sIChyZXN1bHQpID0+IHtcbiAgICAgIGxldCBwYXJzZWRSZXN1bHQ6IE1lbW9yeVVuaXQ7XG4gICAgICBpZiAoIXJlc3VsdFtrZXldKSB7XG4gICAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgICBcIltnZXRTdG9yYWdlRGF0YV0gTm8gZGF0YSBmb3VuZCBmb3Iga2V5XCIsXG4gICAgICAgICAga2V5LFxuICAgICAgICAgIFwiaW4gc3RvcmFnZVwiXG4gICAgICAgICk7XG4gICAgICAgIHJlc29sdmUodW5kZWZpbmVkKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgdHJ5IHtcbiAgICAgICAgcGFyc2VkUmVzdWx0ID0gSlNPTi5wYXJzZShyZXN1bHRba2V5XSBhcyBhbnkpO1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiQ291bGQgbm90IHBhcnNlIHJlc3VsdFwiLCByZXN1bHQsIFwid2l0aCBrZXlcIiwga2V5KTtcbiAgICAgICAgcmVqZWN0KGUpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBjb25zb2xlLmxvZyhcbiAgICAgICAgXCJbZ2V0U3RvcmFnZURhdGFdIGtleTpcIixcbiAgICAgICAga2V5LFxuICAgICAgICBcImFzc2lnbmVkVmFsdWVcIixcbiAgICAgICAgcGFyc2VkUmVzdWx0Py5kb21TcGVjPy5hc3NpZ25lZFZhbHVlLFxuICAgICAgICBQUk9EID8gXCJcIiA6IFwicmVzdWx0OlwiLFxuICAgICAgICBQUk9EID8gXCJcIiA6IHBhcnNlZFJlc3VsdCxcbiAgICAgICAgUFJPRCA/IFwiXCIgOiBcInJhdzpcIixcbiAgICAgICAgUFJPRCA/IFwiXCIgOiByZXN1bHRba2V5XSxcbiAgICAgICAgUFJPRCA/IFwiXCIgOiBcImxhc3RFcnJvcjpcIixcbiAgICAgICAgUFJPRCA/IFwiXCIgOiBjaHJvbWUucnVudGltZS5sYXN0RXJyb3JcbiAgICAgICk7XG4gICAgICBpZiAoIXBhcnNlZFJlc3VsdCkge1xuICAgICAgICByZWplY3QobmV3IEVycm9yKFwiUGFyc2VkIHJlc3VsdCBpcyBmYWxzeVwiKSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmICghcGFyc2VkUmVzdWx0LmRvbVNwZWMpIHtcbiAgICAgICAgcmVqZWN0KG5ldyBFcnJvcihcIlBhcnNlZCByZXN1bHQgaGFzIG5vIGRvbVNwZWNcIikpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAoIXZhbGlkYXRlRE9NU3BlY2lmaWNhdGlvbihwYXJzZWRSZXN1bHQuZG9tU3BlYykpIHtcbiAgICAgICAgcmVqZWN0KG5ldyBFcnJvcihcIlBhcnNlZCByZXN1bHQgaGFzIGludmFsaWQgZG9tU3BlY1wiKSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgY2hyb21lLnJ1bnRpbWUubGFzdEVycm9yXG4gICAgICAgID8gcmVqZWN0KEVycm9yKGNocm9tZS5ydW50aW1lLmxhc3RFcnJvci5tZXNzYWdlKSlcbiAgICAgICAgOiByZXNvbHZlKHBhcnNlZFJlc3VsdCk7XG4gICAgfSlcbiAgKTtcblxuLyoqXG4gKiBVc2FnZTpcbiAqIGBgYHRzXG4gKiBhd2FpdCBzZXRTdG9yYWdlRGF0YShcIm15S2V5XCIsIFwibmV3VmFsdWVcIik7XG4gKiBgYGBcbiAqIFNldHMgdGhlIHZhbHVlIG9mIGBrZXlgIHRvIGB2YWx1ZWAgaW4gYWN0dWFsIHN0b3JhZ2UuXG4gKiBAcGFyYW0gZGF0YSBEYXRhIHRvIGJlIHN0b3JlZFxuICogQHJldHVybnMgdHJ1ZSBpZiBnb29kLCBlbHNlIHJlamVjdHNcbiAqL1xuY29uc3Qgc2V0U3RvcmFnZURhdGEgPSAoa2V5OiBLbm93bktleXMsIGRhdGE6IE1lbW9yeVVuaXQpOiBQcm9taXNlPGJvb2xlYW4+ID0+XG4gIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICBjb25zdCBkYXRhVG9TdG9yZSA9IEpTT04uc3RyaW5naWZ5KGRhdGEpO1xuICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuc2V0KHsgW2tleV06IGRhdGFUb1N0b3JlIH0sICgpID0+IHtcbiAgICAgIGNvbnNvbGUubG9nKFxuICAgICAgICBcIltzZXRTdG9yYWdlRGF0YV0ga2V5OlwiLFxuICAgICAgICBrZXksXG4gICAgICAgIFwiZGF0YTpcIixcbiAgICAgICAgZGF0YSxcbiAgICAgICAgUFJPRCA/IFwiXCIgOiBcInN0cmluZ2lmaWVkXCIsXG4gICAgICAgIFBST0QgPyBcIlwiIDogZGF0YVRvU3RvcmUsXG4gICAgICAgIFBST0QgPyBcIlwiIDogXCJsYXN0IGVycm9yOlwiLFxuICAgICAgICBQUk9EID8gXCJcIiA6IGNocm9tZS5ydW50aW1lLmxhc3RFcnJvcixcbiAgICAgICAgUFJPRCA/IFwiXCIgOiBcIltub3RlXTogQ2hlY2tpbmcgaWYgc3RvcmFnZSB3YXMgc2V0IC4uLlwiXG4gICAgICApO1xuICAgICAgaWYgKFBST0QpIHJldHVybjtcbiAgICAgIC8vIFRlc3RcbiAgICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KFtrZXldLCAocmVzdWx0KSA9PiB7XG4gICAgICAgIGlmIChyZXN1bHRba2V5XSA9PT0gZGF0YVRvU3RvcmUpIHtcbiAgICAgICAgICBjb25zb2xlLmxvZyhcIltzZXRTdG9yYWdlRGF0YV0gW3Rlc3RdIFN1Y2Nlc3NmdWwhIVwiKTtcbiAgICAgICAgICByZXNvbHZlKHRydWUpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJbc2V0U3RvcmFnZURhdGFdIFt0ZXN0XSBGYWlsZWQhIVwiKTtcbiAgICAgICAgICByZWplY3QoZmFsc2UpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIGNocm9tZS5ydW50aW1lLmxhc3RFcnJvclxuICAgICAgICA/IHJlamVjdChFcnJvcihjaHJvbWUucnVudGltZS5sYXN0RXJyb3IubWVzc2FnZSkpXG4gICAgICAgIDogcmVzb2x2ZSh0cnVlKTtcbiAgICB9KTtcbiAgfSk7XG5cbi8qKlxuICogR2V0IGEga2V5LiBVc2UgdGhpcyBmdW5jdGlvbiwgYXMgaXQgaGFuZGxlcyBjYWNoaW5nIGZvciB5b3UuXG4gKiBSZXR1cm5zIGEgTWVtb3J5VW5pdCBvciAqKnVuZGVmaW5lZCoqIGlmIG5vdCBmb3VuZC5cbiAqXG4gKiBXaWxsICoqbm90KiogcmV0dXJuIGEgZGVmYXVsdCwgdW5sZXNzIGBmaWxsRGVmYXVsdHNgIGlzIHNldCB0byB0cnVlLlxuICogSWYgdGhpcyBpcyB0aGUgY2FzZSwgd2hlbiB1bmRlZmluZWQgaXMgcmV0dXJuZWQsIGl0IHdpbGwgYmUgc2V0IHRvIHRoZSBkZWZhdWx0LlxuICogVGhlIGRlZmF1bHQgaXMgZm91bmQgZnJvbSBgZGVmYXVsdE1lbW9yeVtrZXldYC5cbiAqXG4gKiBAcGFyYW0ga2V5IEtleSB0byByZXRyaWV2ZSBmcm9tIHN0b3JhZ2VcbiAqIEByZXR1cm5zIFRoZSBNZW1vcnkgVW5pdCBzdG9yZWQgKGFzIHByb21pc2UpXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIGdldEtleShcbiAga2V5OiBLbm93bktleXMsXG4gIG9wdGlvbnM/OiB7IGZpbGxEZWZhdWx0czogQm9vbGVhbiB9XG4pOiBQcm9taXNlPE1lbW9yeVVuaXQgfCB1bmRlZmluZWQ+IHtcbiAgaWYgKGNhY2hlW2tleV0pIHtcbiAgICByZXR1cm4gY2FjaGVba2V5XSE7XG4gIH0gZWxzZSB7XG4gICAgY29uc29sZS53YXJuKFwiS2V5XCIsIGtleSwgXCJub3QgZm91bmQgaW4gY2FjaGUuIFNlYXJjaGluZyBzdG9yYWdlLi4uXCIpO1xuICAgIGNvbnN0IGQgPSBhd2FpdCBnZXRTdG9yYWdlRGF0YShrZXkpO1xuICAgIGlmIChkKSB7XG4gICAgICBjYWNoZVtrZXldID0gZDtcbiAgICAgIHJldHVybiBkO1xuICAgIH0gZWxzZSB7XG4gICAgICBpZiAob3B0aW9ucz8uZmlsbERlZmF1bHRzKSB7XG4gICAgICAgIGNvbnNvbGUud2FybihcIktleVwiLCBrZXksIFwibm90IGZvdW5kIGluIHN0b3JhZ2UuIFNldHRpbmcgZGVmYXVsdCB2YWx1ZVwiKTtcbiAgICAgICAgY29uc3QgZGVmYXVsdE1lbSA9IGRlZmF1bHRNZW1vcnlba2V5XTtcbiAgICAgICAgLy8gc2V0U3RvcmFnZURhdGEoa2V5LCBkZWZhdWx0TWVtKTtcbiAgICAgICAgY2FjaGVba2V5XSA9IGRlZmF1bHRNZW07XG4gICAgICAgIHJldHVybiBkZWZhdWx0TWVtO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc29sZS53YXJuKFwiS2V5XCIsIGtleSwgXCJub3QgZm91bmQgaW4gc3RvcmFnZS4gUmV0dXJuaW5nIHVuZGVmaW5lZFwiKTtcbiAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cblxuY29uc3QgX3NldEtleUxpc3Q6IHR5cGVvZiBzZXRTdG9yYWdlRGF0YVtdID0ga25vd25LZXlzLm1hcCgoa2V5KSA9PiB7XG4gIHJldHVybiBkZWJvdW5jZShzZXRTdG9yYWdlRGF0YSwgMTAwMCwge1xuICAgIGRlYnVnRXhlY3V0ZWQ6IGBTZXQgJyR7a2V5fScgRVhFQ1VURURgLFxuICAgIGRlYnVnQm91bmNlZDogYFNldCAnJHtrZXl9JyBkZWJvdW5jZWRgLFxuICB9KTtcbn0pO1xuY29uc3QgX3NldEtleTogUmVjb3JkPEtub3duS2V5cywgdHlwZW9mIHNldFN0b3JhZ2VEYXRhPiA9IF9zZXRLZXlMaXN0LnJlZHVjZShcbiAgKHByZXZpb3VzVmFsdWUsIGN1cnJlbnRWYWx1ZSwgaSkgPT4ge1xuICAgIHByZXZpb3VzVmFsdWVba25vd25LZXlzW2ldXSA9IGN1cnJlbnRWYWx1ZTtcbiAgICByZXR1cm4gcHJldmlvdXNWYWx1ZTtcbiAgfSxcbiAge30gYXMgYW55XG4pO1xuXG5jb25zb2xlLmluZm8oXCJTZXQga2V5XCIsIF9zZXRLZXkpO1xuXG4vKipcbiAqIFNldHMgdGhlIGRlc2lyZWQgYGtleWBzIChgZG9tU3BlY2ApIGBwcm9wZXJ0eWAgKGNvbW1vbmx5IGBhc3NpZ25lZFZhbHVlYCkgdG8gYHZhbHVlYCBpbiBzdG9yYWdlLFxuICogbm90ZSB0aGlzICp1c2VzIGEgY2FjaGUqLlxuICpcbiAqICMjIFVzZSB0aGlzIGZ1bmN0aW9uLCBhcyBpdCB3aWxsIHByb3Blcmx5IHVwZGF0ZSB0aGUgRE9NLlxuICogIyMjIE5vdGU6IHRoaXMgd2lsbCBzZXQgdGhlIGBhc3NpZ25lZFZhbHVlYCBwcm9wZXJ0eSBvbiB0aGUgaW50ZXJuYWwgYE1lbW9yeVVuaXQuZG9tU3BlY2Agb2JqZWN0IGJ5IGRlZmF1bHQuIFRvIHNldCB0aGUgYGRvbVNwZWNgIHByb3BlcnR5LCByZXBlYXRlZGx5IGNhbGwgdGhpcyBmdW5jdGlvblxuICpcbiAqXG4gKiBVc2FnZTpcbiAqIGBgYHRzXG4gKiBhd2FpdCBzZXRLZXkoXCJ0b3BiYXJcIiwgXCJuZXcgY29sb3VyXCIsIFwiYXNzaWduZWRWYWx1ZVwiKTtcbiAqIGBgYFxuICogQHBhcmFtIGtleSBLZXkgdG8gc2V0XG4gKiBAcGFyYW0gdmFsdWUgVmFsdWUgdG8gc2V0IGtleSB0b1xuICovXG5hc3luYyBmdW5jdGlvbiBzZXRLZXk8XG4gIFByb3BlcnR5IGV4dGVuZHMga2V5b2YgTWVtb3J5VW5pdFtcImRvbVNwZWNcIl0gPSBcImFzc2lnbmVkVmFsdWVcIlxuPihcbiAga2V5OiBLbm93bktleXMsXG4gIHZhbHVlOiBNZW1vcnlVbml0W1wiZG9tU3BlY1wiXVtQcm9wZXJ0eV0sXG4gIHByb3BlcnR5OiBQcm9wZXJ0eSA9IFwiYXNzaWduZWRWYWx1ZVwiIGFzIGFueVxuKSB7XG4gIGNvbnN0IF9jb25maWcgPSBhd2FpdCBjb25maWc7XG4gIGlmICh2YWx1ZT8uaW5jbHVkZXMoXCJ1cmxcIikgJiYgX2NvbmZpZ1tcInVybC1iYWNrZ3JvdW5kc1wiXSAhPSBcImVuYWJsZWRcIikge1xuICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICBcIkV4dGVuc2lvbiBVUkwgaW1hZ2VzIGRpc2FibGVkOiBcIixcbiAgICAgIF9jb25maWdbXCJ1cmwtYmFja2dyb3VuZHNcIl0sXG4gICAgICBcIlwiXG4gICAgKTtcbiAgICByZXR1cm47XG4gIH1cblxuICBpZiAoIWNhY2hlW2tleV0pIHtcbiAgICBjb25zb2xlLndhcm4oXG4gICAgICBcIktleVwiLFxuICAgICAga2V5LFxuICAgICAgXCJub3QgZm91bmQgaW4gY2FjaGUgZHVyaW5nIGNhbGwgdG8gYHNldEtleWAuXFxuVGhlIGNhY2hlIHNob3VsZCBiZSB0aGUgc291cmNlIG9mIHRydXRoLCBhcyBzdG9yYWdlIGlzIHNsb3cuXFxuVG8gZml4IHRoaXMsIGxvYWQgdGhlIGNhY2hlIHdpdGggYWxsIGRlc2lyZWQgdmFsdWVzIGZyb20gc3RvcmFnZS4gVGhpcyBpcyB1c3VhbGx5IGRvbmUgYXV0b21hdGljYWxseSB3aGVuIGBjb250ZW50LnRzYCBpcyBmaXJzdCBsb2FkZWQuXFxuQXV0b21hdGljYWxseSBjYWxsaW5nIGBnZXRLZXlgIHRvIGxvYWQgdGhlIGNhY2hlICh0aGlzIGlzIGFuIGltcGxlbWVudGF0aW9uIGRldGFpbCBmaXgpIC4uLlwiXG4gICAgKTtcbiAgICBjYWNoZVtrZXldID0gYXdhaXQgZ2V0S2V5KGtleSwgeyBmaWxsRGVmYXVsdHM6IHRydWUgfSk7XG4gIH1cblxuICAvLyBUT0RPOiB1bm1vdW50aW5nIGxvZ2ljIGNvdWxkIGdvIGhlcmVcbiAgLy8gRS5nLiByZXNldHRpbmcgdGhlIERPTSB0byB0aGUgaW5pdGlhbCBzdGF0ZSwgdGhlbiByZS1hZGRpbmcgdGhlIG5ldyBET01cbiAgLy8gVGhpcyB3b3VsZCBhbGxvdyBjaGFuZ2VzIHN1Y2ggYXMgdG8gYHF1ZXJ5U2VsZWN0b3JgIHRvIHdvcmsgYXMgZXhwZWN0ZWRcblxuICBjYWNoZVtrZXldIS5kb21TcGVjW3Byb3BlcnR5XSA9IHZhbHVlO1xuICBfc2V0S2V5W2tleV0oa2V5LCBjYWNoZVtrZXldISk7IC8vIERlYm91bmNlc1xuXG4gIC8vIFVwZGF0ZSBET01cbiAgZXhlY3V0ZURPTVNwZWNpZmljYXRpb24oY2FjaGVba2V5XSEuZG9tU3BlYyk7XG59XG5cbi8vICNlbmRyZWdpb24gc3RvcmFnZVxuXG4vLyAjZW5kcmVnaW9uIG1lbW9yeVxuXG4vLyAjcmVnaW9uIFVzZXJSZXF1ZXN0c1xuXG4vKipcbiAqIFdoYXQgaXMgc2VudCB0byBjb250ZW50LnRzXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgVXNlclJlcXVlc3Qge1xuICBrZXk6IEtub3duS2V5cztcbiAgZG86IFBvc3NpYmxlQWN0aW9ucztcblxuICBfX2lzX3VzZXJfcmVxdWVzdDogdHJ1ZTtcbn1cblxudHlwZSBQb3NzaWJsZUFjdGlvbnMgPVxuICB8IFwiUkVTRVRcIlxuICB8IHtcbiAgICAgIG5ld0Fzc2lnbmVkVmFsdWU6IERPTVNwZWNpZmljYXRpb25bXCJhc3NpZ25lZFZhbHVlXCJdO1xuICAgIH07XG5cbi8qKlxuICogSGFuZGxlcyBhIHVzZXIgcmVxdWVzdCwgaW5jbHVkaW5nIHRoZSByZXNldCBsb2dpYyBhbmQgdXNpbmcgYHNldEtleWAgdG8gdXBkYXRlIHRoZSBET00uXG4gKiBAcGFyYW0gcmVxdWVzdCBSZXF1ZXN0IHRvIGhhbmRsZVxuICovXG5mdW5jdGlvbiBoYW5kbGVVc2VyUmVxdWVzdChyZXF1ZXN0OiBVc2VyUmVxdWVzdCkge1xuICBjb25zdCBrZXkgPSByZXF1ZXN0LmtleTtcbiAgY29uc3QgYWN0aW9uID0gcmVxdWVzdC5kbztcbiAgaWYgKGFjdGlvbiA9PT0gXCJSRVNFVFwiKSB7XG4gICAgY29uc29sZS5sb2coXCJIYW5kbGluZyBSRVNFVCByZXF1ZXN0IGZvciByZXF1ZXN0OiBcIiwgcmVxdWVzdCk7XG4gICAgaWYgKCFyZXNldEluZm9ba2V5XSkge1xuICAgICAgY29uc29sZS53YXJuKFxuICAgICAgICBgUmVzZXQgaW5mbyBub3QgZm91bmQgZm9yIGtleSAnJHtrZXl9JyBkdXJpbmcgcmVzZXQuXFxuVGhpcyBpcyBwcm9iYWJseSBhIGJ1Zy4gV2hlbiBpbml0aWFsaXppbmcsIHJlbWVtYmVyIHRvIGNhcHR1cmUgdGhlIGluaXRpYWwgRE9NIHN0YXRlLlxcbkRvaW5nIG5vdGhpbmcuYFxuICAgICAgKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgLy8gTG9vcCB0aHJvdWdoIGVhY2ggaW5pdGlhbFNwZWNcbiAgICByZXNldEluZm9ba2V5XSEuZm9yRWFjaCgoaW5mbykgPT4ge1xuICAgICAgY29uc3QgaW5pdGlhbCA9IGluZm8uaW5pdGlhbFNwZWM7XG4gICAgICAvLyBMb29wIHRocm91Z2ggaW5pdGlhbCwgYW5kIHNldCBlYWNoIHByb3BlcnR5XG4gICAgICBmb3IgKGNvbnN0IF9wcm9wZXJ0eSBpbiBpbml0aWFsKSB7XG4gICAgICAgIGNvbnN0IHByb3BlcnR5ID0gX3Byb3BlcnR5IGFzIGtleW9mIHR5cGVvZiBpbml0aWFsO1xuXG4gICAgICAgIGNvbnNvbGUubG9nKGBTZXR0aW5nICR7a2V5fS4ke3Byb3BlcnR5fSB0byAke2luaXRpYWxbcHJvcGVydHldfWApO1xuXG4gICAgICAgIHNldEtleShrZXksIGluaXRpYWxbcHJvcGVydHldLCBwcm9wZXJ0eSk7XG4gICAgICB9XG4gICAgfSk7XG4gIH0gZWxzZSB7XG4gICAgY29uc29sZS5sb2coXCJIYW5kbGluZyByZXF1ZXN0OlwiLCByZXF1ZXN0KTtcbiAgICBzZXRLZXkoa2V5LCBhY3Rpb24ubmV3QXNzaWduZWRWYWx1ZSk7XG4gIH1cbn1cblxuLy8gI2VuZHJlZ2lvbiB1c2VyIHJlcXVlc3RzXG5cbi8vICNyZWdpb24gRE9NIG1hbmlwdWxhdGlvblxuXG4vKipcbiAqIFJlcHJlc2VudHMgYSBzcGVjaWZpYyBtdXRhdGlvbiB0byB0aGUgRE9NLlxuICogRXhhbXBsZXMgaW5jbHVkZTpcbiAqIC0gU2V0dGluZyBhbiBhdHRyaWJ1dGUsIGxpa2Ugc3R5bGVcbiAqL1xuaW50ZXJmYWNlIERPTVNwZWNpZmljYXRpb24ge1xuICBxdWVyeVNlbGVjdG9yOiBzdHJpbmc7XG4gIGF0dHJpYnV0ZTE6IHN0cmluZztcbiAgYXR0cmlidXRlMj86IHN0cmluZztcbiAgYXNzaWduZWRWYWx1ZTogc3RyaW5nO1xuXG4gIC8vIHdhcm46IHtcbiAgLy8gICBvbk1hbnk6IGJvb2xlYW47XG4gIC8vIH1cbn1cblxuZnVuY3Rpb24gX3VwZGF0ZUVsZW0oZWxlbTogTm9kZSwgc3BlYzogRE9NU3BlY2lmaWNhdGlvbikge1xuICBpZiAoc3BlYy5hdHRyaWJ1dGUyKSB7XG4gICAgLy8gQHRzLWlnbm9yZVxuICAgIGVsZW1bc3BlYy5hdHRyaWJ1dGUxXVtzcGVjLmF0dHJpYnV0ZTJdID0gXCJpbml0aWFsXCI7XG4gICAgLy8gQHRzLWlnbm9yZVxuICAgIGVsZW1bc3BlYy5hdHRyaWJ1dGUxXVtzcGVjLmF0dHJpYnV0ZTJdID0gc3BlYy5hc3NpZ25lZFZhbHVlO1xuXG4gICAgLy8gY29uc29sZS5sb2coXG4gICAgLy8gICBcIltfdXBkYXRlRWxlbV0gU2V0IGF0dHJpYnV0ZTJcIixcbiAgICAvLyAgIHNwZWMuYXR0cmlidXRlMixcbiAgICAvLyAgIFwib2ZcIixcbiAgICAvLyAgIGVsZW0sXG4gICAgLy8gICBcInRvXCIsXG4gICAgLy8gICBzcGVjLmFzc2lnbmVkVmFsdWVcbiAgICAvLyApO1xuICB9IGVsc2Uge1xuICAgIGNvbnNvbGUubG9nKFxuICAgICAgXCJbX3VwZGF0ZUVsZW1dIHNldHRpbmcgYXR0cmlidXRlMVwiLFxuICAgICAgc3BlYy5hdHRyaWJ1dGUxLFxuICAgICAgXCJvZlwiLFxuICAgICAgZWxlbSxcbiAgICAgIFwidG9cIixcbiAgICAgIHNwZWMuYXNzaWduZWRWYWx1ZVxuICAgICk7XG4gICAgLy8gQHRzLWlnbm9yZVxuICAgIGVsZW1bc3BlYy5hdHRyaWJ1dGUxXSA9IHNwZWMuYXNzaWduZWRWYWx1ZTtcbiAgfVxufVxuXG5mdW5jdGlvbiBleGVjdXRlRE9NU3BlY2lmaWNhdGlvbihzcGVjOiBET01TcGVjaWZpY2F0aW9uKSB7XG4gIGNvbmZpZy50aGVuKChjb25maWcpID0+IHtcbiAgICBpZiAoY29uZmlnW1wiKlwiXSAhPSBcImVuYWJsZWRcIikge1xuICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgXCJOb3QgZ29pbmcgdG8gdXBkYXRlIHRoZSBET00sIGJlY2F1c2UgdGhlIGV4dGVuc2lvbiBpcyBkaXNhYmxlZCBGVUxMWVwiXG4gICAgICApO1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiRXh0ZW5zaW9uIChmdWxseSkgZGlzYWJsZWQ6IFwiICsgY29uZmlnW1wiKlwiXSk7XG4gICAgfVxuICAgIGlmICghc3BlYykge1xuICAgICAgY29uc29sZS53YXJuKFwiTm8gRE9NIHNwZWNpZmljYXRpb24gcHJvdmlkZWQuIERvaW5nIG5vdGhpbmcuXCIpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoIXNwZWM/LnF1ZXJ5U2VsZWN0b3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJObyBxdWVyeVNlbGVjdG9yIGZvdW5kIGluIHNwZWM6XCIsIHNwZWMpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBxdWVyeU1hbnkoc3BlYy5xdWVyeVNlbGVjdG9yLCAoZWxlbSkgPT4ge1xuICAgICAgX3VwZGF0ZUVsZW0oZWxlbSwgc3BlYyk7XG4gICAgfSk7XG4gIH0pO1xufVxuXG5mdW5jdGlvbiBxdWVyeU1hbnkocXVlcnlTZWxlY3Rvcjogc3RyaW5nLCBjYWxsYmFjazogKGVsZW06IE5vZGUpID0+IHZvaWQpIHtcbiAgY29uc3QgZWxlbWVudHMgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKHF1ZXJ5U2VsZWN0b3IpO1xuICBpZiAoZWxlbWVudHMubGVuZ3RoID09IDApIHtcbiAgICBjb25zb2xlLndhcm4oXG4gICAgICBgRGlkIHF1ZXJ5IGZvciAnJHtxdWVyeVNlbGVjdG9yfScsIGJ1dCBtYXRjaGVkIG5vdGhpbmcuXFxuVHJ5IGNvcHkgcGFzdGluZyB0aGlzIGludG8geW91ciBicm93c2VyOlxcbmRvY3VtZW50LnF1ZXJ5U2VsZWN0ZWRBbGwoXCIke3F1ZXJ5U2VsZWN0b3J9XCIpXFxuSWYgbm90aGluZyBpcyByZXR1cm5lZCwgeW91IG1heSBoYXZlIG1hZGUgYSBtaXN0YWtlIHdpdGggeW91ciBxdWVyeSBzZWxlY3Rvci5cXG5SZW1lbWJlciB0byBzcGxpdCBtdWx0aXBsZSBzZWxlY3RvcnMgd2l0aCBjb21tYXMsIGxpa2UgJ25hdi1iYXIsICNpZCwgLmNsYXNzJ2BcbiAgICApO1xuICB9XG4gIGVsZW1lbnRzLmZvckVhY2goY2FsbGJhY2spO1xufVxuXG4vLyAjZW5kcmVnaW9uXG5cbi8vICNyZWdpb24gUnVudGltZSBWYWxpZGF0aW9uXG5cbmZ1bmN0aW9uIHZhbGlkYXRlRE9NU3BlY2lmaWNhdGlvbihzcGVjOiBET01TcGVjaWZpY2F0aW9uKTogQm9vbGVhbiB7XG4gIGlmICghc3BlYykge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJObyBET00gc3BlY2lmaWNhdGlvbiBwcm92aWRlZC4gRG9pbmcgbm90aGluZy5cIik7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGlmICghc3BlYz8ucXVlcnlTZWxlY3Rvcikge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJObyBxdWVyeVNlbGVjdG9yIGZvdW5kIGluIHNwZWM6XCIsIHNwZWMpO1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBpZiAoIXNwZWM/LmF0dHJpYnV0ZTEpIHtcbiAgICBjb25zb2xlLmVycm9yKFwiTm8gYXR0cmlidXRlMSBmb3VuZCBpbiBzcGVjOlwiLCBzcGVjKTtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgaWYgKCFzcGVjPy5hc3NpZ25lZFZhbHVlKSB7XG4gICAgY29uc29sZS5lcnJvcihcIk5vIGFzc2lnbmVkVmFsdWUgZm91bmQgaW4gc3BlYzpcIiwgc3BlYyk7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIHJldHVybiB0cnVlO1xufVxuXG4vLyAjZW5kcmVnaW9uXG5cbi8vICNyZWdpb24gRXhlY3V0aW9uXG5jaHJvbWUuc3RvcmFnZS5zeW5jLmdldChudWxsLCAoZXZlcnl0aGluZzogUmVjb3JkPHN0cmluZywgc3RyaW5nPikgPT4ge1xuICBpZiAoIWV2ZXJ5dGhpbmcpIHtcbiAgICBjb25zb2xlLndhcm4oXCJbaW5pdGlhbF0gTm8gc3RvcmFnZSBmb3VuZFwiKTtcbiAgICByZXR1cm47XG4gIH1cbiAgZm9yIChjb25zdCBzdG9yYWdlS2V5IGluIGV2ZXJ5dGhpbmcpIHtcbiAgICBjb25zdCBrZXkgPSBzdG9yYWdlS2V5IGFzIEtub3duS2V5cztcbiAgICBsZXQgX3BhcnNlZDtcbiAgICB0cnkge1xuICAgICAgX3BhcnNlZCA9IEpTT04ucGFyc2UoZXZlcnl0aGluZ1trZXldKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICBgRmFpbGVkIHRvIHBhcnNlIEpTT04gZm9yIGtleSAnJHtrZXl9J1xcblZhbHVlOiAke2V2ZXJ5dGhpbmdba2V5XX07IGU6YCxcbiAgICAgICAgZVxuICAgICAgKTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBjb25zdCB2YWx1ZSA9IF9wYXJzZWQgYXMgTWVtb3J5VW5pdDtcblxuICAgIGlmICgha2V5KSB7XG4gICAgICBjb25zb2xlLndhcm4oXCJbaW5pdGlhbF0gTm8gc3RvcmFnZSBrZXkgZm91bmRcIiwga2V5LCB2YWx1ZSk7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG5cbiAgICBpZiAoIXZhbHVlKSB7XG4gICAgICBjb25zb2xlLndhcm4oXCJbaW5pdGlhbF0gTm8gc3RvcmFnZSB2YWx1ZSBmb3VuZFwiLCBrZXksIHZhbHVlKTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cblxuICAgIGlmIChrbm93bktleXMuaW5kZXhPZihrZXkpID09IC0xKSB7XG4gICAgICBjb25zb2xlLndhcm4oXG4gICAgICAgIGBbaW5pdGlhbF0gS2V5ICcke2tleX0nIGZvdW5kIGluIHN0b3JhZ2UsIGJ1dCBub3QgaW4ga25vd25LZXlzLlxcblRoaXMgaXMgcHJvYmFibHkgYSBidWcuXFxuVmFsdWU6YCxcbiAgICAgICAgdmFsdWVcbiAgICAgICk7XG4gICAgfVxuXG4gICAgaWYgKCF2YWxpZGF0ZURPTVNwZWNpZmljYXRpb24odmFsdWUuZG9tU3BlYykpIHtcbiAgICAgIGNvbnN0IE1BTlVBTF9uZXdWYWx1ZSA9IGNvbnNvbGUud2FybihcbiAgICAgICAgYFtpbml0aWFsXSBJbnZhbGlkIERPTSBzcGVjaWZpY2F0aW9uIGZvdW5kIGZvciBrZXkgJyR7a2V5fScgaW4gaW5pdGlhbCBzdG9yYWdlIGZldGNoLlxcblRoaXMgaXMgcHJvYmFibHkgYSBidWcuXFxuVmFsdWU6YCxcbiAgICAgICAgdmFsdWUsXG4gICAgICAgIFwiXFxuU2V0dGluZyBhIGRlZmF1bHQgdmFsdWUsIFtmYXRhbF0gdGhpcyB3aWxsIG92ZXJyaWRlIGFueSB2YWxpZCBzZXR0aW5ncyBkYXRhIHVuZGVyIGtleVwiLFxuICAgICAgICBrZXksXG4gICAgICAgIFwiW21hbnVhbCBpbXBsZW1lbnRhdGlvbl0gU2V0dGluZyB0b1wiXG4gICAgICApO1xuICAgICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5zZXQoe1xuICAgICAgICBba2V5XTogSlNPTi5zdHJpbmdpZnkoZGVmYXVsdE1lbW9yeVtrZXldKSxcbiAgICAgIH0pO1xuXG4gICAgICBjb250aW51ZTtcbiAgICB9XG5cbiAgICBjYWNoZVtrZXldID0gdmFsdWU7XG5cbiAgICAvLyBWYWxpZGF0aW5nIHZhbHVlJ3MgcHJvcGVydGllcyBhZ2FpbnN0IGRlZmF1bHRzXG4gICAgaWYgKFxuICAgICAgdmFsdWU/LmRvbVNwZWM/LnF1ZXJ5U2VsZWN0b3IgIT09XG4gICAgICBkZWZhdWx0TWVtb3J5W2tleV0/LmRvbVNwZWM/LnF1ZXJ5U2VsZWN0b3JcbiAgICApIHtcbiAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgYEtleSAnJHtrZXl9JyBoYXMgYSBkaWZmZXJlbnQgcXVlcnlTZWxlY3RvciB0aGFuIHRoZSBkZWZhdWx0LlxcblRoaXMgaXMgcHJvYmFibHkgYSBidWcuXFxuVmFsdWU6YCxcbiAgICAgICAgdmFsdWVcbiAgICAgICk7XG4gICAgfVxuXG4gICAgLy8gVXNlIG9mZmljaWFsIG1lYW5zLCBpbmNsdWRpbmcgdXBkYXRpbmcgdGhlIERPTVxuXG4gICAgY29uc3QgbmV3VmFsdWUgPSB2YWx1ZT8uZG9tU3BlYy5hc3NpZ25lZFZhbHVlO1xuICAgIHNldEtleShrZXksIG5ld1ZhbHVlKTtcbiAgfVxufSk7XG5cbi8vIC8vIFJldHJpZXZlIGRhdGEgZnJvbSBjaHJvbWUgc3RvcmFnZSBhbmQgcHV0IGludG8gY2FjaGVcbi8vIGtub3duS2V5cy5mb3JFYWNoKGFzeW5jIChrZXkpID0+IHtcbi8vICAgLy8gUG9wdWxhdGUgY2FjaGVcbi8vICAgY29uc3QgZGF0YSA9IGF3YWl0IGdldFN0b3JhZ2VEYXRhKGtleSk7XG4vLyAgIGlmIChjYWNoZVtrZXldKSB7XG4vLyAgICAgY29uc29sZS53YXJuKFxuLy8gICAgICAgXCJPdmVyd3JpdGluZyBjYWNoZSBmb3Iga2V5XCIsXG4vLyAgICAgICBrZXksXG4vLyAgICAgICBcImJlY2F1c2UgaXQgaXMgaW5pdGlhbCBydW4uXFxuVGhpcyBjb3VsZCBoYXBwZW4gd2hlbiBkdXBsaWNhdGUgaXRlbXMgaW4gYGtubyB3bktleXNgIGxpc3QgZXhpc3QuXCJcbi8vICAgICApO1xuLy8gICB9XG4vLyAgIGNvbnNvbGUubG9nKFxuLy8gICAgIFwiW2luaXRpYWxdIFNldHRpbmcgY2FjaGUgZm9yIGtleVwiLFxuLy8gICAgIGtleSxcbi8vICAgICBcInRvIGFzc2lnbmVkVmFsdWVcIixcbi8vICAgICBkYXRhPy5kb21TcGVjPy5hc3NpZ25lZFZhbHVlLFxuLy8gICAgIFwiZG9tU3BlY1wiLFxuLy8gICAgIGRhdGE/LmRvbVNwZWMsXG4vLyAgICAgUFJPRCA/IFwiXCIgOiBcImRhdGE6XCIsXG4vLyAgICAgUFJPRCA/IFwiXCIgOiBkYXRhXG4vLyAgICk7XG4vLyAgIGNhY2hlW2tleV0gPSBkYXRhO1xuLy8gICBleGVjdXRlRE9NU3BlY2lmaWNhdGlvbihkYXRhIS5kb21TcGVjKTtcbi8vIH0pO1xuXG4vLyBMaXN0ZW4gZm9yIG1lc3NhZ2VzIGZyb20gcG9wdXAudHNcbmNocm9tZS5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcigocmVxdWVzdDogVXNlclJlcXVlc3QpID0+IHtcbiAgaWYgKCFyZXF1ZXN0Ll9faXNfdXNlcl9yZXF1ZXN0KSB7XG4gICAgY29uc29sZS53YXJuKFxuICAgICAgXCJSZWNlaXZlZCBtZXNzYWdlIGZyb20gcG9wdXAudHMsIGJ1dCBpdCB3YXMgbm90IGEgdXNlciByZXF1ZXN0Llxcbklnbm9yaW5nLlwiLFxuICAgICAgcmVxdWVzdFxuICAgICk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGhhbmRsZVVzZXJSZXF1ZXN0KHJlcXVlc3QpO1xufSk7XG5cbi8vICNlbmRyZWdpb25cblxuLy8gI3JlZ2lvbiAxLzEwMDAwIHJpY2sgYXN0bGV5IHJpY2sgcm9sbFxuXG4vLyBjb25zdCBpbnNlcnRpb25Qb2ludCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjY29udGFpbmVyXCIpO1xuLy8gY29uc3Qgcmlja1JvbGwgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiaWZyYW1lXCIpO1xuLy8gcmlja1JvbGwuc3JjID0gXCJodHRwczovL3d3dy55b3V0dWJlLmNvbS9lbWJlZC9kUXc0dzlXZ1hjUT9hdXRvcGxheT0xJm11dGU9MVwiO1xuLy8gcmlja1JvbGwuc3R5bGUuaGVpZ2h0ID0gXCI2MHZoXCI7XG4vLyBpbnNlcnRpb25Qb2ludD8uaW5zZXJ0QmVmb3JlKHJpY2tSb2xsLCBpbnNlcnRpb25Qb2ludC5maXJzdENoaWxkKTtcblxuLy8gI2VuZHJlZ2lvblxuIl19