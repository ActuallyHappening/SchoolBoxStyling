"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var _a;
// Replaced by macro.py
const PROD = true;
const config = fetch("https://firestore.googleapis.com/v1/projects/better-schoolbox-1f647/databases/(default)/documents/default-config/global")
    .then((resp) => resp.json())
    .then((resp) => {
    const _config = resp.fields;
    const config = {
        "*": _config["*"].stringValue,
        "url-backgrounds": _config["url-backgrounds"].stringValue,
    };
    if (!config["*"]) {
        config["*"] = "enabled";
        console.warn("No config found for *");
    }
    if (!config["url-backgrounds"]) {
        config["url-backgrounds"] = "enabled";
        console.warn("No config found for url-backgrounds");
    }
    console.warn("Config:", config);
    return config;
    // XXX potential runtime checking here
});
const knownKeys = [
    "topBar",
    // "topBarIcons",
    "leftBar",
    "timetableHeaders",
    "background",
    "iconNotifications",
    "nameText",
    // "sectionHeaders",
];
// TODO: Implement text colour changes
/*
--body-foreground-h1-s: 10%;
*/
// TODO: Populate default values for known keys
const _knownDefaults = {
    topBar: {
        querySelector: "nav.tab-bar",
        attribute1: "style",
        attribute2: "background",
        // assignedValue:
        //   document.querySelector("nav.tab-bar")?.style.backgroundColor,
    },
    leftBar: {
        querySelector: "aside#left-menu",
        attribute1: "style",
        attribute2: "background",
        // assignedValue:
        //   document.querySelector("aside#left-menu")?.style.backgroundColor,
    },
    timetableHeaders: {
        querySelector: "table.timetable[data-timetable]>thead>tr>th",
        attribute1: "style",
        attribute2: "background",
        // assignedValue: document.querySelector(
        //   "table.timetable[data-timetable]>thead>tr>th"
        // )?.style.backgroundColor,
    },
    background: {
        querySelector: "body",
        attribute1: "style",
        attribute2: "background",
        // assignedValue:
        //   document.querySelector("body")?.style.backgroundColor ??
        //   "rgb(237, 237, 237)",
    },
    iconNotifications: {
        querySelector: "a.icon-notifications, label#notification-toggle-full",
        attribute1: "style",
        attribute2: "background",
    },
    nameText: {
        querySelector: "h1>strong",
        attribute1: "innerText",
    },
};
/**
 * Default memory units, loaded with actual values from DOM.
 */
const knownDefaults = {};
for (const _key of Object.keys(_knownDefaults)) {
    const key = _key;
    const _none = "NOT FOUND ON DOM!";
    let assignedValue = _none;
    const spec = _knownDefaults[key];
    const Node = document.querySelector(spec.querySelector);
    let computedStyles;
    if (!Node) {
        console.error(`Could not find element with querySelector: ${spec.querySelector}`);
        computedStyles = { background: "initial" };
    }
    else {
        computedStyles = window.getComputedStyle(Node);
    }
    if (spec.attribute2) {
        if (spec.attribute1 !== "style") {
            console.warn("attribute2 is set, but attribute1 is not style\nThis might not work as expected!\nGrabbing from raw _query (DOM node)");
            // @ts-ignore
            assignedValue = Node[spec.attribute1][spec.attribute2];
        }
        else {
            // @ts-ignore
            assignedValue = computedStyles[spec.attribute2];
        }
    }
    else {
        // @ts-ignore
        assignedValue = (Node !== null && Node !== void 0 ? Node : { src: "initial" })[spec.attribute1];
    }
    // console.log("Got assigned value '", assignedValue, "' for key", key);
    knownDefaults[key] = Object.assign(Object.assign({}, _knownDefaults[key]), { assignedValue: assignedValue === _none ? "" : assignedValue });
}
//   {
//     key: "deleteIMGSrc",
//     querySelector: 'img[src][alt="Emmanuel College"]',
//     firstLevelProperty: "srcset",
//     newValWrapper: "$$$",
//     defaultValue: "DELETE",
//   },
const defaultMemory = {};
for (const key of knownKeys) {
    defaultMemory[key] = { domSpec: knownDefaults[key] };
}
for (const key of knownKeys) {
    if (!defaultMemory[key]) {
        console.error(`Key ${key} not found in defaultMemory!`);
    }
    if (!((_a = defaultMemory[key]) === null || _a === void 0 ? void 0 : _a.domSpec)) {
        console.error(`Key ${key} not found in defaultMemorys domSpecs!`);
    }
}
console.log("content.js loaded");
// #region Helpers
/**
 * Usage:
 * ```ts
 * function expensiveFunction() {
 *  // Do something expensive
 * }
 * const cheapFunc = debounce(expensiveFunction, 1000, {debugExecuted: "Expensive function executed", debugBounced: "Expensive function was debounced"});
 * // Or call it directly
 * expensiveFunction() // Immediate
 * cheapFunc() // Debounced
 * ```
 * @param fn Function to be executed
 * @param delay Delay before execution
 */
const debounce = (callback, waitFor, debug) => {
    let timeout;
    return (...args) => {
        let result;
        (debug === null || debug === void 0 ? void 0 : debug.debugBounced) ? console.log(debug === null || debug === void 0 ? void 0 : debug.debugBounced) : null;
        timeout && clearTimeout(timeout);
        timeout = setTimeout(() => {
            var _a;
            console.log((_a = debug === null || debug === void 0 ? void 0 : debug.debugExecuted) !== null && _a !== void 0 ? _a : "& Executed");
            result = callback(...args);
        }, waitFor);
        return result;
    };
};
// #region Cache
const cache = {};
const resetInfo = {};
for (const _key of knownKeys) {
    const key = _key;
    resetInfo[key] = [
        {
            initialSpec: knownDefaults[key],
        },
    ];
}
// XXX: Add other reset info here
// #endregion
// #region Storage manipulation
/**
 * Usage:
 * ```ts
 * const dataUnderKey = await getStorageData("myKey");
 * ```
 *
 * @param key Key to retrieve from storage
 * @returns Promise that resolves to the value stored under the key
 */
const getStorageData = (key) => new Promise((resolve, reject) => chrome.storage.sync.get([key], (result) => {
    var _a;
    let parsedResult;
    if (!result[key]) {
        console.warn("[getStorageData] No data found for key", key, "in storage");
        resolve(undefined);
        return;
    }
    try {
        parsedResult = JSON.parse(result[key]);
    }
    catch (e) {
        console.error("Could not parse result", result, "with key", key);
        reject(e);
        return;
    }
    console.log("[getStorageData] key:", key, "assignedValue", (_a = parsedResult === null || parsedResult === void 0 ? void 0 : parsedResult.domSpec) === null || _a === void 0 ? void 0 : _a.assignedValue, PROD ? "" : "result:", PROD ? "" : parsedResult, PROD ? "" : "raw:", PROD ? "" : result[key], PROD ? "" : "lastError:", PROD ? "" : chrome.runtime.lastError);
    if (!parsedResult) {
        reject(new Error("Parsed result is falsy"));
        return;
    }
    if (!parsedResult.domSpec) {
        reject(new Error("Parsed result has no domSpec"));
        return;
    }
    if (!validateDOMSpecification(parsedResult.domSpec)) {
        reject(new Error("Parsed result has invalid domSpec"));
        return;
    }
    chrome.runtime.lastError
        ? reject(Error(chrome.runtime.lastError.message))
        : resolve(parsedResult);
}));
/**
 * Usage:
 * ```ts
 * await setStorageData("myKey", "newValue");
 * ```
 * Sets the value of `key` to `value` in actual storage.
 * @param data Data to be stored
 * @returns true if good, else rejects
 */
const setStorageData = (key, data) => new Promise((resolve, reject) => {
    const dataToStore = JSON.stringify(data);
    chrome.storage.sync.set({ [key]: dataToStore }, () => {
        console.log("[setStorageData] key:", key, "data:", data, PROD ? "" : "stringified", PROD ? "" : dataToStore, PROD ? "" : "last error:", PROD ? "" : chrome.runtime.lastError, PROD ? "" : "[note]: Checking if storage was set ...");
        if (PROD)
            return;
        // Test
        chrome.storage.sync.get([key], (result) => {
            if (result[key] === dataToStore) {
                console.log("[setStorageData] [test] Successful!!");
                resolve(true);
            }
            else {
                console.error("[setStorageData] [test] Failed!!");
                reject(false);
            }
        });
        chrome.runtime.lastError
            ? reject(Error(chrome.runtime.lastError.message))
            : resolve(true);
    });
});
/**
 * Get a key. Use this function, as it handles caching for you.
 * Returns a MemoryUnit or **undefined** if not found.
 *
 * Will **not** return a default, unless `fillDefaults` is set to true.
 * If this is the case, when undefined is returned, it will be set to the default.
 * The default is found from `defaultMemory[key]`.
 *
 * @param key Key to retrieve from storage
 * @returns The Memory Unit stored (as promise)
 */
function getKey(key, options) {
    return __awaiter(this, void 0, void 0, function* () {
        if (cache[key]) {
            return cache[key];
        }
        else {
            console.warn("Key", key, "not found in cache. Searching storage...");
            const d = yield getStorageData(key);
            if (d) {
                cache[key] = d;
                return d;
            }
            else {
                if (options === null || options === void 0 ? void 0 : options.fillDefaults) {
                    console.warn("Key", key, "not found in storage. Setting default value");
                    const defaultMem = defaultMemory[key];
                    // setStorageData(key, defaultMem);
                    cache[key] = defaultMem;
                    return defaultMem;
                }
                else {
                    console.warn("Key", key, "not found in storage. Returning undefined");
                    return undefined;
                }
            }
        }
    });
}
const _setKeyList = knownKeys.map((key) => {
    return debounce(setStorageData, 1000, {
        debugExecuted: `Set '${key}' EXECUTED`,
        debugBounced: `Set '${key}' debounced`,
    });
});
const _setKey = _setKeyList.reduce((previousValue, currentValue, i) => {
    previousValue[knownKeys[i]] = currentValue;
    return previousValue;
}, {});
console.info("Set key", _setKey);
/**
 * Sets the desired `key`s (`domSpec`) `property` (commonly `assignedValue`) to `value` in storage,
 * note this *uses a cache*.
 *
 * ## Use this function, as it will properly update the DOM.
 * ### Note: this will set the `assignedValue` property on the internal `MemoryUnit.domSpec` object by default. To set the `domSpec` property, repeatedly call this function
 *
 *
 * Usage:
 * ```ts
 * await setKey("topbar", "new colour", "assignedValue");
 * ```
 * @param key Key to set
 * @param value Value to set key to
 */
function setKey(key_1, value_1) {
    return __awaiter(this, arguments, void 0, function* (key, value, property = "assignedValue") {
        const _config = yield config;
        if ((value === null || value === void 0 ? void 0 : value.includes("url")) && _config["url-backgrounds"] != "enabled") {
            console.error("Extension URL images disabled: ", _config["url-backgrounds"], "");
            return;
        }
        if (!cache[key]) {
            console.warn("Key", key, "not found in cache during call to `setKey`.\nThe cache should be the source of truth, as storage is slow.\nTo fix this, load the cache with all desired values from storage. This is usually done automatically when `content.ts` is first loaded.\nAutomatically calling `getKey` to load the cache (this is an implementation detail fix) ...");
            cache[key] = yield getKey(key, { fillDefaults: true });
        }
        // TODO: unmounting logic could go here
        // E.g. resetting the DOM to the initial state, then re-adding the new DOM
        // This would allow changes such as to `querySelector` to work as expected
        cache[key].domSpec[property] = value;
        _setKey[key](key, cache[key]); // Debounces
        // Update DOM
        executeDOMSpecification(cache[key].domSpec);
    });
}
/**
 * Handles a user request, including the reset logic and using `setKey` to update the DOM.
 * @param request Request to handle
 */
function handleUserRequest(request) {
    const key = request.key;
    const action = request.do;
    if (action === "RESET") {
        console.log("Handling RESET request for request: ", request);
        if (!resetInfo[key]) {
            console.warn(`Reset info not found for key '${key}' during reset.\nThis is probably a bug. When initializing, remember to capture the initial DOM state.\nDoing nothing.`);
            return;
        }
        // Loop through each initialSpec
        resetInfo[key].forEach((info) => {
            const initial = info.initialSpec;
            // Loop through initial, and set each property
            for (const _property in initial) {
                const property = _property;
                console.log(`Setting ${key}.${property} to ${initial[property]}`);
                setKey(key, initial[property], property);
            }
        });
    }
    else {
        console.log("Handling request:", request);
        setKey(key, action.newAssignedValue);
    }
}
function _updateElem(elem, spec) {
    if (spec.attribute2) {
        // @ts-ignore
        elem[spec.attribute1][spec.attribute2] = "initial";
        // @ts-ignore
        elem[spec.attribute1][spec.attribute2] = spec.assignedValue;
        // console.log(
        //   "[_updateElem] Set attribute2",
        //   spec.attribute2,
        //   "of",
        //   elem,
        //   "to",
        //   spec.assignedValue
        // );
    }
    else {
        console.log("[_updateElem] setting attribute1", spec.attribute1, "of", elem, "to", spec.assignedValue);
        // @ts-ignore
        elem[spec.attribute1] = spec.assignedValue;
    }
}
function executeDOMSpecification(spec) {
    config.then((config) => {
        if (config["*"] != "enabled") {
            console.error("Not going to update the DOM, because the extension is disabled FULLY");
            throw new Error("Extension (fully) disabled: " + config["*"]);
        }
        if (!spec) {
            console.warn("No DOM specification provided. Doing nothing.");
            return;
        }
        if (!(spec === null || spec === void 0 ? void 0 : spec.querySelector)) {
            console.error("No querySelector found in spec:", spec);
            return;
        }
        queryMany(spec.querySelector, (elem) => {
            _updateElem(elem, spec);
        });
    });
}
function queryMany(querySelector, callback) {
    const elements = document.querySelectorAll(querySelector);
    if (elements.length == 0) {
        console.warn(`Did query for '${querySelector}', but matched nothing.\nTry copy pasting this into your browser:\ndocument.querySelectedAll("${querySelector}")\nIf nothing is returned, you may have made a mistake with your query selector.\nRemember to split multiple selectors with commas, like 'nav-bar, #id, .class'`);
    }
    elements.forEach(callback);
}
// #endregion
// #region Runtime Validation
function validateDOMSpecification(spec) {
    if (!spec) {
        console.error("No DOM specification provided. Doing nothing.");
        return false;
    }
    if (!(spec === null || spec === void 0 ? void 0 : spec.querySelector)) {
        console.error("No querySelector found in spec:", spec);
        return false;
    }
    if (!(spec === null || spec === void 0 ? void 0 : spec.attribute1)) {
        console.error("No attribute1 found in spec:", spec);
        return false;
    }
    if (!(spec === null || spec === void 0 ? void 0 : spec.assignedValue)) {
        console.error("No assignedValue found in spec:", spec);
        return false;
    }
    return true;
}
// #endregion
// #region Execution
chrome.storage.sync.get(null, (everything) => {
    var _a, _b, _c;
    if (!everything) {
        console.warn("[initial] No storage found");
        return;
    }
    for (const storageKey in everything) {
        const key = storageKey;
        let _parsed;
        try {
            _parsed = JSON.parse(everything[key]);
        }
        catch (e) {
            console.error(`Failed to parse JSON for key '${key}'\nValue: ${everything[key]}; e:`, e);
            continue;
        }
        const value = _parsed;
        if (!key) {
            console.warn("[initial] No storage key found", key, value);
            continue;
        }
        if (!value) {
            console.warn("[initial] No storage value found", key, value);
            continue;
        }
        if (knownKeys.indexOf(key) == -1) {
            console.warn(`[initial] Key '${key}' found in storage, but not in knownKeys.\nThis is probably a bug.\nValue:`, value);
        }
        if (!validateDOMSpecification(value.domSpec)) {
            const MANUAL_newValue = console.warn(`[initial] Invalid DOM specification found for key '${key}' in initial storage fetch.\nThis is probably a bug.\nValue:`, value, "\nSetting a default value, [fatal] this will override any valid settings data under key", key, "[manual implementation] Setting to");
            chrome.storage.sync.set({
                [key]: JSON.stringify(defaultMemory[key]),
            });
            continue;
        }
        cache[key] = value;
        // Validating value's properties against defaults
        if (((_a = value === null || value === void 0 ? void 0 : value.domSpec) === null || _a === void 0 ? void 0 : _a.querySelector) !==
            ((_c = (_b = defaultMemory[key]) === null || _b === void 0 ? void 0 : _b.domSpec) === null || _c === void 0 ? void 0 : _c.querySelector)) {
            console.warn(`Key '${key}' has a different querySelector than the default.\nThis is probably a bug.\nValue:`, value);
        }
        // Use official means, including updating the DOM
        const newValue = value === null || value === void 0 ? void 0 : value.domSpec.assignedValue;
        setKey(key, newValue);
    }
});
// // Retrieve data from chrome storage and put into cache
// knownKeys.forEach(async (key) => {
//   // Populate cache
//   const data = await getStorageData(key);
//   if (cache[key]) {
//     console.warn(
//       "Overwriting cache for key",
//       key,
//       "because it is initial run.\nThis could happen when duplicate items in `kno wnKeys` list exist."
//     );
//   }
//   console.log(
//     "[initial] Setting cache for key",
//     key,
//     "to assignedValue",
//     data?.domSpec?.assignedValue,
//     "domSpec",
//     data?.domSpec,
//     PROD ? "" : "data:",
//     PROD ? "" : data
//   );
//   cache[key] = data;
//   executeDOMSpecification(data!.domSpec);
// });
// Listen for messages from popup.ts
chrome.runtime.onMessage.addListener((request) => {
    if (!request.__is_user_request) {
        console.warn("Received message from popup.ts, but it was not a user request.\nIgnoring.", request);
        return;
    }
    handleUserRequest(request);
});
// #endregion
// #region 1/10000 rick astley rick roll
// const insertionPoint = document.querySelector("#container");
// const rickRoll = document.createElement("iframe");
// rickRoll.src = "https://www.youtube.com/embed/dQw4w9WgXcQ?autoplay=1&mute=1";
// rickRoll.style.height = "60vh";
// insertionPoint?.insertBefore(rickRoll, insertionPoint.firstChild);
// #endregion
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udGVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImNvbnRlbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0FBQUEsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDO0FBUWxCLE1BQU0sTUFBTSxHQUFvQixLQUFLLENBQ25DLHlIQUF5SCxDQUMxSDtLQUNFLElBQUksQ0FBQyxDQUFDLElBQUksRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO0tBQzNCLElBQUksQ0FBQyxDQUFDLElBQUksRUFBRSxFQUFFO0lBQ2IsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLE1BQWtELENBQUM7SUFDeEUsTUFBTSxNQUFNLEdBQVc7UUFDckIsR0FBRyxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxXQUFXO1FBQzdCLGlCQUFpQixFQUFFLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLFdBQVc7S0FDMUQsQ0FBQztJQUNGLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQztRQUNqQixNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsU0FBUyxDQUFDO1FBQ3hCLE9BQU8sQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBQ0QsSUFBSSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFLENBQUM7UUFDL0IsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsU0FBUyxDQUFDO1FBQ3RDLE9BQU8sQ0FBQyxJQUFJLENBQUMscUNBQXFDLENBQUMsQ0FBQztJQUN0RCxDQUFDO0lBQ0QsT0FBTyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDLENBQUM7SUFDaEMsT0FBTyxNQUFNLENBQUM7SUFDZCxzQ0FBc0M7QUFDeEMsQ0FBQyxDQUFDLENBQUM7QUFxQkwsTUFBTSxTQUFTLEdBQUc7SUFDaEIsUUFBUTtJQUNSLGlCQUFpQjtJQUNqQixTQUFTO0lBQ1Qsa0JBQWtCO0lBQ2xCLFlBQVk7SUFFWixtQkFBbUI7SUFDbkIsVUFBVTtJQUVWLG9CQUFvQjtDQUNaLENBQUM7QUFHWCxzQ0FBc0M7QUFDdEM7O0VBRUU7QUFFRiwrQ0FBK0M7QUFFL0MsTUFBTSxjQUFjLEdBR2hCO0lBQ0YsTUFBTSxFQUFFO1FBQ04sYUFBYSxFQUFFLGFBQWE7UUFDNUIsVUFBVSxFQUFFLE9BQU87UUFDbkIsVUFBVSxFQUFFLFlBQVk7UUFDeEIsaUJBQWlCO1FBQ2pCLGtFQUFrRTtLQUNuRTtJQUNELE9BQU8sRUFBRTtRQUNQLGFBQWEsRUFBRSxpQkFBaUI7UUFDaEMsVUFBVSxFQUFFLE9BQU87UUFDbkIsVUFBVSxFQUFFLFlBQVk7UUFDeEIsaUJBQWlCO1FBQ2pCLHNFQUFzRTtLQUN2RTtJQUNELGdCQUFnQixFQUFFO1FBQ2hCLGFBQWEsRUFBRSw2Q0FBNkM7UUFDNUQsVUFBVSxFQUFFLE9BQU87UUFDbkIsVUFBVSxFQUFFLFlBQVk7UUFDeEIseUNBQXlDO1FBQ3pDLGtEQUFrRDtRQUNsRCw0QkFBNEI7S0FDN0I7SUFDRCxVQUFVLEVBQUU7UUFDVixhQUFhLEVBQUUsTUFBTTtRQUNyQixVQUFVLEVBQUUsT0FBTztRQUNuQixVQUFVLEVBQUUsWUFBWTtRQUN4QixpQkFBaUI7UUFDakIsNkRBQTZEO1FBQzdELDBCQUEwQjtLQUMzQjtJQUNELGlCQUFpQixFQUFFO1FBQ2pCLGFBQWEsRUFBRSxzREFBc0Q7UUFDckUsVUFBVSxFQUFFLE9BQU87UUFDbkIsVUFBVSxFQUFFLFlBQVk7S0FDekI7SUFDRCxRQUFRLEVBQUU7UUFDUixhQUFhLEVBQUUsV0FBVztRQUMxQixVQUFVLEVBQUUsV0FBVztLQUN4QjtDQUNGLENBQUM7QUFFRjs7R0FFRztBQUNILE1BQU0sYUFBYSxHQUF1QyxFQUFTLENBQUM7QUFDcEUsS0FBSyxNQUFNLElBQUksSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFLENBQUM7SUFDL0MsTUFBTSxHQUFHLEdBQUcsSUFBaUIsQ0FBQztJQUM5QixNQUFNLEtBQUssR0FBRyxtQkFBbUIsQ0FBQztJQUNsQyxJQUFJLGFBQWEsR0FBc0MsS0FBSyxDQUFDO0lBRTdELE1BQU0sSUFBSSxHQUFHLGNBQWMsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUNqQyxNQUFNLElBQUksR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUN4RCxJQUFJLGNBQWMsQ0FBQztJQUNuQixJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDVixPQUFPLENBQUMsS0FBSyxDQUNYLDhDQUE4QyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQ25FLENBQUM7UUFDRixjQUFjLEdBQUcsRUFBRSxVQUFVLEVBQUUsU0FBUyxFQUFFLENBQUM7SUFDN0MsQ0FBQztTQUFNLENBQUM7UUFDTixjQUFjLEdBQUcsTUFBTSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ2pELENBQUM7SUFFRCxJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNwQixJQUFJLElBQUksQ0FBQyxVQUFVLEtBQUssT0FBTyxFQUFFLENBQUM7WUFDaEMsT0FBTyxDQUFDLElBQUksQ0FDVix1SEFBdUgsQ0FDeEgsQ0FBQztZQUNGLGFBQWE7WUFDYixhQUFhLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDekQsQ0FBQzthQUFNLENBQUM7WUFDTixhQUFhO1lBQ2IsYUFBYSxHQUFHLGNBQWMsQ0FBQyxJQUFJLENBQUMsVUFBVyxDQUFDLENBQUM7UUFDbkQsQ0FBQztJQUNILENBQUM7U0FBTSxDQUFDO1FBQ04sYUFBYTtRQUNiLGFBQWEsR0FBRyxDQUFDLElBQUksYUFBSixJQUFJLGNBQUosSUFBSSxHQUFJLEVBQUUsR0FBRyxFQUFFLFNBQVMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ2hFLENBQUM7SUFFRCx3RUFBd0U7SUFFeEUsYUFBYSxDQUFDLEdBQUcsQ0FBQyxtQ0FDYixjQUFjLENBQUMsR0FBRyxDQUFDLEtBQ3RCLGFBQWEsRUFBRSxhQUFhLEtBQUssS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLGFBQWEsR0FDNUQsQ0FBQztBQUNKLENBQUM7QUFDRCxNQUFNO0FBQ04sMkJBQTJCO0FBQzNCLHlEQUF5RDtBQUN6RCxvQ0FBb0M7QUFDcEMsNEJBQTRCO0FBQzVCLDhCQUE4QjtBQUM5QixPQUFPO0FBRVAsTUFBTSxhQUFhLEdBQXFCLEVBQVMsQ0FBQztBQUNsRCxLQUFLLE1BQU0sR0FBRyxJQUFJLFNBQVMsRUFBRSxDQUFDO0lBQzVCLGFBQWEsQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLE9BQU8sRUFBRSxhQUFhLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQztBQUN2RCxDQUFDO0FBQ0QsS0FBSyxNQUFNLEdBQUcsSUFBSSxTQUFTLEVBQUUsQ0FBQztJQUM1QixJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUM7UUFDeEIsT0FBTyxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsOEJBQThCLENBQUMsQ0FBQztJQUMxRCxDQUFDO0lBQ0QsSUFBSSxDQUFDLENBQUEsTUFBQSxhQUFhLENBQUMsR0FBRyxDQUFDLDBDQUFFLE9BQU8sQ0FBQSxFQUFFLENBQUM7UUFDakMsT0FBTyxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsd0NBQXdDLENBQUMsQ0FBQztJQUNwRSxDQUFDO0FBQ0gsQ0FBQztBQUVELE9BQU8sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLENBQUMsQ0FBQztBQUVqQyxrQkFBa0I7QUFFbEI7Ozs7Ozs7Ozs7Ozs7R0FhRztBQUNILE1BQU0sUUFBUSxHQUFHLENBQ2YsUUFBVyxFQUNYLE9BQWUsRUFDZixLQUF5RCxFQUN6RCxFQUFFO0lBQ0YsSUFBSSxPQUFzQyxDQUFDO0lBQzNDLE9BQU8sQ0FBQyxHQUFHLElBQW1CLEVBQWlCLEVBQUU7UUFDL0MsSUFBSSxNQUFXLENBQUM7UUFDaEIsQ0FBQSxLQUFLLGFBQUwsS0FBSyx1QkFBTCxLQUFLLENBQUUsWUFBWSxFQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssYUFBTCxLQUFLLHVCQUFMLEtBQUssQ0FBRSxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1FBQzlELE9BQU8sSUFBSSxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDakMsT0FBTyxHQUFHLFVBQVUsQ0FBQyxHQUFHLEVBQUU7O1lBQ3hCLE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBQSxLQUFLLGFBQUwsS0FBSyx1QkFBTCxLQUFLLENBQUUsYUFBYSxtQ0FBSSxZQUFZLENBQUMsQ0FBQztZQUNsRCxNQUFNLEdBQUcsUUFBUSxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUM7UUFDN0IsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ1osT0FBTyxNQUFNLENBQUM7SUFDaEIsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDO0FBd0JGLGdCQUFnQjtBQUVoQixNQUFNLEtBQUssR0FBdUIsRUFBRSxDQUFDO0FBYXJDLE1BQU0sU0FBUyxHQUF3QixFQUFFLENBQUM7QUFFMUMsS0FBSyxNQUFNLElBQUksSUFBSSxTQUFTLEVBQUUsQ0FBQztJQUM3QixNQUFNLEdBQUcsR0FBRyxJQUFpQixDQUFDO0lBQzlCLFNBQVMsQ0FBQyxHQUFHLENBQUMsR0FBRztRQUNmO1lBQ0UsV0FBVyxFQUFFLGFBQWEsQ0FBQyxHQUFHLENBQUM7U0FDaEM7S0FDRixDQUFDO0FBQ0osQ0FBQztBQUNELGlDQUFpQztBQUVqQyxhQUFhO0FBRWIsK0JBQStCO0FBRS9COzs7Ozs7OztHQVFHO0FBQ0gsTUFBTSxjQUFjLEdBQUcsQ0FBQyxHQUFjLEVBQW1DLEVBQUUsQ0FDekUsSUFBSSxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLEVBQUUsQ0FDOUIsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxNQUFNLEVBQUUsRUFBRTs7SUFDeEMsSUFBSSxZQUF3QixDQUFDO0lBQzdCLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQztRQUNqQixPQUFPLENBQUMsSUFBSSxDQUNWLHdDQUF3QyxFQUN4QyxHQUFHLEVBQ0gsWUFBWSxDQUNiLENBQUM7UUFDRixPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDbkIsT0FBTztJQUNULENBQUM7SUFDRCxJQUFJLENBQUM7UUFDSCxZQUFZLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFRLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQztRQUNYLE9BQU8sQ0FBQyxLQUFLLENBQUMsd0JBQXdCLEVBQUUsTUFBTSxFQUFFLFVBQVUsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNqRSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDVixPQUFPO0lBQ1QsQ0FBQztJQUNELE9BQU8sQ0FBQyxHQUFHLENBQ1QsdUJBQXVCLEVBQ3ZCLEdBQUcsRUFDSCxlQUFlLEVBQ2YsTUFBQSxZQUFZLGFBQVosWUFBWSx1QkFBWixZQUFZLENBQUUsT0FBTywwQ0FBRSxhQUFhLEVBQ3BDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxTQUFTLEVBQ3JCLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxZQUFZLEVBQ3hCLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQ2xCLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEVBQ3ZCLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxZQUFZLEVBQ3hCLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FDckMsQ0FBQztJQUNGLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztRQUNsQixNQUFNLENBQUMsSUFBSSxLQUFLLENBQUMsd0JBQXdCLENBQUMsQ0FBQyxDQUFDO1FBQzVDLE9BQU87SUFDVCxDQUFDO0lBQ0QsSUFBSSxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUMxQixNQUFNLENBQUMsSUFBSSxLQUFLLENBQUMsOEJBQThCLENBQUMsQ0FBQyxDQUFDO1FBQ2xELE9BQU87SUFDVCxDQUFDO0lBQ0QsSUFBSSxDQUFDLHdCQUF3QixDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDO1FBQ3BELE1BQU0sQ0FBQyxJQUFJLEtBQUssQ0FBQyxtQ0FBbUMsQ0FBQyxDQUFDLENBQUM7UUFDdkQsT0FBTztJQUNULENBQUM7SUFFRCxNQUFNLENBQUMsT0FBTyxDQUFDLFNBQVM7UUFDdEIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDakQsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQztBQUM1QixDQUFDLENBQUMsQ0FDSCxDQUFDO0FBRUo7Ozs7Ozs7O0dBUUc7QUFDSCxNQUFNLGNBQWMsR0FBRyxDQUFDLEdBQWMsRUFBRSxJQUFnQixFQUFvQixFQUFFLENBQzVFLElBQUksT0FBTyxDQUFDLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxFQUFFO0lBQzlCLE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDekMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxXQUFXLEVBQUUsRUFBRSxHQUFHLEVBQUU7UUFDbkQsT0FBTyxDQUFDLEdBQUcsQ0FDVCx1QkFBdUIsRUFDdkIsR0FBRyxFQUNILE9BQU8sRUFDUCxJQUFJLEVBQ0osSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLGFBQWEsRUFDekIsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFdBQVcsRUFDdkIsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLGFBQWEsRUFDekIsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUNwQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMseUNBQXlDLENBQ3RELENBQUM7UUFDRixJQUFJLElBQUk7WUFBRSxPQUFPO1FBQ2pCLE9BQU87UUFDUCxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLE1BQU0sRUFBRSxFQUFFO1lBQ3hDLElBQUksTUFBTSxDQUFDLEdBQUcsQ0FBQyxLQUFLLFdBQVcsRUFBRSxDQUFDO2dCQUNoQyxPQUFPLENBQUMsR0FBRyxDQUFDLHNDQUFzQyxDQUFDLENBQUM7Z0JBQ3BELE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNoQixDQUFDO2lCQUFNLENBQUM7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFDO2dCQUNsRCxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDaEIsQ0FBQztRQUNILENBQUMsQ0FBQyxDQUFDO1FBQ0gsTUFBTSxDQUFDLE9BQU8sQ0FBQyxTQUFTO1lBQ3RCLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ2pELENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDcEIsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQztBQUVMOzs7Ozs7Ozs7O0dBVUc7QUFDSCxTQUFlLE1BQU0sQ0FDbkIsR0FBYyxFQUNkLE9BQW1DOztRQUVuQyxJQUFJLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDO1lBQ2YsT0FBTyxLQUFLLENBQUMsR0FBRyxDQUFFLENBQUM7UUFDckIsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxHQUFHLEVBQUUsMENBQTBDLENBQUMsQ0FBQztZQUNyRSxNQUFNLENBQUMsR0FBRyxNQUFNLGNBQWMsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNwQyxJQUFJLENBQUMsRUFBRSxDQUFDO2dCQUNOLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ2YsT0FBTyxDQUFDLENBQUM7WUFDWCxDQUFDO2lCQUFNLENBQUM7Z0JBQ04sSUFBSSxPQUFPLGFBQVAsT0FBTyx1QkFBUCxPQUFPLENBQUUsWUFBWSxFQUFFLENBQUM7b0JBQzFCLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLEdBQUcsRUFBRSw2Q0FBNkMsQ0FBQyxDQUFDO29CQUN4RSxNQUFNLFVBQVUsR0FBRyxhQUFhLENBQUMsR0FBRyxDQUFDLENBQUM7b0JBQ3RDLG1DQUFtQztvQkFDbkMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLFVBQVUsQ0FBQztvQkFDeEIsT0FBTyxVQUFVLENBQUM7Z0JBQ3BCLENBQUM7cUJBQU0sQ0FBQztvQkFDTixPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxHQUFHLEVBQUUsMkNBQTJDLENBQUMsQ0FBQztvQkFDdEUsT0FBTyxTQUFTLENBQUM7Z0JBQ25CLENBQUM7WUFDSCxDQUFDO1FBQ0gsQ0FBQztJQUNILENBQUM7Q0FBQTtBQUVELE1BQU0sV0FBVyxHQUE0QixTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLEVBQUU7SUFDakUsT0FBTyxRQUFRLENBQUMsY0FBYyxFQUFFLElBQUksRUFBRTtRQUNwQyxhQUFhLEVBQUUsUUFBUSxHQUFHLFlBQVk7UUFDdEMsWUFBWSxFQUFFLFFBQVEsR0FBRyxhQUFhO0tBQ3ZDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDO0FBQ0gsTUFBTSxPQUFPLEdBQTZDLFdBQVcsQ0FBQyxNQUFNLENBQzFFLENBQUMsYUFBYSxFQUFFLFlBQVksRUFBRSxDQUFDLEVBQUUsRUFBRTtJQUNqQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsWUFBWSxDQUFDO0lBQzNDLE9BQU8sYUFBYSxDQUFDO0FBQ3ZCLENBQUMsRUFDRCxFQUFTLENBQ1YsQ0FBQztBQUVGLE9BQU8sQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO0FBRWpDOzs7Ozs7Ozs7Ozs7OztHQWNHO0FBQ0gsU0FBZSxNQUFNO3lEQUduQixHQUFjLEVBQ2QsS0FBc0MsRUFDdEMsV0FBcUIsZUFBc0I7UUFFM0MsTUFBTSxPQUFPLEdBQUcsTUFBTSxNQUFNLENBQUM7UUFDN0IsSUFBSSxDQUFBLEtBQUssYUFBTCxLQUFLLHVCQUFMLEtBQUssQ0FBRSxRQUFRLENBQUMsS0FBSyxDQUFDLEtBQUksT0FBTyxDQUFDLGlCQUFpQixDQUFDLElBQUksU0FBUyxFQUFFLENBQUM7WUFDdEUsT0FBTyxDQUFDLEtBQUssQ0FDWCxpQ0FBaUMsRUFDakMsT0FBTyxDQUFDLGlCQUFpQixDQUFDLEVBQzFCLEVBQUUsQ0FDSCxDQUFDO1lBQ0YsT0FBTztRQUNULENBQUM7UUFFRCxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDaEIsT0FBTyxDQUFDLElBQUksQ0FDVixLQUFLLEVBQ0wsR0FBRyxFQUNILGlWQUFpVixDQUNsVixDQUFDO1lBQ0YsS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLE1BQU0sTUFBTSxDQUFDLEdBQUcsRUFBRSxFQUFFLFlBQVksRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDO1FBQ3pELENBQUM7UUFFRCx1Q0FBdUM7UUFDdkMsMEVBQTBFO1FBQzFFLDBFQUEwRTtRQUUxRSxLQUFLLENBQUMsR0FBRyxDQUFFLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxHQUFHLEtBQUssQ0FBQztRQUN0QyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxHQUFHLENBQUUsQ0FBQyxDQUFDLENBQUMsWUFBWTtRQUU1QyxhQUFhO1FBQ2IsdUJBQXVCLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQy9DLENBQUM7Q0FBQTtBQXdCRDs7O0dBR0c7QUFDSCxTQUFTLGlCQUFpQixDQUFDLE9BQW9CO0lBQzdDLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUM7SUFDeEIsTUFBTSxNQUFNLEdBQUcsT0FBTyxDQUFDLEVBQUUsQ0FBQztJQUMxQixJQUFJLE1BQU0sS0FBSyxPQUFPLEVBQUUsQ0FBQztRQUN2QixPQUFPLENBQUMsR0FBRyxDQUFDLHNDQUFzQyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQzdELElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQztZQUNwQixPQUFPLENBQUMsSUFBSSxDQUNWLGlDQUFpQyxHQUFHLHdIQUF3SCxDQUM3SixDQUFDO1lBQ0YsT0FBTztRQUNULENBQUM7UUFDRCxnQ0FBZ0M7UUFDaEMsU0FBUyxDQUFDLEdBQUcsQ0FBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksRUFBRSxFQUFFO1lBQy9CLE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUM7WUFDakMsOENBQThDO1lBQzlDLEtBQUssTUFBTSxTQUFTLElBQUksT0FBTyxFQUFFLENBQUM7Z0JBQ2hDLE1BQU0sUUFBUSxHQUFHLFNBQWlDLENBQUM7Z0JBRW5ELE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxHQUFHLElBQUksUUFBUSxPQUFPLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUM7Z0JBRWxFLE1BQU0sQ0FBQyxHQUFHLEVBQUUsT0FBTyxDQUFDLFFBQVEsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDO1lBQzNDLENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7U0FBTSxDQUFDO1FBQ04sT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUMxQyxNQUFNLENBQUMsR0FBRyxFQUFFLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7QUFDSCxDQUFDO0FBc0JELFNBQVMsV0FBVyxDQUFDLElBQVUsRUFBRSxJQUFzQjtJQUNyRCxJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNwQixhQUFhO1FBQ2IsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsU0FBUyxDQUFDO1FBQ25ELGFBQWE7UUFDYixJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO1FBRTVELGVBQWU7UUFDZixvQ0FBb0M7UUFDcEMscUJBQXFCO1FBQ3JCLFVBQVU7UUFDVixVQUFVO1FBQ1YsVUFBVTtRQUNWLHVCQUF1QjtRQUN2QixLQUFLO0lBQ1AsQ0FBQztTQUFNLENBQUM7UUFDTixPQUFPLENBQUMsR0FBRyxDQUNULGtDQUFrQyxFQUNsQyxJQUFJLENBQUMsVUFBVSxFQUNmLElBQUksRUFDSixJQUFJLEVBQ0osSUFBSSxFQUNKLElBQUksQ0FBQyxhQUFhLENBQ25CLENBQUM7UUFDRixhQUFhO1FBQ2IsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO0lBQzdDLENBQUM7QUFDSCxDQUFDO0FBRUQsU0FBUyx1QkFBdUIsQ0FBQyxJQUFzQjtJQUNyRCxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxFQUFFLEVBQUU7UUFDckIsSUFBSSxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksU0FBUyxFQUFFLENBQUM7WUFDN0IsT0FBTyxDQUFDLEtBQUssQ0FDWCxzRUFBc0UsQ0FDdkUsQ0FBQztZQUNGLE1BQU0sSUFBSSxLQUFLLENBQUMsOEJBQThCLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFDaEUsQ0FBQztRQUNELElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNWLE9BQU8sQ0FBQyxJQUFJLENBQUMsK0NBQStDLENBQUMsQ0FBQztZQUM5RCxPQUFPO1FBQ1QsQ0FBQztRQUNELElBQUksQ0FBQyxDQUFBLElBQUksYUFBSixJQUFJLHVCQUFKLElBQUksQ0FBRSxhQUFhLENBQUEsRUFBRSxDQUFDO1lBQ3pCLE9BQU8sQ0FBQyxLQUFLLENBQUMsaUNBQWlDLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDdkQsT0FBTztRQUNULENBQUM7UUFDRCxTQUFTLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDLElBQUksRUFBRSxFQUFFO1lBQ3JDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDMUIsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUM7QUFFRCxTQUFTLFNBQVMsQ0FBQyxhQUFxQixFQUFFLFFBQThCO0lBQ3RFLE1BQU0sUUFBUSxHQUFHLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUMxRCxJQUFJLFFBQVEsQ0FBQyxNQUFNLElBQUksQ0FBQyxFQUFFLENBQUM7UUFDekIsT0FBTyxDQUFDLElBQUksQ0FDVixrQkFBa0IsYUFBYSxpR0FBaUcsYUFBYSxrS0FBa0ssQ0FDaFQsQ0FBQztJQUNKLENBQUM7SUFDRCxRQUFRLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzdCLENBQUM7QUFFRCxhQUFhO0FBRWIsNkJBQTZCO0FBRTdCLFNBQVMsd0JBQXdCLENBQUMsSUFBc0I7SUFDdEQsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO1FBQ1YsT0FBTyxDQUFDLEtBQUssQ0FBQywrQ0FBK0MsQ0FBQyxDQUFDO1FBQy9ELE9BQU8sS0FBSyxDQUFDO0lBQ2YsQ0FBQztJQUNELElBQUksQ0FBQyxDQUFBLElBQUksYUFBSixJQUFJLHVCQUFKLElBQUksQ0FBRSxhQUFhLENBQUEsRUFBRSxDQUFDO1FBQ3pCLE9BQU8sQ0FBQyxLQUFLLENBQUMsaUNBQWlDLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDdkQsT0FBTyxLQUFLLENBQUM7SUFDZixDQUFDO0lBQ0QsSUFBSSxDQUFDLENBQUEsSUFBSSxhQUFKLElBQUksdUJBQUosSUFBSSxDQUFFLFVBQVUsQ0FBQSxFQUFFLENBQUM7UUFDdEIsT0FBTyxDQUFDLEtBQUssQ0FBQyw4QkFBOEIsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUNwRCxPQUFPLEtBQUssQ0FBQztJQUNmLENBQUM7SUFDRCxJQUFJLENBQUMsQ0FBQSxJQUFJLGFBQUosSUFBSSx1QkFBSixJQUFJLENBQUUsYUFBYSxDQUFBLEVBQUUsQ0FBQztRQUN6QixPQUFPLENBQUMsS0FBSyxDQUFDLGlDQUFpQyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3ZELE9BQU8sS0FBSyxDQUFDO0lBQ2YsQ0FBQztJQUNELE9BQU8sSUFBSSxDQUFDO0FBQ2QsQ0FBQztBQUVELGFBQWE7QUFFYixvQkFBb0I7QUFDcEIsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxDQUFDLFVBQWtDLEVBQUUsRUFBRTs7SUFDbkUsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ2hCLE9BQU8sQ0FBQyxJQUFJLENBQUMsNEJBQTRCLENBQUMsQ0FBQztRQUMzQyxPQUFPO0lBQ1QsQ0FBQztJQUNELEtBQUssTUFBTSxVQUFVLElBQUksVUFBVSxFQUFFLENBQUM7UUFDcEMsTUFBTSxHQUFHLEdBQUcsVUFBdUIsQ0FBQztRQUNwQyxJQUFJLE9BQU8sQ0FBQztRQUNaLElBQUksQ0FBQztZQUNILE9BQU8sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1FBQ3hDLENBQUM7UUFBQyxPQUFPLENBQUMsRUFBRSxDQUFDO1lBQ1gsT0FBTyxDQUFDLEtBQUssQ0FDWCxpQ0FBaUMsR0FBRyxhQUFhLFVBQVUsQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUN0RSxDQUFDLENBQ0YsQ0FBQztZQUNGLFNBQVM7UUFDWCxDQUFDO1FBQ0QsTUFBTSxLQUFLLEdBQUcsT0FBcUIsQ0FBQztRQUVwQyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7WUFDVCxPQUFPLENBQUMsSUFBSSxDQUFDLGdDQUFnQyxFQUFFLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUMzRCxTQUFTO1FBQ1gsQ0FBQztRQUVELElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNYLE9BQU8sQ0FBQyxJQUFJLENBQUMsa0NBQWtDLEVBQUUsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQzdELFNBQVM7UUFDWCxDQUFDO1FBRUQsSUFBSSxTQUFTLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUM7WUFDakMsT0FBTyxDQUFDLElBQUksQ0FDVixrQkFBa0IsR0FBRyw0RUFBNEUsRUFDakcsS0FBSyxDQUNOLENBQUM7UUFDSixDQUFDO1FBRUQsSUFBSSxDQUFDLHdCQUF3QixDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDO1lBQzdDLE1BQU0sZUFBZSxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQ2xDLHNEQUFzRCxHQUFHLDhEQUE4RCxFQUN2SCxLQUFLLEVBQ0wseUZBQXlGLEVBQ3pGLEdBQUcsRUFDSCxvQ0FBb0MsQ0FDckMsQ0FBQztZQUNGLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztnQkFDdEIsQ0FBQyxHQUFHLENBQUMsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQzthQUMxQyxDQUFDLENBQUM7WUFFSCxTQUFTO1FBQ1gsQ0FBQztRQUVELEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxLQUFLLENBQUM7UUFFbkIsaURBQWlEO1FBQ2pELElBQ0UsQ0FBQSxNQUFBLEtBQUssYUFBTCxLQUFLLHVCQUFMLEtBQUssQ0FBRSxPQUFPLDBDQUFFLGFBQWE7YUFDN0IsTUFBQSxNQUFBLGFBQWEsQ0FBQyxHQUFHLENBQUMsMENBQUUsT0FBTywwQ0FBRSxhQUFhLENBQUEsRUFDMUMsQ0FBQztZQUNELE9BQU8sQ0FBQyxJQUFJLENBQ1YsUUFBUSxHQUFHLG9GQUFvRixFQUMvRixLQUFLLENBQ04sQ0FBQztRQUNKLENBQUM7UUFFRCxpREFBaUQ7UUFFakQsTUFBTSxRQUFRLEdBQUcsS0FBSyxhQUFMLEtBQUssdUJBQUwsS0FBSyxDQUFFLE9BQU8sQ0FBQyxhQUFhLENBQUM7UUFDOUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxRQUFRLENBQUMsQ0FBQztJQUN4QixDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUM7QUFFSCwwREFBMEQ7QUFDMUQscUNBQXFDO0FBQ3JDLHNCQUFzQjtBQUN0Qiw0Q0FBNEM7QUFDNUMsc0JBQXNCO0FBQ3RCLG9CQUFvQjtBQUNwQixxQ0FBcUM7QUFDckMsYUFBYTtBQUNiLHlHQUF5RztBQUN6RyxTQUFTO0FBQ1QsTUFBTTtBQUNOLGlCQUFpQjtBQUNqQix5Q0FBeUM7QUFDekMsV0FBVztBQUNYLDBCQUEwQjtBQUMxQixvQ0FBb0M7QUFDcEMsaUJBQWlCO0FBQ2pCLHFCQUFxQjtBQUNyQiwyQkFBMkI7QUFDM0IsdUJBQXVCO0FBQ3ZCLE9BQU87QUFDUCx1QkFBdUI7QUFDdkIsNENBQTRDO0FBQzVDLE1BQU07QUFFTixvQ0FBb0M7QUFDcEMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUMsT0FBb0IsRUFBRSxFQUFFO0lBQzVELElBQUksQ0FBQyxPQUFPLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztRQUMvQixPQUFPLENBQUMsSUFBSSxDQUNWLDJFQUEyRSxFQUMzRSxPQUFPLENBQ1IsQ0FBQztRQUNGLE9BQU87SUFDVCxDQUFDO0lBQ0QsaUJBQWlCLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDN0IsQ0FBQyxDQUFDLENBQUM7QUFFSCxhQUFhO0FBRWIsd0NBQXdDO0FBRXhDLCtEQUErRDtBQUMvRCxxREFBcUQ7QUFDckQsZ0ZBQWdGO0FBQ2hGLGtDQUFrQztBQUNsQyxxRUFBcUU7QUFFckUsYUFBYSIsInNvdXJjZXNDb250ZW50IjpbImNvbnN0IFBST0QgPSB0cnVlO1xuXG4vLyBjb25zb2xlLmxvZyhcIlRFU1RJTkchXCIpO1xuLy8gY29uc29sZS5sb2coXCJ3aW5kb3dcIiwgd2luZG93KTtcbnR5cGUgY29uZmlncyA9IFwiKlwiIHwgXCJ1cmwtYmFja2dyb3VuZHNcIjtcbnR5cGUgQ29uZmlnID0ge1xuICBba2V5IGluIGNvbmZpZ3NdOiBcImVuYWJsZWRcIiB8IHN0cmluZztcbn07XG5jb25zdCBjb25maWc6IFByb21pc2U8Q29uZmlnPiA9IGZldGNoKFxuICBcImh0dHBzOi8vZmlyZXN0b3JlLmdvb2dsZWFwaXMuY29tL3YxL3Byb2plY3RzL2JldHRlci1zY2hvb2xib3gtMWY2NDcvZGF0YWJhc2VzLyhkZWZhdWx0KS9kb2N1bWVudHMvZGVmYXVsdC1jb25maWcvZ2xvYmFsXCJcbilcbiAgLnRoZW4oKHJlc3ApID0+IHJlc3AuanNvbigpKVxuICAudGhlbigocmVzcCkgPT4ge1xuICAgIGNvbnN0IF9jb25maWcgPSByZXNwLmZpZWxkcyBhcyBSZWNvcmQ8Y29uZmlncywgeyBzdHJpbmdWYWx1ZTogc3RyaW5nIH0+O1xuICAgIGNvbnN0IGNvbmZpZzogQ29uZmlnID0ge1xuICAgICAgXCIqXCI6IF9jb25maWdbXCIqXCJdLnN0cmluZ1ZhbHVlLFxuICAgICAgXCJ1cmwtYmFja2dyb3VuZHNcIjogX2NvbmZpZ1tcInVybC1iYWNrZ3JvdW5kc1wiXS5zdHJpbmdWYWx1ZSxcbiAgICB9O1xuICAgIGlmICghY29uZmlnW1wiKlwiXSkge1xuICAgICAgY29uZmlnW1wiKlwiXSA9IFwiZW5hYmxlZFwiO1xuICAgICAgY29uc29sZS53YXJuKFwiTm8gY29uZmlnIGZvdW5kIGZvciAqXCIpO1xuICAgIH1cbiAgICBpZiAoIWNvbmZpZ1tcInVybC1iYWNrZ3JvdW5kc1wiXSkge1xuICAgICAgY29uZmlnW1widXJsLWJhY2tncm91bmRzXCJdID0gXCJlbmFibGVkXCI7XG4gICAgICBjb25zb2xlLndhcm4oXCJObyBjb25maWcgZm91bmQgZm9yIHVybC1iYWNrZ3JvdW5kc1wiKTtcbiAgICB9XG4gICAgY29uc29sZS53YXJuKFwiQ29uZmlnOlwiLCBjb25maWcpO1xuICAgIHJldHVybiBjb25maWc7XG4gICAgLy8gWFhYIHBvdGVudGlhbCBydW50aW1lIGNoZWNraW5nIGhlcmVcbiAgfSk7XG5cbnR5cGUgcXVlcnlTZWxlY3RvciA9IHN0cmluZztcbnR5cGUgYXR0cjEgPSBcIl9fc3R5bGVfX1wiIHwgXCJzcmNcIiB8IFwiaW5uZXJIVE1MXCI7XG50eXBlIGF0dHIyID0gXCJiYWNrZ3JvdW5kXCIgfCB1bmRlZmluZWQ7XG50eXBlIGFzc2lnbmVkVmFsdWUgPSBzdHJpbmc7XG5cbi8qKlxuICogVXNlcyAtIGluIG5hbWUsIGkuZS5cbiAqXG4gKiBkZWZhdWx0LWNvbmZpZyA9IHsuLi59XG4gKi9cbnR5cGUgX2RlZmF1bHRDb25maWcgPSB7XG4gIF9pbmJ1aWx0X3NoYXJlZDogeyBfaW5idWlsdF9rZXlzOiBLbm93bktleXNbXSB9ICYge1xuICAgIFtrZXkgaW4gS25vd25LZXlzXTogW3F1ZXJ5U2VsZWN0b3IsIGF0dHIxLCBhdHRyMl07XG4gIH07XG4gIGVtbWFudWVsX3NlbnNpYmxlX2RlZmF1bHRzOiB7XG4gICAgW2tleSBpbiBLbm93bktleXNdOiBhc3NpZ25lZFZhbHVlO1xuICB9O1xufTtcblxuY29uc3Qga25vd25LZXlzID0gW1xuICBcInRvcEJhclwiLFxuICAvLyBcInRvcEJhckljb25zXCIsXG4gIFwibGVmdEJhclwiLFxuICBcInRpbWV0YWJsZUhlYWRlcnNcIixcbiAgXCJiYWNrZ3JvdW5kXCIsXG5cbiAgXCJpY29uTm90aWZpY2F0aW9uc1wiLFxuICBcIm5hbWVUZXh0XCIsXG5cbiAgLy8gXCJzZWN0aW9uSGVhZGVyc1wiLFxuXSBhcyBjb25zdDtcbmV4cG9ydCB0eXBlIEtub3duS2V5cyA9IHR5cGVvZiBrbm93bktleXNbbnVtYmVyXTtcblxuLy8gVE9ETzogSW1wbGVtZW50IHRleHQgY29sb3VyIGNoYW5nZXNcbi8qXG4tLWJvZHktZm9yZWdyb3VuZC1oMS1zOiAxMCU7XG4qL1xuXG4vLyBUT0RPOiBQb3B1bGF0ZSBkZWZhdWx0IHZhbHVlcyBmb3Iga25vd24ga2V5c1xuXG5jb25zdCBfa25vd25EZWZhdWx0czogUmVjb3JkPFxuICBLbm93bktleXMsXG4gIE9taXQ8RE9NU3BlY2lmaWNhdGlvbiwgXCJhc3NpZ25lZFZhbHVlXCI+XG4+ID0ge1xuICB0b3BCYXI6IHtcbiAgICBxdWVyeVNlbGVjdG9yOiBcIm5hdi50YWItYmFyXCIsXG4gICAgYXR0cmlidXRlMTogXCJzdHlsZVwiLFxuICAgIGF0dHJpYnV0ZTI6IFwiYmFja2dyb3VuZFwiLFxuICAgIC8vIGFzc2lnbmVkVmFsdWU6XG4gICAgLy8gICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwibmF2LnRhYi1iYXJcIik/LnN0eWxlLmJhY2tncm91bmRDb2xvcixcbiAgfSxcbiAgbGVmdEJhcjoge1xuICAgIHF1ZXJ5U2VsZWN0b3I6IFwiYXNpZGUjbGVmdC1tZW51XCIsXG4gICAgYXR0cmlidXRlMTogXCJzdHlsZVwiLFxuICAgIGF0dHJpYnV0ZTI6IFwiYmFja2dyb3VuZFwiLFxuICAgIC8vIGFzc2lnbmVkVmFsdWU6XG4gICAgLy8gICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiYXNpZGUjbGVmdC1tZW51XCIpPy5zdHlsZS5iYWNrZ3JvdW5kQ29sb3IsXG4gIH0sXG4gIHRpbWV0YWJsZUhlYWRlcnM6IHtcbiAgICBxdWVyeVNlbGVjdG9yOiBcInRhYmxlLnRpbWV0YWJsZVtkYXRhLXRpbWV0YWJsZV0+dGhlYWQ+dHI+dGhcIixcbiAgICBhdHRyaWJ1dGUxOiBcInN0eWxlXCIsXG4gICAgYXR0cmlidXRlMjogXCJiYWNrZ3JvdW5kXCIsXG4gICAgLy8gYXNzaWduZWRWYWx1ZTogZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcbiAgICAvLyAgIFwidGFibGUudGltZXRhYmxlW2RhdGEtdGltZXRhYmxlXT50aGVhZD50cj50aFwiXG4gICAgLy8gKT8uc3R5bGUuYmFja2dyb3VuZENvbG9yLFxuICB9LFxuICBiYWNrZ3JvdW5kOiB7XG4gICAgcXVlcnlTZWxlY3RvcjogXCJib2R5XCIsXG4gICAgYXR0cmlidXRlMTogXCJzdHlsZVwiLFxuICAgIGF0dHJpYnV0ZTI6IFwiYmFja2dyb3VuZFwiLFxuICAgIC8vIGFzc2lnbmVkVmFsdWU6XG4gICAgLy8gICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiYm9keVwiKT8uc3R5bGUuYmFja2dyb3VuZENvbG9yID8/XG4gICAgLy8gICBcInJnYigyMzcsIDIzNywgMjM3KVwiLFxuICB9LFxuICBpY29uTm90aWZpY2F0aW9uczoge1xuICAgIHF1ZXJ5U2VsZWN0b3I6IFwiYS5pY29uLW5vdGlmaWNhdGlvbnMsIGxhYmVsI25vdGlmaWNhdGlvbi10b2dnbGUtZnVsbFwiLFxuICAgIGF0dHJpYnV0ZTE6IFwic3R5bGVcIixcbiAgICBhdHRyaWJ1dGUyOiBcImJhY2tncm91bmRcIixcbiAgfSxcbiAgbmFtZVRleHQ6IHtcbiAgICBxdWVyeVNlbGVjdG9yOiBcImgxPnN0cm9uZ1wiLFxuICAgIGF0dHJpYnV0ZTE6IFwiaW5uZXJUZXh0XCIsXG4gIH0sXG59O1xuXG4vKipcbiAqIERlZmF1bHQgbWVtb3J5IHVuaXRzLCBsb2FkZWQgd2l0aCBhY3R1YWwgdmFsdWVzIGZyb20gRE9NLlxuICovXG5jb25zdCBrbm93bkRlZmF1bHRzOiBSZXF1aXJlZDxNZW1vcnk8RE9NU3BlY2lmaWNhdGlvbj4+ID0ge30gYXMgYW55O1xuZm9yIChjb25zdCBfa2V5IG9mIE9iamVjdC5rZXlzKF9rbm93bkRlZmF1bHRzKSkge1xuICBjb25zdCBrZXkgPSBfa2V5IGFzIEtub3duS2V5cztcbiAgY29uc3QgX25vbmUgPSBcIk5PVCBGT1VORCBPTiBET00hXCI7XG4gIGxldCBhc3NpZ25lZFZhbHVlOiBET01TcGVjaWZpY2F0aW9uW1wiYXNzaWduZWRWYWx1ZVwiXSA9IF9ub25lO1xuXG4gIGNvbnN0IHNwZWMgPSBfa25vd25EZWZhdWx0c1trZXldO1xuICBjb25zdCBOb2RlID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihzcGVjLnF1ZXJ5U2VsZWN0b3IpO1xuICBsZXQgY29tcHV0ZWRTdHlsZXM7XG4gIGlmICghTm9kZSkge1xuICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICBgQ291bGQgbm90IGZpbmQgZWxlbWVudCB3aXRoIHF1ZXJ5U2VsZWN0b3I6ICR7c3BlYy5xdWVyeVNlbGVjdG9yfWBcbiAgICApO1xuICAgIGNvbXB1dGVkU3R5bGVzID0geyBiYWNrZ3JvdW5kOiBcImluaXRpYWxcIiB9O1xuICB9IGVsc2Uge1xuICAgIGNvbXB1dGVkU3R5bGVzID0gd2luZG93LmdldENvbXB1dGVkU3R5bGUoTm9kZSk7XG4gIH1cblxuICBpZiAoc3BlYy5hdHRyaWJ1dGUyKSB7XG4gICAgaWYgKHNwZWMuYXR0cmlidXRlMSAhPT0gXCJzdHlsZVwiKSB7XG4gICAgICBjb25zb2xlLndhcm4oXG4gICAgICAgIFwiYXR0cmlidXRlMiBpcyBzZXQsIGJ1dCBhdHRyaWJ1dGUxIGlzIG5vdCBzdHlsZVxcblRoaXMgbWlnaHQgbm90IHdvcmsgYXMgZXhwZWN0ZWQhXFxuR3JhYmJpbmcgZnJvbSByYXcgX3F1ZXJ5IChET00gbm9kZSlcIlxuICAgICAgKTtcbiAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgIGFzc2lnbmVkVmFsdWUgPSBOb2RlW3NwZWMuYXR0cmlidXRlMV1bc3BlYy5hdHRyaWJ1dGUyXTtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gQHRzLWlnbm9yZVxuICAgICAgYXNzaWduZWRWYWx1ZSA9IGNvbXB1dGVkU3R5bGVzW3NwZWMuYXR0cmlidXRlMiFdO1xuICAgIH1cbiAgfSBlbHNlIHtcbiAgICAvLyBAdHMtaWdub3JlXG4gICAgYXNzaWduZWRWYWx1ZSA9IChOb2RlID8/IHsgc3JjOiBcImluaXRpYWxcIiB9KVtzcGVjLmF0dHJpYnV0ZTFdO1xuICB9XG5cbiAgLy8gY29uc29sZS5sb2coXCJHb3QgYXNzaWduZWQgdmFsdWUgJ1wiLCBhc3NpZ25lZFZhbHVlLCBcIicgZm9yIGtleVwiLCBrZXkpO1xuXG4gIGtub3duRGVmYXVsdHNba2V5XSA9IHtcbiAgICAuLi5fa25vd25EZWZhdWx0c1trZXldLFxuICAgIGFzc2lnbmVkVmFsdWU6IGFzc2lnbmVkVmFsdWUgPT09IF9ub25lID8gXCJcIiA6IGFzc2lnbmVkVmFsdWUsXG4gIH07XG59XG4vLyAgIHtcbi8vICAgICBrZXk6IFwiZGVsZXRlSU1HU3JjXCIsXG4vLyAgICAgcXVlcnlTZWxlY3RvcjogJ2ltZ1tzcmNdW2FsdD1cIkVtbWFudWVsIENvbGxlZ2VcIl0nLFxuLy8gICAgIGZpcnN0TGV2ZWxQcm9wZXJ0eTogXCJzcmNzZXRcIixcbi8vICAgICBuZXdWYWxXcmFwcGVyOiBcIiQkJFwiLFxuLy8gICAgIGRlZmF1bHRWYWx1ZTogXCJERUxFVEVcIixcbi8vICAgfSxcblxuY29uc3QgZGVmYXVsdE1lbW9yeTogUmVxdWlyZWQ8TWVtb3J5PiA9IHt9IGFzIGFueTtcbmZvciAoY29uc3Qga2V5IG9mIGtub3duS2V5cykge1xuICBkZWZhdWx0TWVtb3J5W2tleV0gPSB7IGRvbVNwZWM6IGtub3duRGVmYXVsdHNba2V5XSB9O1xufVxuZm9yIChjb25zdCBrZXkgb2Yga25vd25LZXlzKSB7XG4gIGlmICghZGVmYXVsdE1lbW9yeVtrZXldKSB7XG4gICAgY29uc29sZS5lcnJvcihgS2V5ICR7a2V5fSBub3QgZm91bmQgaW4gZGVmYXVsdE1lbW9yeSFgKTtcbiAgfVxuICBpZiAoIWRlZmF1bHRNZW1vcnlba2V5XT8uZG9tU3BlYykge1xuICAgIGNvbnNvbGUuZXJyb3IoYEtleSAke2tleX0gbm90IGZvdW5kIGluIGRlZmF1bHRNZW1vcnlzIGRvbVNwZWNzIWApO1xuICB9XG59XG5cbmNvbnNvbGUubG9nKFwiY29udGVudC5qcyBsb2FkZWRcIik7XG5cbi8vICNyZWdpb24gSGVscGVyc1xuXG4vKipcbiAqIFVzYWdlOlxuICogYGBgdHNcbiAqIGZ1bmN0aW9uIGV4cGVuc2l2ZUZ1bmN0aW9uKCkge1xuICogIC8vIERvIHNvbWV0aGluZyBleHBlbnNpdmVcbiAqIH1cbiAqIGNvbnN0IGNoZWFwRnVuYyA9IGRlYm91bmNlKGV4cGVuc2l2ZUZ1bmN0aW9uLCAxMDAwLCB7ZGVidWdFeGVjdXRlZDogXCJFeHBlbnNpdmUgZnVuY3Rpb24gZXhlY3V0ZWRcIiwgZGVidWdCb3VuY2VkOiBcIkV4cGVuc2l2ZSBmdW5jdGlvbiB3YXMgZGVib3VuY2VkXCJ9KTtcbiAqIC8vIE9yIGNhbGwgaXQgZGlyZWN0bHlcbiAqIGV4cGVuc2l2ZUZ1bmN0aW9uKCkgLy8gSW1tZWRpYXRlXG4gKiBjaGVhcEZ1bmMoKSAvLyBEZWJvdW5jZWRcbiAqIGBgYFxuICogQHBhcmFtIGZuIEZ1bmN0aW9uIHRvIGJlIGV4ZWN1dGVkXG4gKiBAcGFyYW0gZGVsYXkgRGVsYXkgYmVmb3JlIGV4ZWN1dGlvblxuICovXG5jb25zdCBkZWJvdW5jZSA9IDxUIGV4dGVuZHMgKC4uLmFyZ3M6IGFueVtdKSA9PiBhbnk+KFxuICBjYWxsYmFjazogVCxcbiAgd2FpdEZvcjogbnVtYmVyLFxuICBkZWJ1Zz86IHsgZGVidWdFeGVjdXRlZD86IHN0cmluZzsgZGVidWdCb3VuY2VkPzogc3RyaW5nIH1cbikgPT4ge1xuICBsZXQgdGltZW91dDogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0VGltZW91dD47XG4gIHJldHVybiAoLi4uYXJnczogUGFyYW1ldGVyczxUPik6IFJldHVyblR5cGU8VD4gPT4ge1xuICAgIGxldCByZXN1bHQ6IGFueTtcbiAgICBkZWJ1Zz8uZGVidWdCb3VuY2VkID8gY29uc29sZS5sb2coZGVidWc/LmRlYnVnQm91bmNlZCkgOiBudWxsO1xuICAgIHRpbWVvdXQgJiYgY2xlYXJUaW1lb3V0KHRpbWVvdXQpO1xuICAgIHRpbWVvdXQgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIGNvbnNvbGUubG9nKGRlYnVnPy5kZWJ1Z0V4ZWN1dGVkID8/IFwiJiBFeGVjdXRlZFwiKTtcbiAgICAgIHJlc3VsdCA9IGNhbGxiYWNrKC4uLmFyZ3MpO1xuICAgIH0sIHdhaXRGb3IpO1xuICAgIHJldHVybiByZXN1bHQ7XG4gIH07XG59O1xuXG4vLyAjZW5kcmVnaW9uXG5cbi8vICNyZWdpb24gTWVtb3J5IG1hbmlwdWxhdGlvblxuXG4vKipcbiAqIFJlcHJlc2VudHMgd2hhdCBpcyBzdG9yZWQgaW4gbWVtb3J5LCBhY3R1YWxseS5cbiAqIEFic3RyYWN0cyBhd2F5IGZyb20gc3BlY2lmaWMgc3RvcmFnZSB0eXBlcyxcbiAqIHNvIHRoYXQgZS5nLiBzd2l0Y2hpbmcgdG8gZmlyZWJhc2UgaXMgYXMgc2ltcGxlIGFzIGltcGxlbWVudGluZyB0aGlzXG4gKi9cbmludGVyZmFjZSBNZW1vcnlVbml0IHtcbiAgZG9tU3BlYzogRE9NU3BlY2lmaWNhdGlvbjtcbiAgLy8gcmVzZXRJbmZvOiBSZXNldEluZm87XG59XG5cbi8qKlxuICogV2hhdCBzaG91bGQgYmUgc3RvcmVkIGluIG1lbW9yeS5cbiAqIEV4YW1wbGU6IGBjYWNoZWAgc2hvdWxkIGJlIG9mIHRoaXMgdHlwZSwgcmV0dXJuIG9mIGNocm9tZSBzdG9yYWdlIHJldHJpZXZhbCBzaG91bGQgYmUgb2YgdGhpcyB0eXBlLCBlLnQuYy5cbiAqL1xudHlwZSBNZW1vcnk8VW5pdCBleHRlbmRzIE1lbW9yeVVuaXQgfCBhbnkgPSBNZW1vcnlVbml0PiA9IHtcbiAgW2tleSBpbiBLbm93bktleXNdPzogVW5pdDtcbn07XG5cbi8vICNyZWdpb24gQ2FjaGVcblxuY29uc3QgY2FjaGU6IE1lbW9yeTxNZW1vcnlVbml0PiA9IHt9O1xuXG4vLyAjZW5kcmVnaW9uIGNhY2hlXG5cbi8vICNyZWdpb24gUmVzZXRJbmZvXG5cbi8qKlxuICogSW5mb3JtYXRpb24gbmVlZGVkIHRvIHJlc2V0IGEgc3BlY2lmaWMga25vd25LZXlcbiAqL1xudHlwZSBSZXNldEluZm8gPSB7XG4gIGluaXRpYWxTcGVjOiBET01TcGVjaWZpY2F0aW9uO1xufTtcblxuY29uc3QgcmVzZXRJbmZvOiBNZW1vcnk8UmVzZXRJbmZvW10+ID0ge307XG5cbmZvciAoY29uc3QgX2tleSBvZiBrbm93bktleXMpIHtcbiAgY29uc3Qga2V5ID0gX2tleSBhcyBLbm93bktleXM7XG4gIHJlc2V0SW5mb1trZXldID0gW1xuICAgIHtcbiAgICAgIGluaXRpYWxTcGVjOiBrbm93bkRlZmF1bHRzW2tleV0sXG4gICAgfSxcbiAgXTtcbn1cbi8vIFhYWDogQWRkIG90aGVyIHJlc2V0IGluZm8gaGVyZVxuXG4vLyAjZW5kcmVnaW9uXG5cbi8vICNyZWdpb24gU3RvcmFnZSBtYW5pcHVsYXRpb25cblxuLyoqXG4gKiBVc2FnZTpcbiAqIGBgYHRzXG4gKiBjb25zdCBkYXRhVW5kZXJLZXkgPSBhd2FpdCBnZXRTdG9yYWdlRGF0YShcIm15S2V5XCIpO1xuICogYGBgXG4gKlxuICogQHBhcmFtIGtleSBLZXkgdG8gcmV0cmlldmUgZnJvbSBzdG9yYWdlXG4gKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgdG8gdGhlIHZhbHVlIHN0b3JlZCB1bmRlciB0aGUga2V5XG4gKi9cbmNvbnN0IGdldFN0b3JhZ2VEYXRhID0gKGtleTogS25vd25LZXlzKTogUHJvbWlzZTxNZW1vcnlVbml0IHwgdW5kZWZpbmVkPiA9PlxuICBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PlxuICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KFtrZXldLCAocmVzdWx0KSA9PiB7XG4gICAgICBsZXQgcGFyc2VkUmVzdWx0OiBNZW1vcnlVbml0O1xuICAgICAgaWYgKCFyZXN1bHRba2V5XSkge1xuICAgICAgICBjb25zb2xlLndhcm4oXG4gICAgICAgICAgXCJbZ2V0U3RvcmFnZURhdGFdIE5vIGRhdGEgZm91bmQgZm9yIGtleVwiLFxuICAgICAgICAgIGtleSxcbiAgICAgICAgICBcImluIHN0b3JhZ2VcIlxuICAgICAgICApO1xuICAgICAgICByZXNvbHZlKHVuZGVmaW5lZCk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIHRyeSB7XG4gICAgICAgIHBhcnNlZFJlc3VsdCA9IEpTT04ucGFyc2UocmVzdWx0W2tleV0gYXMgYW55KTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkNvdWxkIG5vdCBwYXJzZSByZXN1bHRcIiwgcmVzdWx0LCBcIndpdGgga2V5XCIsIGtleSk7XG4gICAgICAgIHJlamVjdChlKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29uc29sZS5sb2coXG4gICAgICAgIFwiW2dldFN0b3JhZ2VEYXRhXSBrZXk6XCIsXG4gICAgICAgIGtleSxcbiAgICAgICAgXCJhc3NpZ25lZFZhbHVlXCIsXG4gICAgICAgIHBhcnNlZFJlc3VsdD8uZG9tU3BlYz8uYXNzaWduZWRWYWx1ZSxcbiAgICAgICAgUFJPRCA/IFwiXCIgOiBcInJlc3VsdDpcIixcbiAgICAgICAgUFJPRCA/IFwiXCIgOiBwYXJzZWRSZXN1bHQsXG4gICAgICAgIFBST0QgPyBcIlwiIDogXCJyYXc6XCIsXG4gICAgICAgIFBST0QgPyBcIlwiIDogcmVzdWx0W2tleV0sXG4gICAgICAgIFBST0QgPyBcIlwiIDogXCJsYXN0RXJyb3I6XCIsXG4gICAgICAgIFBST0QgPyBcIlwiIDogY2hyb21lLnJ1bnRpbWUubGFzdEVycm9yXG4gICAgICApO1xuICAgICAgaWYgKCFwYXJzZWRSZXN1bHQpIHtcbiAgICAgICAgcmVqZWN0KG5ldyBFcnJvcihcIlBhcnNlZCByZXN1bHQgaXMgZmFsc3lcIikpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAoIXBhcnNlZFJlc3VsdC5kb21TcGVjKSB7XG4gICAgICAgIHJlamVjdChuZXcgRXJyb3IoXCJQYXJzZWQgcmVzdWx0IGhhcyBubyBkb21TcGVjXCIpKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgaWYgKCF2YWxpZGF0ZURPTVNwZWNpZmljYXRpb24ocGFyc2VkUmVzdWx0LmRvbVNwZWMpKSB7XG4gICAgICAgIHJlamVjdChuZXcgRXJyb3IoXCJQYXJzZWQgcmVzdWx0IGhhcyBpbnZhbGlkIGRvbVNwZWNcIikpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIGNocm9tZS5ydW50aW1lLmxhc3RFcnJvclxuICAgICAgICA/IHJlamVjdChFcnJvcihjaHJvbWUucnVudGltZS5sYXN0RXJyb3IubWVzc2FnZSkpXG4gICAgICAgIDogcmVzb2x2ZShwYXJzZWRSZXN1bHQpO1xuICAgIH0pXG4gICk7XG5cbi8qKlxuICogVXNhZ2U6XG4gKiBgYGB0c1xuICogYXdhaXQgc2V0U3RvcmFnZURhdGEoXCJteUtleVwiLCBcIm5ld1ZhbHVlXCIpO1xuICogYGBgXG4gKiBTZXRzIHRoZSB2YWx1ZSBvZiBga2V5YCB0byBgdmFsdWVgIGluIGFjdHVhbCBzdG9yYWdlLlxuICogQHBhcmFtIGRhdGEgRGF0YSB0byBiZSBzdG9yZWRcbiAqIEByZXR1cm5zIHRydWUgaWYgZ29vZCwgZWxzZSByZWplY3RzXG4gKi9cbmNvbnN0IHNldFN0b3JhZ2VEYXRhID0gKGtleTogS25vd25LZXlzLCBkYXRhOiBNZW1vcnlVbml0KTogUHJvbWlzZTxib29sZWFuPiA9PlxuICBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgY29uc3QgZGF0YVRvU3RvcmUgPSBKU09OLnN0cmluZ2lmeShkYXRhKTtcbiAgICBjaHJvbWUuc3RvcmFnZS5zeW5jLnNldCh7IFtrZXldOiBkYXRhVG9TdG9yZSB9LCAoKSA9PiB7XG4gICAgICBjb25zb2xlLmxvZyhcbiAgICAgICAgXCJbc2V0U3RvcmFnZURhdGFdIGtleTpcIixcbiAgICAgICAga2V5LFxuICAgICAgICBcImRhdGE6XCIsXG4gICAgICAgIGRhdGEsXG4gICAgICAgIFBST0QgPyBcIlwiIDogXCJzdHJpbmdpZmllZFwiLFxuICAgICAgICBQUk9EID8gXCJcIiA6IGRhdGFUb1N0b3JlLFxuICAgICAgICBQUk9EID8gXCJcIiA6IFwibGFzdCBlcnJvcjpcIixcbiAgICAgICAgUFJPRCA/IFwiXCIgOiBjaHJvbWUucnVudGltZS5sYXN0RXJyb3IsXG4gICAgICAgIFBST0QgPyBcIlwiIDogXCJbbm90ZV06IENoZWNraW5nIGlmIHN0b3JhZ2Ugd2FzIHNldCAuLi5cIlxuICAgICAgKTtcbiAgICAgIGlmIChQUk9EKSByZXR1cm47XG4gICAgICAvLyBUZXN0XG4gICAgICBjaHJvbWUuc3RvcmFnZS5zeW5jLmdldChba2V5XSwgKHJlc3VsdCkgPT4ge1xuICAgICAgICBpZiAocmVzdWx0W2tleV0gPT09IGRhdGFUb1N0b3JlKSB7XG4gICAgICAgICAgY29uc29sZS5sb2coXCJbc2V0U3RvcmFnZURhdGFdIFt0ZXN0XSBTdWNjZXNzZnVsISFcIik7XG4gICAgICAgICAgcmVzb2x2ZSh0cnVlKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjb25zb2xlLmVycm9yKFwiW3NldFN0b3JhZ2VEYXRhXSBbdGVzdF0gRmFpbGVkISFcIik7XG4gICAgICAgICAgcmVqZWN0KGZhbHNlKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgICBjaHJvbWUucnVudGltZS5sYXN0RXJyb3JcbiAgICAgICAgPyByZWplY3QoRXJyb3IoY2hyb21lLnJ1bnRpbWUubGFzdEVycm9yLm1lc3NhZ2UpKVxuICAgICAgICA6IHJlc29sdmUodHJ1ZSk7XG4gICAgfSk7XG4gIH0pO1xuXG4vKipcbiAqIEdldCBhIGtleS4gVXNlIHRoaXMgZnVuY3Rpb24sIGFzIGl0IGhhbmRsZXMgY2FjaGluZyBmb3IgeW91LlxuICogUmV0dXJucyBhIE1lbW9yeVVuaXQgb3IgKip1bmRlZmluZWQqKiBpZiBub3QgZm91bmQuXG4gKlxuICogV2lsbCAqKm5vdCoqIHJldHVybiBhIGRlZmF1bHQsIHVubGVzcyBgZmlsbERlZmF1bHRzYCBpcyBzZXQgdG8gdHJ1ZS5cbiAqIElmIHRoaXMgaXMgdGhlIGNhc2UsIHdoZW4gdW5kZWZpbmVkIGlzIHJldHVybmVkLCBpdCB3aWxsIGJlIHNldCB0byB0aGUgZGVmYXVsdC5cbiAqIFRoZSBkZWZhdWx0IGlzIGZvdW5kIGZyb20gYGRlZmF1bHRNZW1vcnlba2V5XWAuXG4gKlxuICogQHBhcmFtIGtleSBLZXkgdG8gcmV0cmlldmUgZnJvbSBzdG9yYWdlXG4gKiBAcmV0dXJucyBUaGUgTWVtb3J5IFVuaXQgc3RvcmVkIChhcyBwcm9taXNlKVxuICovXG5hc3luYyBmdW5jdGlvbiBnZXRLZXkoXG4gIGtleTogS25vd25LZXlzLFxuICBvcHRpb25zPzogeyBmaWxsRGVmYXVsdHM6IEJvb2xlYW4gfVxuKTogUHJvbWlzZTxNZW1vcnlVbml0IHwgdW5kZWZpbmVkPiB7XG4gIGlmIChjYWNoZVtrZXldKSB7XG4gICAgcmV0dXJuIGNhY2hlW2tleV0hO1xuICB9IGVsc2Uge1xuICAgIGNvbnNvbGUud2FybihcIktleVwiLCBrZXksIFwibm90IGZvdW5kIGluIGNhY2hlLiBTZWFyY2hpbmcgc3RvcmFnZS4uLlwiKTtcbiAgICBjb25zdCBkID0gYXdhaXQgZ2V0U3RvcmFnZURhdGEoa2V5KTtcbiAgICBpZiAoZCkge1xuICAgICAgY2FjaGVba2V5XSA9IGQ7XG4gICAgICByZXR1cm4gZDtcbiAgICB9IGVsc2Uge1xuICAgICAgaWYgKG9wdGlvbnM/LmZpbGxEZWZhdWx0cykge1xuICAgICAgICBjb25zb2xlLndhcm4oXCJLZXlcIiwga2V5LCBcIm5vdCBmb3VuZCBpbiBzdG9yYWdlLiBTZXR0aW5nIGRlZmF1bHQgdmFsdWVcIik7XG4gICAgICAgIGNvbnN0IGRlZmF1bHRNZW0gPSBkZWZhdWx0TWVtb3J5W2tleV07XG4gICAgICAgIC8vIHNldFN0b3JhZ2VEYXRhKGtleSwgZGVmYXVsdE1lbSk7XG4gICAgICAgIGNhY2hlW2tleV0gPSBkZWZhdWx0TWVtO1xuICAgICAgICByZXR1cm4gZGVmYXVsdE1lbTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnNvbGUud2FybihcIktleVwiLCBrZXksIFwibm90IGZvdW5kIGluIHN0b3JhZ2UuIFJldHVybmluZyB1bmRlZmluZWRcIik7XG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG5cbmNvbnN0IF9zZXRLZXlMaXN0OiB0eXBlb2Ygc2V0U3RvcmFnZURhdGFbXSA9IGtub3duS2V5cy5tYXAoKGtleSkgPT4ge1xuICByZXR1cm4gZGVib3VuY2Uoc2V0U3RvcmFnZURhdGEsIDEwMDAsIHtcbiAgICBkZWJ1Z0V4ZWN1dGVkOiBgU2V0ICcke2tleX0nIEVYRUNVVEVEYCxcbiAgICBkZWJ1Z0JvdW5jZWQ6IGBTZXQgJyR7a2V5fScgZGVib3VuY2VkYCxcbiAgfSk7XG59KTtcbmNvbnN0IF9zZXRLZXk6IFJlY29yZDxLbm93bktleXMsIHR5cGVvZiBzZXRTdG9yYWdlRGF0YT4gPSBfc2V0S2V5TGlzdC5yZWR1Y2UoXG4gIChwcmV2aW91c1ZhbHVlLCBjdXJyZW50VmFsdWUsIGkpID0+IHtcbiAgICBwcmV2aW91c1ZhbHVlW2tub3duS2V5c1tpXV0gPSBjdXJyZW50VmFsdWU7XG4gICAgcmV0dXJuIHByZXZpb3VzVmFsdWU7XG4gIH0sXG4gIHt9IGFzIGFueVxuKTtcblxuY29uc29sZS5pbmZvKFwiU2V0IGtleVwiLCBfc2V0S2V5KTtcblxuLyoqXG4gKiBTZXRzIHRoZSBkZXNpcmVkIGBrZXlgcyAoYGRvbVNwZWNgKSBgcHJvcGVydHlgIChjb21tb25seSBgYXNzaWduZWRWYWx1ZWApIHRvIGB2YWx1ZWAgaW4gc3RvcmFnZSxcbiAqIG5vdGUgdGhpcyAqdXNlcyBhIGNhY2hlKi5cbiAqXG4gKiAjIyBVc2UgdGhpcyBmdW5jdGlvbiwgYXMgaXQgd2lsbCBwcm9wZXJseSB1cGRhdGUgdGhlIERPTS5cbiAqICMjIyBOb3RlOiB0aGlzIHdpbGwgc2V0IHRoZSBgYXNzaWduZWRWYWx1ZWAgcHJvcGVydHkgb24gdGhlIGludGVybmFsIGBNZW1vcnlVbml0LmRvbVNwZWNgIG9iamVjdCBieSBkZWZhdWx0LiBUbyBzZXQgdGhlIGBkb21TcGVjYCBwcm9wZXJ0eSwgcmVwZWF0ZWRseSBjYWxsIHRoaXMgZnVuY3Rpb25cbiAqXG4gKlxuICogVXNhZ2U6XG4gKiBgYGB0c1xuICogYXdhaXQgc2V0S2V5KFwidG9wYmFyXCIsIFwibmV3IGNvbG91clwiLCBcImFzc2lnbmVkVmFsdWVcIik7XG4gKiBgYGBcbiAqIEBwYXJhbSBrZXkgS2V5IHRvIHNldFxuICogQHBhcmFtIHZhbHVlIFZhbHVlIHRvIHNldCBrZXkgdG9cbiAqL1xuYXN5bmMgZnVuY3Rpb24gc2V0S2V5PFxuICBQcm9wZXJ0eSBleHRlbmRzIGtleW9mIE1lbW9yeVVuaXRbXCJkb21TcGVjXCJdID0gXCJhc3NpZ25lZFZhbHVlXCJcbj4oXG4gIGtleTogS25vd25LZXlzLFxuICB2YWx1ZTogTWVtb3J5VW5pdFtcImRvbVNwZWNcIl1bUHJvcGVydHldLFxuICBwcm9wZXJ0eTogUHJvcGVydHkgPSBcImFzc2lnbmVkVmFsdWVcIiBhcyBhbnlcbikge1xuICBjb25zdCBfY29uZmlnID0gYXdhaXQgY29uZmlnO1xuICBpZiAodmFsdWU/LmluY2x1ZGVzKFwidXJsXCIpICYmIF9jb25maWdbXCJ1cmwtYmFja2dyb3VuZHNcIl0gIT0gXCJlbmFibGVkXCIpIHtcbiAgICBjb25zb2xlLmVycm9yKFxuICAgICAgXCJFeHRlbnNpb24gVVJMIGltYWdlcyBkaXNhYmxlZDogXCIsXG4gICAgICBfY29uZmlnW1widXJsLWJhY2tncm91bmRzXCJdLFxuICAgICAgXCJcIlxuICAgICk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgaWYgKCFjYWNoZVtrZXldKSB7XG4gICAgY29uc29sZS53YXJuKFxuICAgICAgXCJLZXlcIixcbiAgICAgIGtleSxcbiAgICAgIFwibm90IGZvdW5kIGluIGNhY2hlIGR1cmluZyBjYWxsIHRvIGBzZXRLZXlgLlxcblRoZSBjYWNoZSBzaG91bGQgYmUgdGhlIHNvdXJjZSBvZiB0cnV0aCwgYXMgc3RvcmFnZSBpcyBzbG93LlxcblRvIGZpeCB0aGlzLCBsb2FkIHRoZSBjYWNoZSB3aXRoIGFsbCBkZXNpcmVkIHZhbHVlcyBmcm9tIHN0b3JhZ2UuIFRoaXMgaXMgdXN1YWxseSBkb25lIGF1dG9tYXRpY2FsbHkgd2hlbiBgY29udGVudC50c2AgaXMgZmlyc3QgbG9hZGVkLlxcbkF1dG9tYXRpY2FsbHkgY2FsbGluZyBgZ2V0S2V5YCB0byBsb2FkIHRoZSBjYWNoZSAodGhpcyBpcyBhbiBpbXBsZW1lbnRhdGlvbiBkZXRhaWwgZml4KSAuLi5cIlxuICAgICk7XG4gICAgY2FjaGVba2V5XSA9IGF3YWl0IGdldEtleShrZXksIHsgZmlsbERlZmF1bHRzOiB0cnVlIH0pO1xuICB9XG5cbiAgLy8gVE9ETzogdW5tb3VudGluZyBsb2dpYyBjb3VsZCBnbyBoZXJlXG4gIC8vIEUuZy4gcmVzZXR0aW5nIHRoZSBET00gdG8gdGhlIGluaXRpYWwgc3RhdGUsIHRoZW4gcmUtYWRkaW5nIHRoZSBuZXcgRE9NXG4gIC8vIFRoaXMgd291bGQgYWxsb3cgY2hhbmdlcyBzdWNoIGFzIHRvIGBxdWVyeVNlbGVjdG9yYCB0byB3b3JrIGFzIGV4cGVjdGVkXG5cbiAgY2FjaGVba2V5XSEuZG9tU3BlY1twcm9wZXJ0eV0gPSB2YWx1ZTtcbiAgX3NldEtleVtrZXldKGtleSwgY2FjaGVba2V5XSEpOyAvLyBEZWJvdW5jZXNcblxuICAvLyBVcGRhdGUgRE9NXG4gIGV4ZWN1dGVET01TcGVjaWZpY2F0aW9uKGNhY2hlW2tleV0hLmRvbVNwZWMpO1xufVxuXG4vLyAjZW5kcmVnaW9uIHN0b3JhZ2VcblxuLy8gI2VuZHJlZ2lvbiBtZW1vcnlcblxuLy8gI3JlZ2lvbiBVc2VyUmVxdWVzdHNcblxuLyoqXG4gKiBXaGF0IGlzIHNlbnQgdG8gY29udGVudC50c1xuICovXG5leHBvcnQgaW50ZXJmYWNlIFVzZXJSZXF1ZXN0IHtcbiAga2V5OiBLbm93bktleXM7XG4gIGRvOiBQb3NzaWJsZUFjdGlvbnM7XG5cbiAgX19pc191c2VyX3JlcXVlc3Q6IHRydWU7XG59XG5cbnR5cGUgUG9zc2libGVBY3Rpb25zID1cbiAgfCBcIlJFU0VUXCJcbiAgfCB7XG4gICAgICBuZXdBc3NpZ25lZFZhbHVlOiBET01TcGVjaWZpY2F0aW9uW1wiYXNzaWduZWRWYWx1ZVwiXTtcbiAgICB9O1xuXG4vKipcbiAqIEhhbmRsZXMgYSB1c2VyIHJlcXVlc3QsIGluY2x1ZGluZyB0aGUgcmVzZXQgbG9naWMgYW5kIHVzaW5nIGBzZXRLZXlgIHRvIHVwZGF0ZSB0aGUgRE9NLlxuICogQHBhcmFtIHJlcXVlc3QgUmVxdWVzdCB0byBoYW5kbGVcbiAqL1xuZnVuY3Rpb24gaGFuZGxlVXNlclJlcXVlc3QocmVxdWVzdDogVXNlclJlcXVlc3QpIHtcbiAgY29uc3Qga2V5ID0gcmVxdWVzdC5rZXk7XG4gIGNvbnN0IGFjdGlvbiA9IHJlcXVlc3QuZG87XG4gIGlmIChhY3Rpb24gPT09IFwiUkVTRVRcIikge1xuICAgIGNvbnNvbGUubG9nKFwiSGFuZGxpbmcgUkVTRVQgcmVxdWVzdCBmb3IgcmVxdWVzdDogXCIsIHJlcXVlc3QpO1xuICAgIGlmICghcmVzZXRJbmZvW2tleV0pIHtcbiAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgYFJlc2V0IGluZm8gbm90IGZvdW5kIGZvciBrZXkgJyR7a2V5fScgZHVyaW5nIHJlc2V0LlxcblRoaXMgaXMgcHJvYmFibHkgYSBidWcuIFdoZW4gaW5pdGlhbGl6aW5nLCByZW1lbWJlciB0byBjYXB0dXJlIHRoZSBpbml0aWFsIERPTSBzdGF0ZS5cXG5Eb2luZyBub3RoaW5nLmBcbiAgICAgICk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIC8vIExvb3AgdGhyb3VnaCBlYWNoIGluaXRpYWxTcGVjXG4gICAgcmVzZXRJbmZvW2tleV0hLmZvckVhY2goKGluZm8pID0+IHtcbiAgICAgIGNvbnN0IGluaXRpYWwgPSBpbmZvLmluaXRpYWxTcGVjO1xuICAgICAgLy8gTG9vcCB0aHJvdWdoIGluaXRpYWwsIGFuZCBzZXQgZWFjaCBwcm9wZXJ0eVxuICAgICAgZm9yIChjb25zdCBfcHJvcGVydHkgaW4gaW5pdGlhbCkge1xuICAgICAgICBjb25zdCBwcm9wZXJ0eSA9IF9wcm9wZXJ0eSBhcyBrZXlvZiB0eXBlb2YgaW5pdGlhbDtcblxuICAgICAgICBjb25zb2xlLmxvZyhgU2V0dGluZyAke2tleX0uJHtwcm9wZXJ0eX0gdG8gJHtpbml0aWFsW3Byb3BlcnR5XX1gKTtcblxuICAgICAgICBzZXRLZXkoa2V5LCBpbml0aWFsW3Byb3BlcnR5XSwgcHJvcGVydHkpO1xuICAgICAgfVxuICAgIH0pO1xuICB9IGVsc2Uge1xuICAgIGNvbnNvbGUubG9nKFwiSGFuZGxpbmcgcmVxdWVzdDpcIiwgcmVxdWVzdCk7XG4gICAgc2V0S2V5KGtleSwgYWN0aW9uLm5ld0Fzc2lnbmVkVmFsdWUpO1xuICB9XG59XG5cbi8vICNlbmRyZWdpb24gdXNlciByZXF1ZXN0c1xuXG4vLyAjcmVnaW9uIERPTSBtYW5pcHVsYXRpb25cblxuLyoqXG4gKiBSZXByZXNlbnRzIGEgc3BlY2lmaWMgbXV0YXRpb24gdG8gdGhlIERPTS5cbiAqIEV4YW1wbGVzIGluY2x1ZGU6XG4gKiAtIFNldHRpbmcgYW4gYXR0cmlidXRlLCBsaWtlIHN0eWxlXG4gKi9cbmludGVyZmFjZSBET01TcGVjaWZpY2F0aW9uIHtcbiAgcXVlcnlTZWxlY3Rvcjogc3RyaW5nO1xuICBhdHRyaWJ1dGUxOiBzdHJpbmc7XG4gIGF0dHJpYnV0ZTI/OiBzdHJpbmc7XG4gIGFzc2lnbmVkVmFsdWU6IHN0cmluZztcblxuICAvLyB3YXJuOiB7XG4gIC8vICAgb25NYW55OiBib29sZWFuO1xuICAvLyB9XG59XG5cbmZ1bmN0aW9uIF91cGRhdGVFbGVtKGVsZW06IE5vZGUsIHNwZWM6IERPTVNwZWNpZmljYXRpb24pIHtcbiAgaWYgKHNwZWMuYXR0cmlidXRlMikge1xuICAgIC8vIEB0cy1pZ25vcmVcbiAgICBlbGVtW3NwZWMuYXR0cmlidXRlMV1bc3BlYy5hdHRyaWJ1dGUyXSA9IFwiaW5pdGlhbFwiO1xuICAgIC8vIEB0cy1pZ25vcmVcbiAgICBlbGVtW3NwZWMuYXR0cmlidXRlMV1bc3BlYy5hdHRyaWJ1dGUyXSA9IHNwZWMuYXNzaWduZWRWYWx1ZTtcblxuICAgIC8vIGNvbnNvbGUubG9nKFxuICAgIC8vICAgXCJbX3VwZGF0ZUVsZW1dIFNldCBhdHRyaWJ1dGUyXCIsXG4gICAgLy8gICBzcGVjLmF0dHJpYnV0ZTIsXG4gICAgLy8gICBcIm9mXCIsXG4gICAgLy8gICBlbGVtLFxuICAgIC8vICAgXCJ0b1wiLFxuICAgIC8vICAgc3BlYy5hc3NpZ25lZFZhbHVlXG4gICAgLy8gKTtcbiAgfSBlbHNlIHtcbiAgICBjb25zb2xlLmxvZyhcbiAgICAgIFwiW191cGRhdGVFbGVtXSBzZXR0aW5nIGF0dHJpYnV0ZTFcIixcbiAgICAgIHNwZWMuYXR0cmlidXRlMSxcbiAgICAgIFwib2ZcIixcbiAgICAgIGVsZW0sXG4gICAgICBcInRvXCIsXG4gICAgICBzcGVjLmFzc2lnbmVkVmFsdWVcbiAgICApO1xuICAgIC8vIEB0cy1pZ25vcmVcbiAgICBlbGVtW3NwZWMuYXR0cmlidXRlMV0gPSBzcGVjLmFzc2lnbmVkVmFsdWU7XG4gIH1cbn1cblxuZnVuY3Rpb24gZXhlY3V0ZURPTVNwZWNpZmljYXRpb24oc3BlYzogRE9NU3BlY2lmaWNhdGlvbikge1xuICBjb25maWcudGhlbigoY29uZmlnKSA9PiB7XG4gICAgaWYgKGNvbmZpZ1tcIipcIl0gIT0gXCJlbmFibGVkXCIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgIFwiTm90IGdvaW5nIHRvIHVwZGF0ZSB0aGUgRE9NLCBiZWNhdXNlIHRoZSBleHRlbnNpb24gaXMgZGlzYWJsZWQgRlVMTFlcIlxuICAgICAgKTtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIkV4dGVuc2lvbiAoZnVsbHkpIGRpc2FibGVkOiBcIiArIGNvbmZpZ1tcIipcIl0pO1xuICAgIH1cbiAgICBpZiAoIXNwZWMpIHtcbiAgICAgIGNvbnNvbGUud2FybihcIk5vIERPTSBzcGVjaWZpY2F0aW9uIHByb3ZpZGVkLiBEb2luZyBub3RoaW5nLlwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKCFzcGVjPy5xdWVyeVNlbGVjdG9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiTm8gcXVlcnlTZWxlY3RvciBmb3VuZCBpbiBzcGVjOlwiLCBzcGVjKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgcXVlcnlNYW55KHNwZWMucXVlcnlTZWxlY3RvciwgKGVsZW0pID0+IHtcbiAgICAgIF91cGRhdGVFbGVtKGVsZW0sIHNwZWMpO1xuICAgIH0pO1xuICB9KTtcbn1cblxuZnVuY3Rpb24gcXVlcnlNYW55KHF1ZXJ5U2VsZWN0b3I6IHN0cmluZywgY2FsbGJhY2s6IChlbGVtOiBOb2RlKSA9PiB2b2lkKSB7XG4gIGNvbnN0IGVsZW1lbnRzID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChxdWVyeVNlbGVjdG9yKTtcbiAgaWYgKGVsZW1lbnRzLmxlbmd0aCA9PSAwKSB7XG4gICAgY29uc29sZS53YXJuKFxuICAgICAgYERpZCBxdWVyeSBmb3IgJyR7cXVlcnlTZWxlY3Rvcn0nLCBidXQgbWF0Y2hlZCBub3RoaW5nLlxcblRyeSBjb3B5IHBhc3RpbmcgdGhpcyBpbnRvIHlvdXIgYnJvd3NlcjpcXG5kb2N1bWVudC5xdWVyeVNlbGVjdGVkQWxsKFwiJHtxdWVyeVNlbGVjdG9yfVwiKVxcbklmIG5vdGhpbmcgaXMgcmV0dXJuZWQsIHlvdSBtYXkgaGF2ZSBtYWRlIGEgbWlzdGFrZSB3aXRoIHlvdXIgcXVlcnkgc2VsZWN0b3IuXFxuUmVtZW1iZXIgdG8gc3BsaXQgbXVsdGlwbGUgc2VsZWN0b3JzIHdpdGggY29tbWFzLCBsaWtlICduYXYtYmFyLCAjaWQsIC5jbGFzcydgXG4gICAgKTtcbiAgfVxuICBlbGVtZW50cy5mb3JFYWNoKGNhbGxiYWNrKTtcbn1cblxuLy8gI2VuZHJlZ2lvblxuXG4vLyAjcmVnaW9uIFJ1bnRpbWUgVmFsaWRhdGlvblxuXG5mdW5jdGlvbiB2YWxpZGF0ZURPTVNwZWNpZmljYXRpb24oc3BlYzogRE9NU3BlY2lmaWNhdGlvbik6IEJvb2xlYW4ge1xuICBpZiAoIXNwZWMpIHtcbiAgICBjb25zb2xlLmVycm9yKFwiTm8gRE9NIHNwZWNpZmljYXRpb24gcHJvdmlkZWQuIERvaW5nIG5vdGhpbmcuXCIpO1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBpZiAoIXNwZWM/LnF1ZXJ5U2VsZWN0b3IpIHtcbiAgICBjb25zb2xlLmVycm9yKFwiTm8gcXVlcnlTZWxlY3RvciBmb3VuZCBpbiBzcGVjOlwiLCBzcGVjKTtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgaWYgKCFzcGVjPy5hdHRyaWJ1dGUxKSB7XG4gICAgY29uc29sZS5lcnJvcihcIk5vIGF0dHJpYnV0ZTEgZm91bmQgaW4gc3BlYzpcIiwgc3BlYyk7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGlmICghc3BlYz8uYXNzaWduZWRWYWx1ZSkge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJObyBhc3NpZ25lZFZhbHVlIGZvdW5kIGluIHNwZWM6XCIsIHNwZWMpO1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICByZXR1cm4gdHJ1ZTtcbn1cblxuLy8gI2VuZHJlZ2lvblxuXG4vLyAjcmVnaW9uIEV4ZWN1dGlvblxuY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQobnVsbCwgKGV2ZXJ5dGhpbmc6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4pID0+IHtcbiAgaWYgKCFldmVyeXRoaW5nKSB7XG4gICAgY29uc29sZS53YXJuKFwiW2luaXRpYWxdIE5vIHN0b3JhZ2UgZm91bmRcIik7XG4gICAgcmV0dXJuO1xuICB9XG4gIGZvciAoY29uc3Qgc3RvcmFnZUtleSBpbiBldmVyeXRoaW5nKSB7XG4gICAgY29uc3Qga2V5ID0gc3RvcmFnZUtleSBhcyBLbm93bktleXM7XG4gICAgbGV0IF9wYXJzZWQ7XG4gICAgdHJ5IHtcbiAgICAgIF9wYXJzZWQgPSBKU09OLnBhcnNlKGV2ZXJ5dGhpbmdba2V5XSk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgYEZhaWxlZCB0byBwYXJzZSBKU09OIGZvciBrZXkgJyR7a2V5fSdcXG5WYWx1ZTogJHtldmVyeXRoaW5nW2tleV19OyBlOmAsXG4gICAgICAgIGVcbiAgICAgICk7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgY29uc3QgdmFsdWUgPSBfcGFyc2VkIGFzIE1lbW9yeVVuaXQ7XG5cbiAgICBpZiAoIWtleSkge1xuICAgICAgY29uc29sZS53YXJuKFwiW2luaXRpYWxdIE5vIHN0b3JhZ2Uga2V5IGZvdW5kXCIsIGtleSwgdmFsdWUpO1xuICAgICAgY29udGludWU7XG4gICAgfVxuXG4gICAgaWYgKCF2YWx1ZSkge1xuICAgICAgY29uc29sZS53YXJuKFwiW2luaXRpYWxdIE5vIHN0b3JhZ2UgdmFsdWUgZm91bmRcIiwga2V5LCB2YWx1ZSk7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG5cbiAgICBpZiAoa25vd25LZXlzLmluZGV4T2Yoa2V5KSA9PSAtMSkge1xuICAgICAgY29uc29sZS53YXJuKFxuICAgICAgICBgW2luaXRpYWxdIEtleSAnJHtrZXl9JyBmb3VuZCBpbiBzdG9yYWdlLCBidXQgbm90IGluIGtub3duS2V5cy5cXG5UaGlzIGlzIHByb2JhYmx5IGEgYnVnLlxcblZhbHVlOmAsXG4gICAgICAgIHZhbHVlXG4gICAgICApO1xuICAgIH1cblxuICAgIGlmICghdmFsaWRhdGVET01TcGVjaWZpY2F0aW9uKHZhbHVlLmRvbVNwZWMpKSB7XG4gICAgICBjb25zdCBNQU5VQUxfbmV3VmFsdWUgPSBjb25zb2xlLndhcm4oXG4gICAgICAgIGBbaW5pdGlhbF0gSW52YWxpZCBET00gc3BlY2lmaWNhdGlvbiBmb3VuZCBmb3Iga2V5ICcke2tleX0nIGluIGluaXRpYWwgc3RvcmFnZSBmZXRjaC5cXG5UaGlzIGlzIHByb2JhYmx5IGEgYnVnLlxcblZhbHVlOmAsXG4gICAgICAgIHZhbHVlLFxuICAgICAgICBcIlxcblNldHRpbmcgYSBkZWZhdWx0IHZhbHVlLCBbZmF0YWxdIHRoaXMgd2lsbCBvdmVycmlkZSBhbnkgdmFsaWQgc2V0dGluZ3MgZGF0YSB1bmRlciBrZXlcIixcbiAgICAgICAga2V5LFxuICAgICAgICBcIlttYW51YWwgaW1wbGVtZW50YXRpb25dIFNldHRpbmcgdG9cIlxuICAgICAgKTtcbiAgICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuc2V0KHtcbiAgICAgICAgW2tleV06IEpTT04uc3RyaW5naWZ5KGRlZmF1bHRNZW1vcnlba2V5XSksXG4gICAgICB9KTtcblxuICAgICAgY29udGludWU7XG4gICAgfVxuXG4gICAgY2FjaGVba2V5XSA9IHZhbHVlO1xuXG4gICAgLy8gVmFsaWRhdGluZyB2YWx1ZSdzIHByb3BlcnRpZXMgYWdhaW5zdCBkZWZhdWx0c1xuICAgIGlmIChcbiAgICAgIHZhbHVlPy5kb21TcGVjPy5xdWVyeVNlbGVjdG9yICE9PVxuICAgICAgZGVmYXVsdE1lbW9yeVtrZXldPy5kb21TcGVjPy5xdWVyeVNlbGVjdG9yXG4gICAgKSB7XG4gICAgICBjb25zb2xlLndhcm4oXG4gICAgICAgIGBLZXkgJyR7a2V5fScgaGFzIGEgZGlmZmVyZW50IHF1ZXJ5U2VsZWN0b3IgdGhhbiB0aGUgZGVmYXVsdC5cXG5UaGlzIGlzIHByb2JhYmx5IGEgYnVnLlxcblZhbHVlOmAsXG4gICAgICAgIHZhbHVlXG4gICAgICApO1xuICAgIH1cblxuICAgIC8vIFVzZSBvZmZpY2lhbCBtZWFucywgaW5jbHVkaW5nIHVwZGF0aW5nIHRoZSBET01cblxuICAgIGNvbnN0IG5ld1ZhbHVlID0gdmFsdWU/LmRvbVNwZWMuYXNzaWduZWRWYWx1ZTtcbiAgICBzZXRLZXkoa2V5LCBuZXdWYWx1ZSk7XG4gIH1cbn0pO1xuXG4vLyAvLyBSZXRyaWV2ZSBkYXRhIGZyb20gY2hyb21lIHN0b3JhZ2UgYW5kIHB1dCBpbnRvIGNhY2hlXG4vLyBrbm93bktleXMuZm9yRWFjaChhc3luYyAoa2V5KSA9PiB7XG4vLyAgIC8vIFBvcHVsYXRlIGNhY2hlXG4vLyAgIGNvbnN0IGRhdGEgPSBhd2FpdCBnZXRTdG9yYWdlRGF0YShrZXkpO1xuLy8gICBpZiAoY2FjaGVba2V5XSkge1xuLy8gICAgIGNvbnNvbGUud2Fybihcbi8vICAgICAgIFwiT3ZlcndyaXRpbmcgY2FjaGUgZm9yIGtleVwiLFxuLy8gICAgICAga2V5LFxuLy8gICAgICAgXCJiZWNhdXNlIGl0IGlzIGluaXRpYWwgcnVuLlxcblRoaXMgY291bGQgaGFwcGVuIHdoZW4gZHVwbGljYXRlIGl0ZW1zIGluIGBrbm8gd25LZXlzYCBsaXN0IGV4aXN0LlwiXG4vLyAgICAgKTtcbi8vICAgfVxuLy8gICBjb25zb2xlLmxvZyhcbi8vICAgICBcIltpbml0aWFsXSBTZXR0aW5nIGNhY2hlIGZvciBrZXlcIixcbi8vICAgICBrZXksXG4vLyAgICAgXCJ0byBhc3NpZ25lZFZhbHVlXCIsXG4vLyAgICAgZGF0YT8uZG9tU3BlYz8uYXNzaWduZWRWYWx1ZSxcbi8vICAgICBcImRvbVNwZWNcIixcbi8vICAgICBkYXRhPy5kb21TcGVjLFxuLy8gICAgIFBST0QgPyBcIlwiIDogXCJkYXRhOlwiLFxuLy8gICAgIFBST0QgPyBcIlwiIDogZGF0YVxuLy8gICApO1xuLy8gICBjYWNoZVtrZXldID0gZGF0YTtcbi8vICAgZXhlY3V0ZURPTVNwZWNpZmljYXRpb24oZGF0YSEuZG9tU3BlYyk7XG4vLyB9KTtcblxuLy8gTGlzdGVuIGZvciBtZXNzYWdlcyBmcm9tIHBvcHVwLnRzXG5jaHJvbWUucnVudGltZS5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIoKHJlcXVlc3Q6IFVzZXJSZXF1ZXN0KSA9PiB7XG4gIGlmICghcmVxdWVzdC5fX2lzX3VzZXJfcmVxdWVzdCkge1xuICAgIGNvbnNvbGUud2FybihcbiAgICAgIFwiUmVjZWl2ZWQgbWVzc2FnZSBmcm9tIHBvcHVwLnRzLCBidXQgaXQgd2FzIG5vdCBhIHVzZXIgcmVxdWVzdC5cXG5JZ25vcmluZy5cIixcbiAgICAgIHJlcXVlc3RcbiAgICApO1xuICAgIHJldHVybjtcbiAgfVxuICBoYW5kbGVVc2VyUmVxdWVzdChyZXF1ZXN0KTtcbn0pO1xuXG4vLyAjZW5kcmVnaW9uXG5cbi8vICNyZWdpb24gMS8xMDAwMCByaWNrIGFzdGxleSByaWNrIHJvbGxcblxuLy8gY29uc3QgaW5zZXJ0aW9uUG9pbnQgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI2NvbnRhaW5lclwiKTtcbi8vIGNvbnN0IHJpY2tSb2xsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImlmcmFtZVwiKTtcbi8vIHJpY2tSb2xsLnNyYyA9IFwiaHR0cHM6Ly93d3cueW91dHViZS5jb20vZW1iZWQvZFF3NHc5V2dYY1E/YXV0b3BsYXk9MSZtdXRlPTFcIjtcbi8vIHJpY2tSb2xsLnN0eWxlLmhlaWdodCA9IFwiNjB2aFwiO1xuLy8gaW5zZXJ0aW9uUG9pbnQ/Lmluc2VydEJlZm9yZShyaWNrUm9sbCwgaW5zZXJ0aW9uUG9pbnQuZmlyc3RDaGlsZCk7XG5cbi8vICNlbmRyZWdpb25cbiJdfQ==